﻿var Jfs_Msg = {
	CATEGORY 			: "Print",
	JOB_NAME 			: "Print",
	TEMPLATE_NAME 		: "Print",
	VENDOR_IDENTIFIER 	: "1"
};