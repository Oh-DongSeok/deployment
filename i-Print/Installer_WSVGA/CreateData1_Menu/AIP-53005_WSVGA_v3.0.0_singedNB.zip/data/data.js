var DATA =
{
	ADDRESS:"",
	PORT:"",
	CREDIT_PAYMENT:"",
	I_MONEY_PAYMENT:"",
	PRINT_USE:"",
	COPY_USE:"",
	SCAN_USE:"",
	FAX_USE:""
}