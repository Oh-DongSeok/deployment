﻿var Img = {
		////ICON
		ALERT_ICON : "./skin/02_print_setting_list_img_impossible.png",
		INFORMATION_ICON : "./skin/02_print_setting_list_img_limitation.png",
		EMPTY_ICON : "./image/IC_ET_01.png",
		SAVE_ICON : "./skin/02_print_setting_list_img_save.png",
		WM_OFF_ICON : "./skin/02_print_setting_list_img_wm_off.png",
		WM_ON_ICON : "./skin/02_print_setting_list_img_wm_on.png",

		//new
		IMG_MP_BG: "./skin/01_main_bg2_800x600.png",
		IMG_MP_POLICY: "./skin/top_policy.png",
		IMG_MP_LOGO:"./skin/fx_3ln_rgb.png",
		IMG_POPUP_ERROR_BG:"./image/CS-GUI-Error_800x440.png",
		IMG_SOFT_CORE_KEYPAD_BG:"./image/soft_core_keypad.png",
		IMG_MP_PROMPTICON_OFF:"./skin/01_main_btn_img_print_n.png",
		IMG_MP_PROMPTICON_PRESS:"./skin/01_main_btn_img_print_p.png",
		IMG_MP_SELECTICON_OFF:"./skin/01_main_btn_img_sel_print_n.png",
		IMG_MP_SELECTICON_PRESS:"./skin/01_main_btn_img_sel_print_p.png",
		IMG_MP_USAGETOOLS_ICON_OFF:"./skin/01_main_btn_img_setting_n.png",
		IMG_MP_USAGETOOLS_ICON_PRESS:"./skin/01_main_btn_img_setting_p.png",
		IMG_MP_FUNCLIST_UP_OFF:"./skin/01_main_btn_up_n.png",
		IMG_MP_FUNCLIST_UP_PRESS:"./skin/01_main_btn_up_p.png",
		IMG_MP_FUNCLIST_DOWN_OFF:"./skin/01_main_btn_dn_n.png",
		IMG_MP_FUNCLIST_DOWN_PRESS:"./skin/01_main_btn_dn_p.png",

		// ECO Function
		IMG_CO2_CAMPAIGN:"./skin/co2_campaign_banner.png",
		ICN_CO2_ICON:"./skin/carbon_icon.png",

		// Soft core keypad
		BTN_SCK_AUTH_PRESS: "./image/btn_auth_key_press.png",
		BTN_SCK_AUTH_OFF: "./image/btn_auth_key_off.png",
		BTN_SCK_NUM_PRESS: "./image/btn_num_key_press.png",
		BTN_SCK_NUM_OFF: "./image/btn_num_key_off.png",

		BTN_SCK_MUL_OFF: "./image/btn_mul_key_off.png",
		BTN_SCK_SHARP_OFF: "./image/btn_sharp_key_off.png",
		BTN_SCK_PAUSE_OFF: "./image/btn_pause_key_off.png",
		BTN_SCK_COMEBACK_OFF: "./image/btn_comeback_key_off.png",
		BTN_SCK_SHORTEN_OFF: "./image/btn_shorten_key_off.png",

		BTN_SCK_MENU_OFF: "./image/btn_menu_key_off.png",
		BTN_SCK_STOP_OFF: "./image/btn_stop_key_off.png",
		BTN_SCK_MENU_STOP_PRESS: "./image/btn_menu_stop_key_press.png",
		BTN_SCK_START_OFF: "./image/btn_start_key_off.png",
		BTN_SCK_START_PRESS: "./image/btn_start_key_press.png",

		//popup
		IMG_POPUP_BG :	"./skin/IM_BK13_1.png",
		BTN_CONFIRM_OFF: "./skin/02_print_setting_btn_121x43_n.png",
    	BTN_CONFIRM_PRESS: "./skin/02_print_setting_btn_121x43_p.png",
    	BTN_CONFIRM_DIS: "./skin/03_print_setting_btn_121x43_dis.png",
    	BTN_CANCEL_OFF: "./skin/02_print_setting_btn_121x43_n.png",
    	BTN_CANCEL_PRESS: "./skin/02_print_setting_btn_121x43_p.png",
    	BTN_CANCEL_DIS: "./skin/03_print_setting_btn_121x43_dis.png",

		//warn Popup
		IMG_POPUP_WARN_BG :	"./skin/04_print_popup_worring_bg.png",
		IMG_POPUP_WARN_ICON : "./skin/04_print_popup_new_card_img3.png",

		//エラー通知ポップアップ用button
		BTN_ERROR_OFF :	"./skin/03_print_setting_btn_121x43_n.png",
		BTN_ERROR_PRESS :	"./skin/03_print_setting_btn_121x43_p.png",
		BTN_ERROR_DIS :	"./skin/03_print_setting_btn_121x43_dis.png",

		//agree Popup
		BTN_AP_OK_OFF: "./skin/02_print_setting_btn_121x43_n.png",
		BTN_AP_OK_PRESS: "./skin/02_print_setting_btn_121x43_p.png",
		BTN_AP_CANCEL_OFF: "./skin/02_print_setting_btn_121x43_n.png",
		BTN_AP_CANCEL_PRESS: "./skin/02_print_setting_btn_121x43_p.png",

		////공통
		//버튼 이미지
		BTN_150_34_OFF : "./skin/03_print_setting_btn_121x43_n.png",
		BTN_150_34_PRESS : "./skin/03_print_setting_btn_121x43_p.png",
		BTN_150_34_PRESS : "./skin/03_print_setting_btn_121x43_p.png",
		BTN_150_34_PRESS : "./skin/03_print_setting_btn_121x43_p.png",

		////개별페이지
		//메뉴화면
		IMG_MP_REFRESH_OFF: "./skin/01_main_btn_reset_n.png",
   		IMG_MP_REFRESH_PRESS: "./skin/01_main_btn_reset_p.png",

		//문서리스트화면
		//Background image
		FILE_LIST_BACKGROUND_IMG: "./skin/02_print_setting_bg.png",

		FILE_LIST_CHECK_OFF: "./skin/02_print_setting_tap_btn_none.png",
		FILE_LIST_CHECK_PRESS: "./skin/02_print_setting_tap_btn_sel.png",

  		//Command button
    	FILE_LIST_COMMAND_BTN_OFF: "./skin/02_print_setting_btn_121x43_n.png",
    	FILE_LIST_COMMAND_BTN_PRESS: "./skin/02_print_setting_btn_121x43_p.png",
    	FILE_LIST_COMMAND_BTN_DIS: "./skin/02_print_setting_btn_121x43_dis.png",
    	//loding image
    	FILE_LIST_LODING_ICON : "./skin/02_print_setting_img_worring.png",
    	//icon image
    	FILE_LIST_SELECTALL_ICON_OFF: "./skin/02_print_setting_btn_img_all_sel_n.png",
    	FILE_LIST_SELECTALL_ICON_PRESS: "./skin/02_print_setting_btn_img_all_sel_p.png",

    	FILE_LIST_DELETE_ICON_OFF: "./skin/02_print_setting_btn_img_del_n.png",
    	FILE_LIST_DELETE_ICON_PRESS: "./skin/02_print_setting_btn_img_del_p.png",

    	FILE_LIST_PS_SETTING_ICON_OFF: "./skin/02_print_setting_btn_img_print_setting_n.png",
    	FILE_LIST_PS_SETTING_ICON_PRESS: "./skin/02_print_setting_btn_img_print_setting_p.png",

    	FILE_LIST_PRINT_ICON_OFF: "./skin/02_print_setting_btn_img_print_n.png",
    	FILE_LIST_PRINT_ICON_PRESS: "./skin/02_print_setting_btn_img_print_p.png",
		//上ボタン、下ボタン
    	FILE_LIST_UP_BTN_OFF: "./skin/02_print_setting_btn_up_n.png",
    	FILE_LIST_UP_BTN_PRESS: "./skin/02_print_setting_btn_up_p.png",
    	FILE_LIST_UP_BTN_DIS: "./skin/02_print_setting_btn_up_dis.png",
    	FILE_LIST_DOWN_BTN_OFF: "./skin/02_print_setting_btn_dn_n.png",
    	FILE_LIST_DOWN_BTN_PRESS: "./skin/02_print_setting_btn_dn_p.png",
    	FILE_LIST_DOWN_BTN_DIS: "./skin/02_print_setting_btn_dn_dis.png",
		//文書選択ボタン
    	FILE_LIST_BUTTON_OFF: "./skin/02_print_setting_tap_n.png",
    	FILE_LIST_BUTTON_PRESS: "./skin/02_print_setting_tap_sel.png",
    	FILE_LIST_BUTTON_ON: "./skin/02_print_setting_tap_sel.png",
    	FILE_LIST_BUTTON_SELECTED: "./skin/02_print_setting_tap_sel.png",
    	FILE_LIST_CHKBUTTON_OFF: "./skin/02_print_setting_tap_btn_none.png",
    	FILE_LIST_CHKBUTTON_PRESS: "./skin/02_print_setting_tap_btn_sel.png",
    	FILE_LIST_CHKBUTTON_ON: "./skin/02_print_setting_tap_btn_sel.png",
		//すべて選択ボタン
    	SELECT_ALL_BTN_OFF: "./skin/02_print_setting_btn_121x43_n.png",
    	SELECT_ALL_BTN_PRESS: "./skin/02_print_setting_btn_121x43_p.png",
    	SELECT_ALL_BTN_ON: "./skin/02_print_setting_btn_121x43_p.png",
    	SELECT_ALL_BTN_DIS: "./skin/02_print_setting_btn_121x43_dis.png",
    	//削除ボタン
    	DELETE_FILE_BTN_OFF: "./skin/02_print_setting_btn_121x43_n.png",
    	DELETE_FILE_BTN_PRESS: "./skin/02_print_setting_btn_121x43_p.png",
    	DELETE_FILE_BTN_DIS: "./skin/02_print_setting_btn_121x43_dis.png",
    	//表示更新ボタン
    	DISPLAY_CHANGE_BTN_OFF: "./skin/02_print_setting_btn_reset_n.png",
    	DISPLAY_CHANGE_BTN_PRESS: "./skin/02_print_setting_btn_reset_p.png",
    	DISPLAY_CHANGE_BTN_DIS: "./skin/02_print_setting_btn_reset_dis.png",
		//프린트 부수 추가
		PRINT_ADD_BTN_OFF: "./skin/02_print_setting_btn_img_plus_n.png",
		PRINT_ADD_BTN_PRESS: "./skin/02_print_setting_btn_img_plus_p.png",
		PRINT_ADD_BTN_DIS: "./skin/02_print_setting_btn_img_plus_dis.png",
		//프린트 부수 제거
		PRINT_REMOVE_BTN_OFF: "./skin/02_print_setting_btn_img_minus_n.png",
		PRINT_REMOVE_BTN_PRESS: "./skin/02_print_setting_btn_img_minus_p.png",
		PRINT_REMOVE_BTN_DIS: "./skin/02_print_setting_btn_img_minus_dis.png",
		//print setting popup
		IMG_PS_BG: "./skin/03_print_setting_bg.png",
		ICN_PRIVATE_PRINT : "./skin/02_print_setting_list_img_my.png",
		ICN_MOBILE : "./skin/02_print_setting_list_img_cross_section.png",
		ICN_MOBILE_PCL : "./skin/02_print_setting_list_img_photo.png",
		ICN_MAC : "./skin/02_print_setting_list_img_mac.png",
		ICN_WINDOWS : "./skin/02_print_setting_list_img_windows.png",
		ICN_LINUX : "./skin/02_print_setting_list_img_linux.png",

		PUL_PS_BASE_OFF:"./skin/02_print_setting_tap_n.png",
		PUL_PS_BASE_PRESS:"./skin/02_print_setting_tap_sel.png",
		PUL_PS_BASE_ON:"./skin/02_print_setting_tap_sel.png",
		PUL_PS_BASE_DIS:"./skin/02_print_setting_tap_n.png",

		PUL_PS_POPUP_BG_TOP:"./image/G_PM_01.png",
		PUL_PS_POPUP_BG_MID:"./image/G_PM_02.png",
		PUL_PS_POPUP_BG_BOT:"./image/G_PM_03.png",

		PUL_PS_BTN_ICN_OFF: "./skin/03_print_setting_btn_drop_down_n.png",
		PUL_PS_BTN_ICN_PRESS: "./skin/03_print_setting_btn_drop_down_p.png",

		BTN_PS_BASE_OFF:"./skin/03_print_setting_img_drop_down_n.png",
		BTN_PS_BASE_PRESS:"./skin/03_print_setting_img_drop_down_s.png",
		BTN_PS_BASE_ON:"./skin/03_print_setting_img_drop_down_s.png",
		BTN_PS_BASE_DIS:"./image/BI_MC_4.png",

		CBX_PS_AFTER_PRN_DELETE_OFF: "./skin/02_print_setting_tap_btn_none.png",
    CBX_PS_AFTER_PRN_DELETE_PRESS: "./skin/02_print_setting_tap_btn_sel.png",
    CBX_PS_AFTER_PRN_DELETE_ON: "./skin/02_print_setting_tap_btn_sel.png",
    CBX_PS_AFTER_PRN_DELETE_DIS: "./skin/02_print_setting_tap_btn_none.png",
		CBX_PS_AFTER_PRN_DELETE_ONDIS: "./image/BZ_CS3_5.png",

		CBX_PS_WATERMARK_ON_OFF: "./skin/02_print_setting_tap_btn_none.png",
    CBX_PS_WATERMARK_ON_PRESS: "./skin/02_print_setting_tap_btn_sel.png",
    CBX_PS_WATERMARK_ON_ON: "./skin/02_print_setting_tap_btn_sel.png",
    CBX_PS_WATERMARK_ON_DIS: "./skin/02_print_setting_tap_btn_none.png",
		CBX_PS_WATERMARK_ONE_ONDIS: "./image/BZ_CS3_5.png",

		PUL_PS_COLORMODE0_OFF : "./image/BI_PC_B1.png",
		PUL_PS_COLORMODE0_PRESS : "./image/BI_PC_B2.png",
		PUL_PS_COLORMODE0_ON : "./image/BI_PC_B3.png",

		PUL_PS_COLORMODE1_OFF : "./image/BI_PC_C1.png",
		PUL_PS_COLORMODE1_PRESS : "./image/BI_PC_C2.png",
		PUL_PS_COLORMODE1_ON : "./image/BI_PC_C3.png",

		IMG_PS_COLORMODE0_OFF : "./image/BI_MC_B1.png",
		IMG_PS_COLORMODE0_PRESS : "./image/BI_MC_B2.png",
		IMG_PS_COLORMODE0_ON : "./image/BI_MC_B3.png",

		IMG_PS_COLORMODE1_OFF : "./image/BI_MC_C1.png",
		IMG_PS_COLORMODE1_PRESS : "./image/BI_MC_C2.png",
		IMG_PS_COLORMODE1_ON : "./image/BI_MC_C3.png",

		PUL_PS_OUTPLEX0_OFF : "./image/BI_PD_11.png",
		PUL_PS_OUTPLEX0_PRESS : "./image/BI_PD_12.png",
		PUL_PS_OUTPLEX0_ON : "./image/BI_PD_13.png",

		PUL_PS_OUTPLEX1_OFF : "./image/BI_PD_21.png",
		PUL_PS_OUTPLEX1_PRESS : "./image/BI_PD_22.png",
		PUL_PS_OUTPLEX1_ON : "./image/BI_PD_23.png",

		PUL_PS_OUTPLEX2_OFF : "./image/BI_PD_31.png",
		PUL_PS_OUTPLEX2_PRESS : "./image/BI_PD_32.png",
		PUL_PS_OUTPLEX2_ON : "./image/BI_PD_33.png",

		IMG_PS_OUTPLEX0_OFF : "./image/BI_MD_11.png",
		IMG_PS_OUTPLEX0_PRESS : "./image/BI_MD_12.png",
		IMG_PS_OUTPLEX0_ON : "./image/BI_MD_13.png",

		IMG_PS_OUTPLEX1_OFF : "./image/BI_MD_21.png",
		IMG_PS_OUTPLEX1_PRESS : "./image/BI_MD_22.png",
		IMG_PS_OUTPLEX1_ON : "./image/BI_MD_23.png",

		IMG_PS_OUTPLEX2_OFF : "./image/BI_MD_31.png",
		IMG_PS_OUTPLEX2_PRESS : "./image/BI_MD_32.png",
		IMG_PS_OUTPLEX2_ON : "./image/BI_MD_33.png",

		PUL_PS_NUP0_OFF : "./image/BI_PE_11.png",
		PUL_PS_NUP0_PRESS : "./image/BI_PE_12.png",
		PUL_PS_NUP0_ON : "./image/BI_PE_13.png",

		PUL_PS_NUP1_OFF : "./image/BI_PE_21.png",
		PUL_PS_NUP1_PRESS : "./image/BI_PE_22.png",
		PUL_PS_NUP1_ON : "./image/BI_PE_23.png",

		PUL_PS_NUP2_OFF : "./image/BI_PE_31.png",
		PUL_PS_NUP2_PRESS : "./image/BI_PE_32.png",
		PUL_PS_NUP2_ON : "./image/BI_PE_33.png",

		PUL_PS_NUP3_OFF : "./image/BI_PE_41.png",
		PUL_PS_NUP3_PRESS : "./image/BI_PE_42.png",
		PUL_PS_NUP3_ON : "./image/BI_PE_43.png",

		IMG_PS_NUP0_OFF : "./image/BI_ME_11.png",
		IMG_PS_NUP0_PRESS : "./image/BI_ME_12.png",
		IMG_PS_NUP0_ON : "./image/BI_ME_13.png",

		IMG_PS_NUP1_OFF : "./image/BI_ME_21.png",
		IMG_PS_NUP1_PRESS : "./image/BI_ME_22.png",
		IMG_PS_NUP1_ON : "./image/BI_ME_23.png",

		IMG_PS_NUP2_OFF : "./image/BI_ME_31.png",
		IMG_PS_NUP2_PRESS : "./image/BI_ME_32.png",
		IMG_PS_NUP2_ON : "./image/BI_ME_33.png",

		IMG_PS_NUP3_OFF : "./image/BI_ME_41.png",
		IMG_PS_NUP3_PRESS : "./image/BI_ME_42.png",
		IMG_PS_NUP3_ON : "./image/BI_ME_43.png",

		IMG_PS_INFOUP_OFF : "./skin/03_print_setting_btn_up_n.png",
		IMG_PS_INFOUP_PRESS : "./skin/03_print_setting_btn_up_p.png",
		IMG_PS_INFOUP_DIS : "./skin/03_print_setting_btn_up_dis.png",

		IMG_PS_INFODOWN_OFF : "./skin/03_print_setting_btn_dn_n.png",
		IMG_PS_INFODOWN_PRESS : "./skin/03_print_setting_btn_dn_p.png",
		IMG_PS_INFODOWN_DIS : "./skin/03_print_setting_btn_dn_dis.png",

		ICN_PS_PLEX_SIMPLEX_OFF : "./skin/02_print_setting_list_img_both.png",
		ICN_PS_PLEX_SIMPLEX_DIS : "./image/I_OBU03_11_4.png",

		ICN_PS_PLEX_DUPLEX_OFF : "./skin/03_print_setting_img_print_both_up.png",
		ICN_PS_PLEX_DUPLEX_DIS : "./image/I_OBU03_13_4.png",

		ICN_PS_PLEX_TUMBLE_OFF : "./skin/03_print_setting_img_print_cross_section.png",
		ICN_PS_PLEX_TUMBLE_DIS : "./image/I_OBU03_12_4.png",

		/**/
		ICN_PS_CM_COLOR_OFF : "./skin/02_print_setting_list_img_auto.png",
		ICN_PS_CM_COLOR_DIS : "./image/I_OBU03_01_4.png",

		ICN_PS_CM_GRAY_OFF: "./skin/02_print_setting_list_img_black.png",
		ICN_PS_CM_GRAY_DIS : "./image/I_OBU03_02_4.png",

		/**/
		ICN_PS_NUP_1UP_OFF : "./skin/02_print_setting_list_img_none.png",
		ICN_PS_NUP_1UP_DIS : "./image/I_OBU03_21_4.png",

		ICN_PS_NUP_2UP_OFF : "./skin/03_print_setting_img_noup_2.png",
		ICN_PS_NUP_2UP_DIS : "./image/I_OBU03_22_4.png",

		ICN_PS_NUP_4UP_OFF : "./skin/03_print_setting_img_noup_4.png",
		ICN_PS_NUP_4UP_DIS : "./image/I_OBU03_23_4.png",

		ICN_PS_NUP_6UP_OFF : "./skin/03_print_setting_img_noup_6.png",
		ICN_PS_NUP_6UP_DIS : "./image/I_OBU03_27_4.png",

		ICN_PS_NUP_8UP_OFF : "./skin/03_print_setting_img_noup_8.png",
		ICN_PS_NUP_8UP_DIS : "./image/I_OBU03_24_4.png",

		ICN_PS_NUP_9UP_OFF : "./skin/03_print_setting_img_noup_9.png",
		ICN_PS_NUP_9UP_DIS : "./image/I_OBU03_28_4.png",

		ICN_PS_NUP_16UP_OFF : "./skin/03_print_setting_img_noup_16.png",
		ICN_PS_NUP_16UP_DIS : "./image/I_OBU03_25_4.png",

		ICN_PS_NUP_32UP_OFF : "./skin/03_print_setting_img_noup_32.png",
		ICN_PS_NUP_32UP_DIS : "./image/I_OBU03_26_4.png",

		IMG_PR_BG : "./skin/04_setting_bg.png",

		ICN_CHECK_MULTI: "./image/checkIcon.png",

		BRIDGE_APP_LOCKED_OFF : "./skin/off_bridge_app_unlocked.png",
		BRIDGE_APP_UNLOCKED_OFF : "./skin/off_bridge_app_unlocked.png",
		ECO_COPY_LOCKED_OFF : "./skin/01_main_btn_eco_copy_n.png",
		ECO_COPY_UNLOCKED_OFF : "./skin/01_main_btn_eco_copy_n.png",
		IPS_LOCKED_OFF : "./skin/01_main_btn_ips_n.png",
		IPS_SCAN_LOCKED_OFF : "./skin/01_main_btn_ips_myscan_n.png",
		IPS_SCAN_UNLOCKED_OFF: "./skin/01_main_btn_ips_myscan_n.png",
    	IPS_UNLOCKED_OFF: "./skin/01_main_btn_ips_n.png",
		NATIVE_MENU_LOCKED_OFF : "./skin/01_main_btn_native_ui_n.png",
		NATIVE_MENU_UNLOCKED_OFF : "./skin/01_main_btn_native_ui_n.png",
		BRIDGE_APP_LOCKED_PRESS : "./skin/press_bridge_app_unlocked.png",
		BRIDGE_APP_UNLOCKED_PRESS : "./skin/press_bridge_app_unlocked.png",
		ECO_COPY_LOCKED_PRESS : "./skin/01_main_btn_eco_copy_p.png",
		ECO_COPY_UNLOCKED_PRESS : "./skin/01_main_btn_eco_copy_p.png",
		IPS_LOCKED_PRESS : "./skin/press_ips_locked.png",
		IPS_SCAN_LOCKED_PRESS : "./skin/01_main_btn_ips_myscan_p.png",
		IPS_SCAN_UNLOCKED_PRESS: "./skin/01_main_btn_ips_myscan_p.png",
    	IPS_UNLOCKED_PRESS: "./skin/01_main_btn_ips_p.png",
		NATIVE_MENU_LOCKED_PRESS : "./skin/01_main_btn_native_ui_p.png",
		NATIVE_MENU_UNLOCKED_PRESS : "./skin/01_main_btn_native_ui_p.png",

		//////////////////
		IMG_RC_BG0 : "./skin/04_print_popup_new_card_bg.png",
		IMG_RC_AGREE : "./skin/Popup_Agree_800-600.png",
		IMG_RC_CARD: "./skin/04_print_popup_new_card_img.png",
    	IMG_RC_BG1: "./skin/04_print_popup_new_card_bg.png",
    	IMG_RC_BG2: "./skin/04_print_popup_new_card_bg.png",
    	IMG_RC_CARD2: "./skin/04_print_popup_new_card_img2.png",

		IMG_RC_OK_OFF:"./image/off_ok.png",
		IMG_RC_OK_PRESS: "./image/press_ok.png",
		IMG_RC_CANCEL_OFF: "./image/off_cancel.png",
		IMG_RC_CANCEL_PRESS: "./image/press_cancel.png",

		/////////////////
		IMG_PE_BG0 : "./skin/05_print_popup_password_exp_bg.png",
		IMG_PE_PASSWORD : "./skin/05_print_popup_password_exp_img.png",

		PRINT_ALL_BTN_OFF : "./skin/print_all_btn_n.png",
		PRINT_ALL_BTN_PRESS : "./skin/print_all_btn_p.png",
		PRINT_ALL_BTN_DIS : "./skin/print_all_btn_n.png",
		PRINT_BTN_OFF: "./skin/02_print_setting_btn_121x43_blue_n.png",
    	PRINT_BTN_PRESS: "./skin/02_print_setting_btn_121x43_blue_p.png",
    	PRINT_BTN_DIS: "./skin/02_print_setting_btn_121x43_blue_dis.png",

    	IMG_PS_PRINT_OFF: "./skin/02_print_setting_btn_121x43_blue_n.png",
    	IMG_PS_PRINT_PRESS: "./skin/02_print_setting_btn_121x43_blue_p.png",
    	IMG_PS_PRINT_DIS: "./skin/02_print_setting_btn_121x43_blue_dis.png",

    	ICN_PS_PRINT_OFF: "./skin/02_print_setting_btn_img_print_n.png",
    	ICN_PS_PRINT_PRESS: "./skin/02_print_setting_btn_img_print_p.png",

		IMG_OK_ICON_OFF:"./skin/03_print_setting_btn_img_ok_n.png",
		IMG_OK_ICON_PRESS:"./skin/03_print_setting_btn_img_ok_p.png",
		IMG_CANCEL_ICON_OFF:"./skin/03_print_setting_btn_img_cancel_n.png",
		IMG_CANCEL_ICON_PRESS:"./skin/03_print_setting_btn_img_cancel_p.png",

		//메뉴화면
		IMG_MP_SETTING_OFF : "./skin/01_main_setting_btn_n.png",
		IMG_MP_SETTING_PRESS : "./skin/01_main_setting_btn_p.png",

		IMG_MP_PROMPT_OFF: "./skin/01_main_btn_164x50_n.png",
    	IMG_MP_PROMPT_PRESS: "./skin/01_main_btn_164x50_p.png",
    	IMG_MP_PROMPT_ON: "./skin/01_main_btn_164x50_p.png",

	    IMG_MP_SELECTED_PRINT_OFF: "./skin/01_main_btn_164x50_n.png",
    	IMG_MP_SELECTED_PRINT_PRESS: "./skin/01_main_btn_164x50_p.png",
    	IMG_MP_SELECTED_PRINT_ON: "./skin/01_main_btn_164x50_p.png",

    	IMG_MP_SETUP_OFF: "./skin/01_main_btn_164x50_n.png",
    	IMG_MP_SETUP_PRESS: "./skin/01_main_btn_164x50_p.png",
		IMG_MP_TOOLS_OFF : "./skin/01_main_btn_164x50_n.png",
		IMG_MP_TOOLS_PRESS : "./skin/01_main_btn_164x50_p.png",

		//인쇄중 화면
		IMG_PP_BG: "./skin/04_print_popup_copy_machine_bg.png",
    	IMG_PP_PG: "./skin/04_print_popup_copy_machine_progress_bar_bg.png",
    	IMG_PP_PGB: "./skin/04_print_popup_copy_machine_progress_bar.png",
    	IMG_PP_MACHINE: "./skin/04_print_popup_copy_machine_img.png",

		//menu button
		IMG_MP_ROCK : "./skin/01_main_btn_lock.png",
		COPY_LOCKED_OFF : "./skin/01_main_btn_copy_n.png",
		COPY_UNLOCKED_OFF: "./skin/01_main_btn_copy_n.png",
		FAX_LOCKED_OFF : "./skin/01_main_btn_fax_n.png",
		FAX_UNLOCKED_OFF: "./skin/01_main_btn_fax_n.png",
		FORM_PRINTING_LOCKED_OFF : "./skin/off_form_printing_unlocked.png",
		FORM_PRINTING_UNLOCKED_OFF : "./skin/off_form_printing_unlocked.png",
		PRIVATE_PRINT_LOCKED_OFF : "./skin/01_main_btn_print_n.png",
		PRIVATE_PRINT_UNLOCKED_OFF : "./skin/01_main_btn_print_n.png",
		SCAN_EMAIL_LOCKED_OFF : "./skin/off_scan_email_unlocked.png",
		SCAN_EMAIL_UNLOCKED_OFF: "./skin/off_scan_email_unlocked.png",
		SCAN_JT_LOCKED_OFF : "./skin/off_scan_jt_unlocked.png",
		SCAN_JT_UNLOCKED_OFF : "./skin/off_scan_jt_unlocked.png",
		SCAN_MBOX_LOCKED_OFF : "./skin/01_main_btn_ips_n.png",
		SCAN_MBOX_UNLOCKED_OFF : "./skin/01_main_btn_ips_n.png",
		SCAN_PC_LOCKED_OFF : "./skin/01_main_btn_scan_n.png",
		SCAN_PC_UNLOCKED_OFF : "./skin/01_main_btn_scan_n.png",
		WEB_LOCKED_OFF : "./skin/off_web_unlocked.png",
		WEB_UNLOCKED_OFF : "./skin/off_web_unlocked.png",
		COPY_LOCKED_PRESS : "./skin/01_main_btn_copy_p.png",
		COPY_UNLOCKED_PRESS: "./skin/01_main_btn_copy_p.png",
		FAX_LOCKED_PRESS : "./skin/01_main_btn_fax_p.png",
		FAX_UNLOCKED_PRESS: "./skin/01_main_btn_fax_p.png",
		FORM_PRINTING_LOCKED_PRESS : "./skin/press_form_printing_unlocked.png",
		FORM_PRINTING_UNLOCKED_PRESS : "./skin/press_form_printing_unlocked.png",
		PRIVATE_PRINT_LOCKED_PRESS : "./skin/01_main_btn_print_p.png",
		PRIVATE_PRINT_UNLOCKED_PRESS : "./skin/01_main_btn_print_p.png",
		SCAN_EMAIL_LOCKED_PRESS : "./skin/press_scan_email_unlocked.png",
		SCAN_EMAIL_UNLOCKED_PRESS: "./skin/press_scan_email_unlocked.png",
		SCAN_JT_LOCKED_PRESS : "./skin/press_scan_jt_unlocked.png",
		SCAN_JT_UNLOCKED_PRESS : "./skin/press_scan_jt_unlocked.png",
		SCAN_MBOX_LOCKED_PRESS : "./skin/01_main_btn_ips_p.png",
		SCAN_MBOX_UNLOCKED_PRESS : "./skin/01_main_btn_ips_p.png",
		SCAN_PC_LOCKED_PRESS : "./skin/01_main_btn_scan_p.png",
		SCAN_PC_UNLOCKED_PRESS : "./skin/01_main_btn_scan_p.png",
		WEB_LOCKED_PRESS : "./skin/press_web_unlocked.png",
		WEB_UNLOCKED_PRESS : "./skin/press_web_unlocked.png",
		EDOC_LOCKED_OFF : "./skin/off_edoc_unlocked.png",
		EDOC_LOCKED_PRESS : "./skin/press_edoc_unlocked.png",
		EDOC_UNLOCKED_OFF : "./skin/off_edoc_unlocked.png",
		EDOC_UNLOCKED_PRESS : "./skin/press_edoc_unlocked.png",
		RESERVED_01_LOCKED_OFF : "./skin/off_reserved01.png",
		RESERVED_02_LOCKED_OFF : "./skin/off_reserved02.png",
		RESERVED_03_LOCKED_OFF : "./skin/off_reserved03.png",
		RESERVED_04_LOCKED_OFF : "./skin/off_reserved04.png",
		RESERVED_05_LOCKED_OFF : "./skin/off_reserved05.png",
		RESERVED_06_LOCKED_OFF : "./skin/off_reserved06.png",
		RESERVED_07_LOCKED_OFF : "./skin/off_reserved07.png",
		RESERVED_08_LOCKED_OFF : "./skin/off_reserved08.png",
		RESERVED_09_LOCKED_OFF : "./skin/off_reserved09.png",
		RESERVED_10_LOCKED_OFF : "./skin/off_reserved10.png",
		RESERVED_11_LOCKED_OFF : "./skin/off_reserved11.png",
		RESERVED_12_LOCKED_OFF : "./skin/off_reserved12.png",
		RESERVED_01_LOCKED_PRESS : "./skin/press_reserved01.png",
		RESERVED_02_LOCKED_PRESS : "./skin/press_reserved02.png",
		RESERVED_03_LOCKED_PRESS : "./skin/press_reserved03.png",
		RESERVED_04_LOCKED_PRESS : "./skin/press_reserved04.png",
		RESERVED_05_LOCKED_PRESS : "./skin/press_reserved05.png",
		RESERVED_06_LOCKED_PRESS : "./skin/press_reserved06.png",
		RESERVED_07_LOCKED_PRESS : "./skin/press_reserved07.png",
		RESERVED_08_LOCKED_PRESS : "./skin/press_reserved08.png",
		RESERVED_09_LOCKED_PRESS : "./skin/press_reserved09.png",
		RESERVED_10_LOCKED_PRESS : "./skin/press_reserved10.png",
		RESERVED_11_LOCKED_PRESS : "./skin/press_reserved11.png",
		RESERVED_12_LOCKED_PRESS : "./skin/press_reserved12.png",
		RESERVED_01_UNLOCKED_OFF : "./skin/off_reserved01.png",
		RESERVED_02_UNLOCKED_OFF : "./skin/off_reserved02.png",
		RESERVED_03_UNLOCKED_OFF : "./skin/off_reserved03.png",
		RESERVED_04_UNLOCKED_OFF : "./skin/off_reserved04.png",
		RESERVED_05_UNLOCKED_OFF : "./skin/off_reserved05.png",
		RESERVED_06_UNLOCKED_OFF : "./skin/off_reserved06.png",
		RESERVED_07_UNLOCKED_OFF : "./skin/off_reserved07.png",
		RESERVED_08_UNLOCKED_OFF : "./skin/off_reserved08.png",
		RESERVED_09_UNLOCKED_OFF : "./skin/off_reserved09.png",
		RESERVED_10_UNLOCKED_OFF : "./skin/off_reserved10.png",
		RESERVED_11_UNLOCKED_OFF : "./skin/off_reserved11.png",
		RESERVED_12_UNLOCKED_OFF : "./skin/off_reserved12.png",
		RESERVED_01_UNLOCKED_PRESS : "./skin/press_reserved01.png",
		RESERVED_02_UNLOCKED_PRESS : "./skin/press_reserved02.png",
		RESERVED_03_UNLOCKED_PRESS : "./skin/press_reserved03.png",
		RESERVED_04_UNLOCKED_PRESS : "./skin/press_reserved04.png",
		RESERVED_05_UNLOCKED_PRESS : "./skin/press_reserved05.png",
		RESERVED_06_UNLOCKED_PRESS : "./skin/press_reserved06.png",
		RESERVED_07_UNLOCKED_PRESS : "./skin/press_reserved07.png",
		RESERVED_08_UNLOCKED_PRESS : "./skin/press_reserved08.png",
		RESERVED_09_UNLOCKED_PRESS : "./skin/press_reserved09.png",
		RESERVED_10_UNLOCKED_PRESS : "./skin/press_reserved10.png",
		RESERVED_11_UNLOCKED_PRESS : "./skin/press_reserved11.png",
		RESERVED_12_UNLOCKED_PRESS : "./skin/press_reserved12.png"
};
