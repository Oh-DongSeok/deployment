﻿/**
 * @fileoverview 프린트중 팝업
 * @author FXKIS son.ch
 * @version 1.0.0
 */
/**
 * 개별 페이지의 표시 및 동작용
 * 프린트중 팝업
 */
var PrintingPopup = new TemplatePage();

PrintingPopup.ID = "pop_printing";
PrintingPopup.key = "PP";	//메시지 영역 구분자

/**
 * 개별 페이지의 Data정의
 */
PrintingPopup._initModel=function()
{
	this._data=
	{
		buttonList:[
		],
		imageList:[
			{id:"img_PP_BG", src:Img["IMG_PP_BG"]},
			{id:"img_PP_PG", src:Img["IMG_PP_PG"]},
			{id:"img_PP_PGB", src:Img["IMG_PP_PGB"]},
			{id:"img_PP_MACHINE", src:Img["IMG_PP_MACHINE"]}
		],
		textList:[
			{id:"lbl_PP_guide", text:Msg.PRINTING.CS_GUI_Printing}
		]
	};
};
PrintingPopup._onPageChange = function() {
	this.updateDisplay();
};

PrintingPopup.updateDisplay = function(){
	var i = 0;
	var elem = document.getElementById("img_PP_PGB");
	elem.style.width="1%";
  	if (i == 0) {
    	i = 1;
    	var width = 0;
    	var progress = setInterval(frame, 100);
    	function frame() {
      		if (width >= 40) {
	        	clearInterval(progress);
	        	i = 0;
      		} else {
	        	width++;
        		elem.style.width = width + "%";
      		}
    	}
  	}
};

/**
 * 개별 페이지의 Event처리
 * @param {string} event : Event종류
 * @param {string} id : Event발생원
 */
PrintingPopup.EventHandler = function(event, id)
{
	switch(event){
		case "onbuttonup":
			MessageManager.clearMessageArea();
			switch(id)
			{
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		case "onhardkeydown":
			MessageManager.clearMessageArea();
			switch(id)
			{
				case BrowserExt.keyCode.FX_VK_CLEAR:
					//Reset Key
					BrowserExt.Beep(0);
					//window.location.reload(true);
					// Mantis No: 0000018
					BrowserExt.SetScreenChange("allservice");
					break;
				case BrowserExt.keyCode.FX_VK_PAUSE:
					break;
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		default:
			break;
	}
};