﻿var glbPageSource=[];
glbPageSource["page_waiting"]='';
glbPageSource["page_menu"]=
	'<img id="img_MP_bg" />' +
	'<img id="img_MP_banner" />' +
	'<!-- 주가정보 -->' +
        '<div class="sliderWrap stockInfo">' +
            '<div class="slider">' +
                '<ul class="list" data-bind="foreach:vl.jisu.list">' +
                    '<li>' +
                        '<strong class="tit" data-bind="text:$data[9]"></strong>' +
                        '<p class="state " data-bind="css:$parent.vl.jisu.getCssValUp($data[4])">' +
							'<span data-bind="NumberFormat:$data[5]"></span>' +
						'</p>' +
                        '<em data-bind="NumberFormat:$data[3]"></em>' +
                    '</li>' +
                '</ul>' +
            '</div>' +
        '</div>' +
	'<div id="btn_MP_setting" class="btn" style="display:none;" >' +
		'<img src="" alt="" id="img_MP_setting" class="btnBg" />' +
		'<div id="lbl_MP_setting" class="lbl"></div>' +
	'</div>' +
	'<img id="btn_MP_refresh" class="btn" />' +
	'<div id="lbl_MP_prnCount"></div>' +
	'<div id="btn_MP_promptPrint" class="btn">' +
		'<img src="" alt="" id="img_MP_promptPrint" class="btnBg" />' +
		'<div id="lbl_MP_promptPrint" class="lbl"></div>' +
	'</div>' +
	'<div id="btn_MP_selectPrint" class="btn">' +
		'<img src="" alt="" id="img_MP_selectPrint" class="btnBg" />' +
		'<div id="lbl_MP_selectPrint" class="lbl"></div>' +
	'</div>' +
	'<div id="btn_MP_usageTools" class="btn">' +
		'<img src="" alt="" id="img_MP_usageTools" class="btnBg" />' +
		'<div id="lbl_MP_usageTools" class="lbl"></div>' +
	'</div>' +
	'<div id="lyr_colorUsage">' +
		'<div id="lbl_MP_color_used"></div>' +
		'<div id="lbl_MP_color_limit"></div>' +
		'<div id="lbl_MP_gray_used"></div>' +
		'<div id="lbl_MP_gray_limit"></div>' +
	'</div>' +
	'<div id="lyr_funcList"></div>' +
	'<div id="txt_MP_Msg0"></div>' +
	'<div id="txt_MP_Msg1"></div>' +
	'<div id="lbl_MP_printOpt" class="lbl"></div>' +
	'<div id="lbl_MP_docCnt" class="lbl"></div>' +
	'<div id="lbl_MP_usage" class="lbl"></div>';
glbPageSource["pop_preferenceSetting"]=
	'<img id="img_PR_bg" class="bg" />' +
	'<img id="img_PR_banner" />' +
	'<!--header-->' +
		'<div>' +
			'<div id="lbl_PR_title" class="lbl"></div>' +
			'<div id="btn_PR_cancel" class="btn">' +
				'<img id="img_PR_cancel" class="bg" />' +
				'<div id="lbl_PR_cancel" class="lbl"></div>' +
			'</div>' +
			'<div id="btn_PR_confirm" class="btn">' +
				'<img id="img_PR_confirm" class="bg" />' +
				'<div id="lbl_PR_confirm" class="lbl"></div>' +
			'</div>' +
		'</div>' +
		'<!--body-->' +
			'<div id="lyr_PR_body">' +
				'<div id="lbl_PR_lstDisplayLimit" class="lbl"></div>' +
				'<div id="lbl_PR_resptimeDisplayLimit" class="lbl"></div>' +
				'<div id="lbl_PR_titleBarName" class="lbl"></div>' +
				'<div id="lbl_PR_connectionTimeLimit" class="lbl"></div>' +
				'<div id="lbl_PR_lstBarDisplay" class="lbl"></div>' +
				'<div id="lbl_PR_serverURL" class="lbl"></div>' +
				'<div id="lbl_PR_lstListAutoSelect" class="lbl"></div>' +
				'<div id="lbl_PR_lstListSortSelect" class="lbl"></div>' +
				'<div id="btn_PR_title_delete" class="btn">' +
					'<img id="img_PR_title_delete" class="bg" />' +
					'<div id="lbl_PR_title_delete" class="lbl"></div>' +
				'</div>' +
				'<div id="btn_PR_url_delete" class="btn">' +
					'<img id="img_PR_url_delete" class="bg" />' +
					'<div id="lbl_PR_url_delete" class="lbl"></div>' +
				'</div>' +
				'<div id="lbl_PR_defaultBtnSetting" class="lbl"></div>' +
				'<div id="lbl_PR_displayColorUsage" class="lbl"></div>' +
				'<div id="lbl_PR_deleteAfterPrintMode" class="lbl"></div>' +
				'<select id="pul_PR_lstDisplayLimit" class="pulldown">' +
					'<option id="pul_PR_lstDisplayLimit0" value="40"></option>' +
					'<option id="pul_PR_lstDisplayLimit1" value="80"></option>' +
				'</select>' +
				'<select id="pul_PR_resptimeDisplayLimit" class="pulldown" >' +
					'<option id="pul_PR_resptimeDisplayLimit0" value="12"></option>' +
					'<option id="pul_PR_resptimeDisplayLimit1" value="24"></option>' +
				'</select>' +
				'<input id="tbx_PR_titleBarName" class="tbx" />' +
				'<input id="tbx_PR_connectionTimeLimit" class="tbx" />' +
				'<div id="lbl_PR_connectionTimeLimit_Guide" class="lbl"></div>' +
				'<select id="pul_PR_lstBarDisplay" class="pulldown">' +
					'<option id="pul_PR_lstBarDisplay0" value="Y"></option>' +
					'<option id="pul_PR_lstBarDisplay1" value="N"></option>' +
				'</select>' +
				'<select id="pul_PR_lstListAutoSelect" class="pulldown">' +
					'<option id="pul_PR_lstListAutoSelect0" value="0"></option>' +
					'<option id="pul_PR_lstListAutoSelect1" value="1"></option>' +
				'</select>' +
				'<input id="tbx_PR_serverURL" class="tbx" />' +
				'<select id="pul_PR_defaultBtnSetting" class="pulldown">' +
					'<option id="pul_PR_defaultBtnSetting0" value="0"></option>' +
					'<option id="pul_PR_defaultBtnSetting1" value="1"></option>' +
					'<option id="pul_PR_defaultBtnSetting2" value="2"></option>' +
					'<option id="pul_PR_defaultBtnSetting3" value="3"></option>' +
					'<option id="pul_PR_defaultBtnSetting4" value="4"></option>' +
				'</select>' +
				'<select id="pul_PR_displayColorUsage" class="pulldown">' +
					'<option id="pul_PR_displayColorUsage0" value="Y"></option>' +
					'<option id="pul_PR_displayColorUsage1" value="N"></option>' +
				'</select>' +
				'<select id="pul_PR_deleteAfterPrintMode" class="pulldown">' +
					'<option id="pul_PR_deleteAfterPrintMode0" value="save"></option>' +
					'<option id="pul_PR_deleteAfterPrintMode1" value="delete"></option>' +
				'</select>' +
				'<select id="pul_PR_lstListSortSelect" class="pulldown">' +
					'<option id="pul_PR_lstListSortSelect0" value="Y"></option>' +
					'<option id="pul_PR_lstListSortSelect1" value="N"></option>' +
				'</select>' +
				'<div id="lbl_PR_csIndex" class="lbl"></div>' +
				'<div id="btn_PR_csIndex_delete" class="btn">' +
					'<img id="img_PR_csIndex_delete" class="bg" />' +
					'<div id="lbl_PR_csIndex_delete" class="lbl"></div>' +
				'</div>' +
				'<input id="tbx_PR_csIndex" class="tbx" />' +
			'</div>' +
			'<div id="txt_PR_Msg0"></div>' +
			'<div id="txt_PR_Msg1"></div>';
glbPageSource["pop_printSetting"]=
	'<!--header-->' +
		'<img id="img_PS_bg" />' +
		'<img id="img_PS_banner" />' +
		'<img id="icn_PS_carbon" />' +
		'<img id="icn_PS_title" class="icon" />' +
		'<div id="lbl_PS_title" class="lbl"></div>' +
		'<div id="btn_PS_confirm" class="btn">' +
			'<img id="img_PS_confirm" class="bg" />' +
			'<div id="lbl_PS_confirm" class="lbl"></div>' +
		'</div>' +
		'<div id="btn_PS_cancel" class="btn">' +
			'<img id="img_PS_cancel" class="bg" />' +
			'<div id="lbl_PS_cancel" class="lbl"></div>' +
		'</div>' +
	'<!--body-->' +
		'<div id="lbl_PS_eco_msg1" class="lbl"></div>' +
		'<div id="lbl_PS_eco_msg2" class="lbl"></div>' +
		'<div id="btn_PS_print" class="btn" >' +
				'<img id="img_PS_print" class="btnBg" />' +
				'<div id="lbl_PS_print" class="lbl" ></div>' +
		'</div>' +
		'<div id="tit_PS_jobName" class="lbl"></div>' +
		'<div id="lbl_PS_jobName" class="lbl"></div>' +
		'<div id="tit_PS_jobRcvTime" class="lbl"></div>' +
		'<div id="lbl_PS_jobRcvTime" class="lbl"></div>' +
		'<div id="tit_PS_totalPage" class="lbl"></div>' +
		'<div id="lbl_PS_totalPage" class="lbl"></div>' +
		'<div id="lbl_PS_totalPageUnit" class="lbl"></div>' +
		'<div id="tit_PS_printQuantity" class="lbl"></div>' +
		'<div id="lyr_PS_printQuantity" class="lyr">' +
			'<img id="img_PS_printQuantity">' +
				'<div id="lbl_PS_printQuantity" class="lbl"></div>' +
				'<div id="lbl_PS_printQuantityUnit"></div>' +
			'</div>' +
			'<div id="tit_PS_printQuantityUnit" class="lbl"></div>' +
			'<img id="cbx_PS_deleteAfterPrint" type="checkbox" class="btn" />' +
			'<div id="tit_PS_deleteAfterPrint" class="lbl"></div>' +
			'<div id="tit_PS_nup" class="lbl"></div><!--pulldown nup--><div id="pul_PS_nup" class="pulldown"><img id="img_PS_nup" class="bg" /><img id="icn_PS_nup" class="icn" /><div id="lbl_PS_nup" class="lbl"></div></div><div id="tit_PS_color" class="lbl"></div><!--pulldown color--><div id="pul_PS_color" class="pulldown"><img id="img_PS_color" class="bg" /><img id="icn_PS_color" class="icn" /><div id="lbl_PS_color" class="lbl"></div></div><div id="tit_PS_plex" class="lbl">tit_PS_plex</div><!--pulldown Plex--><div id="pul_PS_plex" class="pulldown"><img id="img_PS_plex" class="bg" /><img id="icn_PS_plex" class="icn" /><div id="lbl_PS_plex" class="lbl"></div></div><div id="lyr_PS_infoDisplay"><img id="bg_PS_infoDisplay" class="bg" /><div id="lyr_PS_Msg" class="lbl"><img id="icn_PS_infoDisplay" class="icon" /><div id="txt_PS_Msg0"></div><div id="txt_PS_Msg1"></div></div><img id="btn_PS_infoUp" class="btn" /><img id="btn_PS_infoDown" class="btn" /></div></div>';
glbPageSource["pop_registCard"]=
	'<img id="img_RC_banner" />' +
	'<!-- body -->' +
		'<div id="lyr_RC_step01" class="rcWrapper">' +
			'<img id="img_RC_step01_bg" />' +
			'<div id="lbl_RC_step01_guide1"></div>' +
			'<div id="lbl_RC_step01_guide2"></div>' +
			'<div id="lbl_RC_step01_guide3"></div>' +
			'<div id="btn_RC_step01_ok" class="btn" >' +
				'<img id="img_RC_step01_ok" class="btnBg" />' +
				'<div id="lbl_RC_step01_ok" class-"lbl"></div>' +
			'</div>' +
			'<div id="btn_RC_step01_cancel" class="btn" >' +
				'<img id="img_RC_step01_cancel" class="btnBg" />' +
				'<div id="lbl_RC_step01_cancel" class-"lbl"></div>' +
			'</div>' +
		'</div>' +
		'<div id="lyr_RC_step02" class="rcWrapper">' +
			'<img id="img_RC_step02_bg" />' +
			'<div id="lbl_RC_step02_guide1"></div>' +
			'<div id="lbl_RC_step02_guide2"></div>' +
			'<div id="lbl_RC_step02_guide3"></div>' +
			'<div id="lbl_RC_step02_guide4"></div>' +
			'<input id="tbx_RC_step02_id" type="text" class="id_box" />' +
			'<input id="tbx_RC_step02_pw" type="password" class="pw_box" />' +
			'<div id="btn_RC_step02_ok" class="btn" >' +
				'<img id="img_RC_step02_ok" class="btnBg" />' +
				'<div id="lbl_RC_step02_ok" class-"lbl"></div>' +
			'</div>' +
			'<div id="btn_RC_step02_cancel" class="btn" >' +
				'<img id="img_RC_step02_cancel" class="btnBg" />' +
				'<div id="lbl_RC_step02_cancel" class-"lbl"></div>' +
			'</div>' +
		'</div>' +
		'<div id="lyr_RC_step03" class="rcWrapper"><img id="img_RC_step03_bg" /><div id="lbl_RC_step03_guide1"></div><div id="lbl_RC_step03_guide2"></div><div id="btn_RC_step03_ok" class="btn" ><img id="img_RC_step03_ok" class="btnBg" /><div id="lbl_RC_step03_ok" class-"lbl"></div></div></div>';
glbPageSource["pop_login"]=
	'<img id="img_LI_banner" />' + 
	'<!-- body -->' + 
		'<div id="lyr_LI_step02" class="liWrapper">' + 
			'<img id="img_LI_step02_bg" />' + 
			'<div id="lbl_LI_step02_guide1"></div>' +
			'<div id="lbl_LI_step02_guide2"></div>' +
			'<input id="tbx_LI_step02_id" type="text" class="id_box" />' + 
			'<input id="tbx_LI_step02_pw" type="password" class="pw_box" />' + 
			'<div id="btn_LI_step02_ok" class="btn" >' +
				'<img id="img_LI_step02_ok" class="btnBg" />' +
				'<div id="lbl_LI_step02_ok" class-"lbl"></div>' +
			'</div>' +
			'<div id="btn_LI_step02_cancel" class="btn" >' +
				'<img id="img_LI_step02_cancel" class="btnBg" />' +
				'<div id="lbl_LI_step02_cancel" class-"lbl"></div>' +
			'</div>' +
		'</div>';
glbPageSource["pop_printing"]=
	'<!--header-->' +
		'<img id="img_PP_banner" />' +
		'<div id="lbl_PP_title"></div>' +
	'<!--body-->' +
	'<div>' +
		'<img id="img_PP_BG" />' +
		'<div id="lbl_PP_guide" class="lbl" ></div>' +
	'</div>';
glbPageSource["pop_errorPopup"]='<!--header--><img id="img_EP_banner" /><img id="img_EP_bg" /><div id="lbl_EP_title"></div><!--body--><div><div id="lbl_EP_msg"><ul><li><div id="txt_EP_msg0"></div></li><li><div id="txt_EP_msg1"></div></li><li><div id="txt_EP_msg2"></div></li><li><div id="txt_EP_msg3"></div></li><li><div id="txt_EP_msg4"></div></li><li><div id="txt_EP_msg5"></div></li><li><div id="txt_EP_msg6"></div></li><li><div id="txt_EP_msg7"></div></li><li><div id="txt_EP_msg8"></div></li><li><div id="txt_EP_msg9"></div></li><li><div id="txt_EP_msg10"></div></li><li><div id="txt_EP_msg11"></div></li></ul></div></div>';
glbPageSource["pop_warnPopup"]='<!--header--><img id="img_WP_banner" /><img id="img_WP_bg" /><div id="lbl_WP_title"></div><!--body--><div><div id="lbl_WP_msg"><ul><li><div id="txt_WP_msg0"></div></li><li><div id="txt_WP_msg1"></div></li><li><div id="txt_WP_msg2"></div></li><li><div id="txt_WP_msg3"></div></li><li><div id="txt_WP_msg4"></div></li><li><div id="txt_WP_msg5"></div></li><li><div id="txt_WP_msg6"></div></li><li><div id="txt_WP_msg7"></div></li><li><div id="txt_WP_msg8"></div></li><li><div id="txt_WP_msg9"></div></li><li><div id="txt_WP_msg10"></div></li></ul></div><div id="btn_WP_close" class="btn"><img id="img_WP_close" class="btnBg" /><div id="lbl_WP_close" ></div></div></div>';