﻿/**
 * 개별 페이지의 표시 및 동작용
 * （IC Card등록용 팝업)
 */
var LoginPopup = new TemplatePage();
var textIdSelect = false;
var textPwSelect = false;

LoginPopup.ID = "pop_login";

/**
 * 개별 페이지의 Data정의
 */
LoginPopup._initModel = function()
{
	this._data =
	{
		buttonList:[
			{id:"btn_LI_step02_ok",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_LI_step02_ok", offImg: Img.IMG_RC_OK_OFF, pressImg: Img.IMG_RC_OK_PRESS }},
			{id:"btn_LI_step02_cancel",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_LI_step02_cancel", offImg: Img.IMG_RC_CANCEL_OFF,pressImg: Img.IMG_RC_CANCEL_PRESS}}
		],
		imageList:[
			{id:"img_LI_step02_bg",	src:Img.IMG_RC_BG1},
			{id:"img_LI_banner",	src:Img.IMG_BOTTOM_BANNER}
		],
		textList:[
			{id:"lbl_LI_step02_guide1",	text:Msg.REGIST_CARD.STEP2_GUIDE1	},
			{id:"lbl_LI_step02_guide2",	text:Msg.REGIST_CARD.STEP2_GUIDE2	},
			{id:"lbl_LI_step02_ok",		text:Msg.REGIST_CARD.LBL_OK	},
			{id:"lbl_LI_step02_cancel",	text:Msg.REGIST_CARD.LBL_CANCEL	}
		]
	};
};

LoginPopup._onPageChange=function(){
	this._dataSet.rcStep = 0;
	WidgetLib.setWidgetStatus("btn_LI_step02_ok",{enable:true});
	document.getElementById("lyr_LI_step02").className = "liWrapper focused";
	this.updateDisplay();
};
/**
 * 화면 표시의 갱신 (공통/화면전환시에 호출된다.)
 */
LoginPopup.updateDisplay=function(){
	KISUtil.debug("function:","updateDisplay");

	var idx = this._dataSet.registCardIdx;
	//console.log("this._dataSet.registCardIdx:"+this._dataSet.registCardIdx);
	if(idx<0)
	{
		KISUtil.debug("invalid DataType/registCard",this._dataSet.registCard);
	}
	else
	{
		glbInfo.registCard=[0,1,2];		//필요한가?
		for(var i=0,il=glbInfo.registCard.length;i<il;i++)
		{
			WidgetLib.setWidgetStatus("btn_LI_registCard_"+i,{on:(i==idx)});
		}
	}
};

/**
 * 개별 페이지의 Event처리
 * @param {string} event : Event의 종류
 * @param {string} id : Event의 발생원
 */
LoginPopup.EventHandler = function(event, id)
{
	KISUtil.debug("EventHandler","event:"+event+"/id:"+id);
	//Common.setText("lbl_LI_step02_guide0", "event:" + event + "/id:" + id);
	switch(event){
		case "onbuttonup":
			MessageManager.clearMessageArea();
			BrowserExt.Beep(0);
			switch(id)
			{
				case "btn_LI_step02_ok":
					var _id = document.getElementById('tbx_LI_step02_id').value;
					var _pw = document.getElementById('tbx_LI_step02_pw').value;
					
					//send Login
					if(_id == "11111"){
						//userId, password, realm, bltinUser, isKeyOperator
						var realm = "";
						//var bltinUser = "CustomerEngineer";
						var bltinUser = "";
						var isKeyOperator = true;
						SSMILib.LoginDev(_id, _pw, realm, bltinUser, isKeyOperator);
					}else{
						SSMILib.LoginDev(_id, _pw);
					}

					//여러번 클릭에 따른 다중요청이 발생할 수 있음 회피 코드가 필요해보임
					WidgetLib.setWidgetStatus("btn_LI_step02_ok",{enable:false});
					BrowserExt.SetScreenChange("allservice");
					break;
				case "btn_LI_step02_cancel":
					document.getElementById("lyr_LI_step02").className = "rcWrapper";
					delete this._dataSet.rcStep;
					//로그아웃 처리
					SSMILib.LogoutDev();
					BrowserExt.SetScreenChange("allservice");
					break;
				case "btn_MP_func_0":
				case "btn_MP_func_1":
				case "btn_MP_func_2":
				case "btn_MP_func_3":
				case "btn_MP_func_4":
				case "btn_MP_func_5":
				case "btn_MP_func_6":
				case "btn_MP_func_7":
				case "btn_MP_func_8":
					break;
				case "btn_comeback_key":
					document.getElementById('tbx_LI_step02_id').value = "";
					document.getElementById('tbx_LI_step02_pw').value = "";
					break;
				case "btn_menu_key":
					//リセットキー
					BrowserExt.Beep(0);
					BrowserExt.SetScreenChange("allservice");
					//document.getElementById('tbx_LI_step02_id').value = "";
					//document.getElementById('tbx_LI_step02_pw').value = "";
					break;
				case "btn_auth_key":
					BrowserExt.Beep(1);
					break;
				case "btn_start_key":
					BrowserExt.Beep(1);
					break;
				default:
					//clearMessageAreaTimer();
					break;
			}
			break;
		case "onhardkeydown":
			MessageManager.clearMessageArea();
			switch(id)
			{
				case BrowserExt.keyCode.FX_VK_CLEAR:
					//Reset Key
					BrowserExt.Beep(0);
					BrowserExt.SetScreenChange("allservice");
					break;
				case BrowserExt.keyCode.FX_VK_BACK_SPACE:
					BrowserExt.Beep(0);
					document.getElementById('tbx_LI_step02_id').value = "";
					document.getElementById('tbx_LI_step02_pw').value = "";
					break;
				case BrowserExt.keyCode.FX_VK_ENTER:
					var _id = document.getElementById('tbx_LI_step02_id').value;
					var _pw = document.getElementById('tbx_LI_step02_pw').value;
					//send Login
					SSMILib.LoginDev(_id, _pw);
					//여러번 클릭에 따른 다중요청이 발생할 수 있음 회피 코드가 필요해보임
					WidgetLib.setWidgetStatus("btn_LI_step02_ok",{enable:false});
					BrowserExt.SetScreenChange("allservice");
					break;
				case BrowserExt.keyCode.FX_VK_0:
				case BrowserExt.keyCode.FX_VK_1:
				case BrowserExt.keyCode.FX_VK_2:
				case BrowserExt.keyCode.FX_VK_3:
				case BrowserExt.keyCode.FX_VK_4:
				case BrowserExt.keyCode.FX_VK_5:
				case BrowserExt.keyCode.FX_VK_6:
				case BrowserExt.keyCode.FX_VK_7:
				case BrowserExt.keyCode.FX_VK_8:
				case BrowserExt.keyCode.FX_VK_9:
				case BrowserExt.keyCode.FX_VK_PAUSE:
					break;
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		default:
			break;
	}
};

function select(){
	textIdSelect = true;
	textPwSelect = false;
}