﻿/**
 * 개별 페이지의 표시 및 동작용
 * （에러 팝업/黄色）
 */
var WarnPopup = new TemplatePage();

WarnPopup.ID = "pop_warnPopup";

/**
 * 개별 페이지의 Data정의
 */
WarnPopup._initModel=function()
{
	this._data=
	{
		buttonList:[
			//{id:"btn_WP_close",	type:WidgetLib.ButtonType.NORMAL,	attr:{offImg:"", pressImg:""}	},
			{id:"btn_WP_close",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_WP_close",	offImg:Img["BTN_ERROR_OFF"], pressImg:Img["BTN_ERROR_PRESS"]}	},
		],
		imageList:[
			{id:"img_WP_bg",	src:Img["IMG_POPUP_WARN_BG"]},
			{id:"img_WP_banner",src:Img["IMG_BOTTOM_BANNER"]}
		],
		textList:[
			//{id	:	"lbl_WP_popup",	text:	Msg.DateFormatPopup.lbl_WP_popup	},	//동적할당
			//{id	:	"lbl_WP_cancel",	text:	Msg.Common.lbl_POPUP_cancel	},	//동적할당
		]
	};
};

WarnPopup._onPageChange = function(){
	this.updateDisplay();
};

/**
 * 화면 표시의 갱신 (공통/화면전환시에 호출된다.)
 */
WarnPopup.updateDisplay = function()
{
	BrowserExt.Beep(1);
	var arg = this._message;
	Common.setText("lbl_WP_close", Msg.Common.lbl_POPUP_close);
	Common.setText("lbl_WP_title", arg.title);
	if(arg.message){
		var tmp;
		var _length=11;
		for (var i = 0, iMax = arg.message.length; i < _length; i++) {
			if (i < iMax) {
				tmp = arg.message[i];
			}
			else {
				tmp = "";
			}
			Common.setText("txt_WP_msg" + i, tmp);
		}
	}
};


/**
 * 개별 페이지의 Event처리
 * @param {string} event : Event의 종류
 * @param {string} id : Event의 발생원
 */
WarnPopup.EventHandler = function(event, id)
{
	KISUtil.debug("EventHandler", "event:" + event + "/id:" + id);
	switch(event){
		case "onbuttonup":
			MessageManager.clearMessageArea();
			switch(id)
			{
				case "btn_WP_close":
					BrowserExt.Beep(0);
					if(this._message.type==="logout"){
						SSMILib.LogoutDev();
						return;
					}				
					else if(this._message.targetPage)
					{
						//PageManager.changePage(PageManager.prevPage, PageManager.type.NORMAL);
						PageManager.changePage(PageManager.prevPage, PageManager.type.CANCEL);
					}
					else
					{
						BrowserExt.SetScreenChange("allservice");
					}
					break;
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		case "onhardkeydown":
			MessageManager.clearMessageArea();
			switch(id)
			{
				case BrowserExt.keyCode.FX_VK_CLEAR:
					if(this._message.targetPage)
					{
						//Reset Key
						BrowserExt.Beep(0);
						//window.location.reload(true);
						// Mantis No: 0000018
						BrowserExt.SetScreenChange("allservice");
					}
					else
					{
						BrowserExt.Beep(1);
					}
					break;
				case BrowserExt.keyCode.FX_VK_PAUSE:
					break;
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		default:
			break;
	}
};