﻿/**
 * 개별 페이지의 표시 및 동작용
 * （환경 설정 팝업)
 */
var PreferenceSettingPopup = new TemplatePage();

PreferenceSettingPopup.ID = "pop_preferenceSetting";
PreferenceSettingPopup.key = "PR";

/**
 * 개별 페이지의  Data정의
 */
PreferenceSettingPopup._initModel=function()
{
	this._data = {
		buttonList:[
			{id:"btn_PR_cancel",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PR_cancel",	offImg:Img["BTN_150_34_OFF"],	pressImg:Img["BTN_150_34_PRESS"]}	},
			{id:"btn_PR_confirm",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PR_confirm",	offImg:Img["BTN_150_34_OFF"],	pressImg:Img["BTN_150_34_PRESS"]}	},
			{id:"btn_PR_title_delete",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PR_title_delete",	offImg:Img["BTN_150_34_OFF"],	pressImg:Img["BTN_150_34_PRESS"]}	},
			{id:"btn_PR_url_delete",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PR_url_delete",	offImg:Img["BTN_150_34_OFF"],	pressImg:Img["BTN_150_34_PRESS"]}	},
			{id:"btn_PR_csIndex_delete",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PR_csIndex_delete",	offImg:Img["BTN_150_34_OFF"],	pressImg:Img["BTN_150_34_PRESS"]}	}
		],
		imageList:[
			{id:"img_PR_bg",	src:Img["IMG_PR_BG"]},
			{id:"img_PR_banner",src:Img["IMG_BOTTOM_BANNER"]}
		],
		textList:[
			{id:"lbl_PR_title",text:Msg.PreferenceSettingPopup.TITLE},									//환경설정
			{id:"lbl_PR_cancel",text:Msg.PreferenceSettingPopup.CANCEL_BTN_LABEL},						//취소
			{id:"lbl_PR_confirm",text:Msg.PreferenceSettingPopup.CONFIRM_BTN_LABEL},					//설정
			{id:"lbl_PR_title_delete",text:Msg.PreferenceSettingPopup.DELETE_BTN_LABEL},				//주소삭제
			{id:"lbl_PR_url_delete",text:Msg.PreferenceSettingPopup.DELETE_BTN_LABEL},					//주소삭제
			{id:"lbl_PR_lstDisplayLimit",text:Msg.PreferenceSettingPopup.LST_DISPLIMIT_LABEL},			//리스트 표시 제한:
			{id:"lbl_PR_resptimeDisplayLimit",text:Msg.PreferenceSettingPopup.RESPTIME_LIMIT_LABEL},	//수신시간 표시 제한:
			{id:"lbl_PR_titleBarName",text:Msg.PreferenceSettingPopup.TITBAR_NAME_LABEL},				//타이틀 바 제목명:
			{id:"lbl_PR_connectionTimeLimit",text:Msg.PreferenceSettingPopup.CONNECTTIME_LIMIT_LABEL},	//연결 제한 시간:
			{id:"lbl_PR_lstBarDisplay",text:Msg.PreferenceSettingPopup.LSTBAR_DISP_LABEL},				//리스트 바로 표시:
			{id:"lbl_PR_serverURL",text:Msg.PreferenceSettingPopup.SERVER_URL_LABEL},					//Server주소(URL):
			{id:"lbl_PR_defaultBtnSetting",text:Msg.PreferenceSettingPopup.DFT_BTNSETTING_LABEL},		//초기 버튼 설정 값 지정:
			{id:"lbl_PR_displayColorUsage",text:Msg.PreferenceSettingPopup.COLORUSAGE_DISP_LABEL},		//Color사용량 보이기:
			{id:"lbl_PR_deleteAfterPrintMode",text:Msg.PreferenceSettingPopup.AFT_DELMODE_LABEL},		//프린트한 후 삭제의 초기 설정:
			{id:"lbl_PR_lstListAutoSelect",text:Msg.PreferenceSettingPopup.LIST_AUTO_SELECT_LABEL},		//리스트 자동 선택: //SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
			{id:"lbl_PR_lstListSortSelect",text:Msg.PreferenceSettingPopup.LIST_SORT_SELECT_LABEL},		//리스트 정렬 선택:
			{id:"lbl_PR_csIndex",text:Msg.PreferenceSettingPopup.CS_INDEX_SET},
			{id:"lbl_PR_csIndex_delete",text:Msg.PreferenceSettingPopup.DELETE_BTN_LABEL},				//주소삭제 CS_INDEX_SET
			
			/********************************************** pulldown item *******************************/
			{id:"pul_PR_lstDisplayLimit0",text:glbInfo.prefrenceSetting.JOB_LIST_COUNT[0].text},
			{id:"pul_PR_lstDisplayLimit1",text:glbInfo.prefrenceSetting.JOB_LIST_COUNT[1].text},
			{id:"pul_PR_resptimeDisplayLimit0",text:glbInfo.prefrenceSetting.TIME_TYPE[0].text},
			{id:"pul_PR_resptimeDisplayLimit1",text:glbInfo.prefrenceSetting.TIME_TYPE[1].text},
			{id:"pul_PR_lstBarDisplay0",text:glbInfo.prefrenceSetting.SKIP[0].text},
			{id:"pul_PR_lstBarDisplay1",text:glbInfo.prefrenceSetting.SKIP[1].text},
			{id:"pul_PR_defaultBtnSetting0",text:glbInfo.prefrenceSetting.BUTTON_DEFAULT[0].text},
			{id:"pul_PR_defaultBtnSetting1",text:glbInfo.prefrenceSetting.BUTTON_DEFAULT[1].text},
			{id:"pul_PR_defaultBtnSetting2",text:glbInfo.prefrenceSetting.BUTTON_DEFAULT[2].text},
			{id:"pul_PR_defaultBtnSetting3",text:glbInfo.prefrenceSetting.BUTTON_DEFAULT[3].text},
			{id:"pul_PR_defaultBtnSetting4",text:glbInfo.prefrenceSetting.BUTTON_DEFAULT[4].text},//2017.01.05 초기 버튼 설정 auto 추가
			{id:"pul_PR_displayColorUsage0",text:glbInfo.prefrenceSetting.COLOR_DISPLAY[0].text},
			{id:"pul_PR_displayColorUsage1",text:glbInfo.prefrenceSetting.COLOR_DISPLAY[1].text},
			{id:"pul_PR_deleteAfterPrintMode0",text:glbInfo.prefrenceSetting.DELETE[0].text},
			{id:"pul_PR_deleteAfterPrintMode1",text:glbInfo.prefrenceSetting.DELETE[1].text},
			{id:"pul_PR_lstListAutoSelect0",text:glbInfo.prefrenceSetting.LIST_AUTO_SELECT[0].text},//SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
			{id:"pul_PR_lstListAutoSelect1",text:glbInfo.prefrenceSetting.LIST_AUTO_SELECT[1].text}, //SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
			{id:"pul_PR_lstListSortSelect0",text:glbInfo.prefrenceSetting.LIST_SORT_ASC[0].text},
			{id:"pul_PR_lstListSortSelect1",text:glbInfo.prefrenceSetting.LIST_SORT_ASC[1].text}
		]
	};
};

/**
 * 개별 페이지 고유의 항목을 구성
 */
PreferenceSettingPopup._initOthers = function(){
	//this._initPullDown("PS");		//PullDown을 구성
	//setEvent
	var tbxTitBarName = document.getElementById("tbx_PR_titleBarName")
		//tbxTitBarName.onfocus = function(){this.blur();};
	var tbxConTimeLimit = document.getElementById("tbx_PR_connectionTimeLimit");
		//tbxConTimeLimit.onfocus=function(){this.blur();};
		tbxConTimeLimit.onchange = function(){
			//var _min=5,_max=999,_default=10;
			var _min = CON_TIMEOUT.Min,
				_max = CON_TIMEOUT.Max,
				_default = CON_TIMEOUT.Default;
	
			var pattern  = /^[0-9]+$/;
			var tmp = parseInt(this.value);
			if(pattern.test(this.value)&!isNaN(tmp)){
				if(tmp < _min){
					this.value = _min;
				}
				else if(tmp > _max){
					this.value = _max;
				}
			}
			else{
				//this.value="";
				this.value=_default;
			}
			//var pattern  = /^[5-9]|[1-9][0-9]{0,2}$/; if(pattern.test(this.value)){ this.value=""; }
		};
	var _lbl = document.getElementById("lbl_PR_connectionTimeLimit_Guide");
		_lbl.innerHTML = "(" + CON_TIMEOUT.Min + "&nbsp;-&nbsp;" + CON_TIMEOUT.Max + ")";
		
	var tbxServerURL = document.getElementById("tbx_PR_serverURL");
		//tbxServerURL.onfocus=function(){this.blur();};
		tbxServerURL.onchange=function(){ 
			//var pattern  = /^(https?:(\/\/)+[a-zA-Z0-9:_\\\.&]*)$/;
			var pattern  = /^(https?:(\/\/)+[a-zA-Z0-9:_\\\.&]*)(:[0-9]+)?\//;
			if(!pattern.test(this.value)){
				//this.value="";
				this.value = gProtocol;
			}
		};
	var tbxCsInstallIndex = document.getElementById("tbx_PR_csIndex");
};

PreferenceSettingPopup._onPageChange = function (e, args){
	this.updateDisplay();
};

PreferenceSettingPopup.onChangeEventHandler = function(e, args){
	//console.log(e);
};

/**
 * 화면 표시의 갱신 (공통/화면전환시에 호출된다.)
 */
PreferenceSettingPopup.updateDisplay = function(){
	KISUtil.debug("function:","updateDisplay");
	var lst = [
		{id:"pul_PR_lstDisplayLimit0",value:glbInfo.prefrenceSetting.JOB_LIST_COUNT[0].value},
		{id:"pul_PR_lstDisplayLimit1",value:glbInfo.prefrenceSetting.JOB_LIST_COUNT[1].value},
		{id:"pul_PR_resptimeDisplayLimit0",value:glbInfo.prefrenceSetting.TIME_TYPE[0].value},
		{id:"pul_PR_resptimeDisplayLimit1",value:glbInfo.prefrenceSetting.TIME_TYPE[1].value},
		{id:"pul_PR_lstBarDisplay0",value:glbInfo.prefrenceSetting.SKIP[0].value},
		{id:"pul_PR_lstBarDisplay1",value:glbInfo.prefrenceSetting.SKIP[1].value},
		{id:"pul_PR_defaultBtnSetting0",value:glbInfo.prefrenceSetting.BUTTON_DEFAULT[0].value},
		{id:"pul_PR_defaultBtnSetting1",value:glbInfo.prefrenceSetting.BUTTON_DEFAULT[1].value},
		{id:"pul_PR_defaultBtnSetting2",value:glbInfo.prefrenceSetting.BUTTON_DEFAULT[2].value},
		{id:"pul_PR_defaultBtnSetting3",value:glbInfo.prefrenceSetting.BUTTON_DEFAULT[3].value},//2017.01.05 초기 버튼 설정 auto 추가
		{id:"pul_PR_defaultBtnSetting4",value:glbInfo.prefrenceSetting.BUTTON_DEFAULT[4].value},//2017.01.05 초기 버튼 설정 auto 추가
		{id:"pul_PR_displayColorUsage0",value:glbInfo.prefrenceSetting.COLOR_DISPLAY[0].value},
		{id:"pul_PR_displayColorUsage1",value:glbInfo.prefrenceSetting.COLOR_DISPLAY[1].value},
		{id:"pul_PR_deleteAfterPrintMode0",value:glbInfo.prefrenceSetting.DELETE[0].value},
		{id:"pul_PR_deleteAfterPrintMode1",value:glbInfo.prefrenceSetting.DELETE[1].value},
		{id:"pul_PR_lstListAutoSelect0", value:glbInfo.prefrenceSetting.LIST_AUTO_SELECT[0].value},//SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
		{id:"pul_PR_lstListAutoSelect1", value:glbInfo.prefrenceSetting.LIST_AUTO_SELECT[1].value}, //SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
		{id:"pul_PR_lstListSortSelect0",value:glbInfo.prefrenceSetting.LIST_SORT_ASC[0].value},
		{id:"pul_PR_lstListSortSelect1",value:glbInfo.prefrenceSetting.LIST_SORT_ASC[1].value}
	];
	var item;
	for(var i=0,iMax=lst.length;i<iMax;i++){
		item=lst[i];
		document.getElementById(item.id).value=item.value;
	}
	
	Common.setIndex("pul_PR_lstDisplayLimit",Common.getIndex(glbInfo.prefrenceSetting.JOB_LIST_COUNT,glbConfig.DATA.JOB_LIST_COUNT));
	Common.setIndex("pul_PR_resptimeDisplayLimit",Common.getIndex(glbInfo.prefrenceSetting.TIME_TYPE,glbConfig.DATA.TIME_TYPE));
	if(glbConfig.DATA.TITLE_NAME&&glbConfig.DATA.TITLE_NAME.length>0) Common.setText("tbx_PR_titleBarName",glbConfig.DATA.TITLE_NAME);
	if(glbConfig.DATA.TIMEOUT&&glbConfig.DATA.TIMEOUT.toString().length>0) Common.setText("tbx_PR_connectionTimeLimit",glbConfig.DATA.TIMEOUT);
	Common.setIndex("pul_PR_lstBarDisplay",Common.getIndex(glbInfo.prefrenceSetting.SKIP,glbConfig.DATA.SKIP));
	Common.setIndex("pul_PR_defaultBtnSetting",Common.getIndex(glbInfo.prefrenceSetting.BUTTON_DEFAULT,glbConfig.DATA.BUTTON_DEFAULT));
	Common.setIndex("pul_PR_displayColorUsage",Common.getIndex(glbInfo.prefrenceSetting.COLOR_DISPLAY,glbConfig.DATA.COLOR_DISPLAY));

	//if(glbConfig.DATA.SERVER_URL&&glbConfig.DATA.SERVER_URL.length>0) Common.setText("tbx_PR_serverURL",glbConfig.DATA.SERVER_URL);
	if(glbConfig.DATA.SERVER_URL && glbInfo.SERVER_NUM > 0){//SmartUI 2017.02 복수의 Print Server 대응 refs #4184
		Common.setText("tbx_PR_serverURL", glbConfig.DATA.SERVER_URL[0]);
	}

	Common.setIndex("pul_PR_deleteAfterPrintMode",Common.getIndex(glbInfo.prefrenceSetting.DELETE,glbConfig.DATA.DELETE));
	Common.setIndex("pul_PR_lstListAutoSelect", Common.getIndex(glbInfo.prefrenceSetting.LIST_AUTO_SELECT, glbConfig.DATA.LIST_AUTO_SELECT));//SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
	Common.setIndex("pul_PR_lstListSortSelect",Common.getIndex(glbInfo.prefrenceSetting.LIST_SORT_ASC,glbConfig.DATA.LIST_SORT_ASC));

	if(glbInfo.SpecifyIndex == 0){
		Common.setText("tbx_PR_csIndex",glbConfig.DATA.CS_INSTALL_INDEX);
	}else{
		Common.setText("tbx_PR_csIndex",glbInfo.SpecifyIndex);
	}
};

/**
 * 개별 페이지의 Event처리
 * @param {string} event : Event의 종류
 * @param {string} id : Event발생원
 */
PreferenceSettingPopup.EventHandler = function(event, id)
{
	KISUtil.debug("EventHandler","event:"+event+"/id:"+id);
	switch(event){
		case "onbuttonup":
			MessageManager.clearMessageArea();
			BrowserExt.Beep(0);
			switch(id)
			{
				case "btn_PR_cancel":
					PageManager.changePage(PageManager.getPrevPage(),PageManager.type.CANCEL);
					break;
				case "btn_PR_confirm":
					//widget으로 등록하지 않았으므로
					//컨펌 직전에 데이터를 반영해야함
					var setting = this.getSetting();
					//console.log(setting);
					glbConfig.DATA = Extend(glbConfig.DATA, setting);
					//save setting
					var _contents = "var DATA = " + JSON.stringify(setting);
					KISUtil.debug(_contents);
					save_content_to_file(_contents, PREFERENCE_DATA_LOC);
					eval(_contents);
					//PageManager.changePage(PageManager.getPrevPage(),PageManager.type.CONFIRM);
					PageManager.changePage(MenuPage,PageManager.type.CONFIRM);
					break;
				case "btn_PR_title_delete":
					Common.setText("tbx_PR_titleBarName","");
					break;
				case "btn_PR_url_delete":
					Common.setText("tbx_PR_serverURL","");
					break;
				case "btn_PR_csIndex_delete":
					Common.setText("tbx_PR_csIndex","");
					break;
				default:
					//clearMessageAreaTimer();
					break;
			}
			break;
		case "onhardkeydown":
			MessageManager.clearMessageArea();
			switch(id)
			{
				//case BrowserExt.keyCode.FX_VK_START:
				//case BrowserExt.keyCode.FX_VK_CLEAR:
				case BrowserExt.keyCode.FX_VK_PAUSE:
					break;
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		default:
			break;
	}
};
PreferenceSettingPopup.getSetting = function(){
	var setting = {};
	var obj = document.getElementById("pul_PR_lstDisplayLimit");
	setting.JOB_LIST_COUNT = parseInt(obj.options[obj.selectedIndex].value); 
	obj = document.getElementById("pul_PR_resptimeDisplayLimit");
	setting.TIME_TYPE = parseInt(obj.options[obj.selectedIndex].value);
	setting.TITLE_NAME = document.getElementById("tbx_PR_titleBarName").value;
	setting.TIMEOUT = parseInt(document.getElementById("tbx_PR_connectionTimeLimit").value);
	obj = document.getElementById("pul_PR_lstBarDisplay");
	setting.SKIP = parseInt(obj.options[obj.selectedIndex].value);
	obj = document.getElementById("pul_PR_defaultBtnSetting");
	setting.BUTTON_DEFAULT = obj.options[obj.selectedIndex].value;
	obj = document.getElementById("pul_PR_displayColorUsage");
	setting.COLOR_DISPLAY = parseBool(obj.options[obj.selectedIndex].value);

	//SmartUI 2017.02 복수의 Print Server 대응 refs #4184
	//setting.SERVER_URL = document.getElementById("tbx_PR_serverURL").value;
	setting.SERVER_URL = glbConfig.DATA.SERVER_URL;
	setting.SERVER_URL[0] = document.getElementById("tbx_PR_serverURL").value;

	obj = document.getElementById("pul_PR_deleteAfterPrintMode");
	setting.DELETE = obj.selectedIndex;
	setting.UPDATE_DELAY_TIME = glbConfig.DATA.UPDATE_DELAY_TIME;//SmartUI 2.0 Enhance 2015.05
	obj = document.getElementById("pul_PR_lstListAutoSelect");//SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
	setting.LIST_AUTO_SELECT = obj.selectedIndex;//SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
	setting.NAME_DISPLAY_SELECT = glbConfig.DATA.NAME_DISPLAY_SELECT; //#4196 User Display 사양에 따른 추가 관리자 설정 화면에 포함하지 않음.
	obj = document.getElementById("pul_PR_lstListSortSelect");
	setting.LIST_SORT_ASC = parseBool(obj.options[obj.selectedIndex].value);
	setting.CS_INSTALL_INDEX = parseInt(document.getElementById("tbx_PR_csIndex").value);
	return setting;
};
/**
 * 풀다운 닫기 처리용 메소드
 * templatePage.js로부터 이동
 */
PreferenceSettingPopup.onPageClick = function(){
	switch(WidgetLib._popupId)
	{
		case "pul_PR_color_popup":
		case "pul_PR_plex_popup":
		case "pul_PR_nup_popup":
			WidgetLib.closePopupWidget(WidgetLib._popupId);
			MessageManager.clearMessageArea();
			break;
		default:
			break;
	}
};