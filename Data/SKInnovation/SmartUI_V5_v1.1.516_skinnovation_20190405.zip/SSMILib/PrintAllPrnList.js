﻿/**
 * PrintAll インスタンスを作成する
 * @constructor
 * @extends XMLLib.SOAPMsg
 * @class  ボックス文書を扱うためのクラス<br>
 * <a href="XMLLib.SOAPMsg.html#">XMLLib.SOAPMsg</a>のサブクラス
 * @lang ja
 */
/**
 * Creates All instance.
 * @constructor
 * @extends XMLLib.SOAPMsg
 * @class Class for handling Mailbox documents.<br>
 * Subclass of <a href="XMLLib.SOAPMsg.html#">XMLLib.SOAPMsg</a>.
 * @lang en
 */
SSMILib.AllPrnInfo = function()
{
	this.userId = "";
	this.deviceIp = "";
	this.wsIp = "";
};
/**
 * @private
 */
Extend(SSMILib.AllPrnInfo.prototype, XMLLib.SOAPMsg.prototype);

/**
 * @private
 */
SSMILib.AllPrnInfo.prototype.createMsg = function()
{
	var xml = new XMLLib.XMLSOAP();
	var root = xml.createSOAPEnvelope();
	var env = root;
	var body = xml.body;
	xml.nss.nss = [];//namespace초기화	

	var soapNS="http://schemas.xmlsoap.org/soap/envelope/";
	var webNS="http://webservice.print.mfd.anyguard.kor.fujixerox.com/";
	
	xml.addNSPrefix(soapNS, "soapenv");
	xml.addNSPrefix(webNS, "web");
	
	var sdNode = xml.createElement("web:" + this.type );
	
	xml.addNSDeclaration(soapNS, root, true);
	xml.addNSDeclaration(webNS, root, true);
	
	var itNode = xml.createElement("userId");
	itNode.appendChild(xml.createTextNode(this.userId));
	sdNode.appendChild(itNode);

	itNode = xml.createElement("deviceIp");
	itNode.appendChild(xml.createTextNode(this.deviceIp));
	sdNode.appendChild(itNode);

	itNode = xml.createElement("wsIp");
	itNode.appendChild(xml.createTextNode(this.wsIp));
	sdNode.appendChild(itNode);

	itNode = xml.createElement("deviceColor");
	itNode.appendChild(xml.createTextNode(this.deviceColor));
	sdNode.appendChild(itNode);

	body.appendChild(sdNode);
	env.appendChild(body);

	var soapMsg = xml.rootElement;
	return soapMsg;
};

/**
 * ボックス文書の情報を取得する<br>
 * 取得に成功すると、文書の情報をプロパティとしてもつオブジェクトが配列で返る。
 * プロパティ詳細については「01-01 SESAMi Service Management Interface Specification.doc」を参照
 * @param	{SSMILib.AllPrnInfo}	sdObj	文書取得用のオブジェクトを指定する
 * @param	{Int}	timeout		通信のタイムアウト値を指定する
 * @addon
 * @static
 * @lang ja
 */
/**
 * Retrieves Mailbox document information.<br>
 * If retrieval is successful, object with document information as properties is returned.
 * See "01-01 SESAMi Service Management Interface Specification.doc" for document attribute details.
 * @param	{SSMILib.AllPrnInfo}	sdObj	Object for retrieving document information
 * @param	{Int}	timeout		Communication timeout
 * @addon
 * @static
 * @lang en
 */
SSMILib.PrintAll = function(sdObj, timeout, remoteHost)//SmartUI 2017.02 복수의 Print Server 대응 refs #4184
{
	var _ws = new WebServiceLib.Communicator();

	_ws.async = SSMILib.async;
	_ws.successHandler = SSMILib.PrintAll.gsdSuccessCb;
	_ws.errorHandler = SSMILib.PrintAll.gsdErrorCb;

	if(timeout){
		_ws.timeout = timeout;
		_ws.timeoutHandler = SSMILib.PrintAll.gsdErrorCb;
	}

	var soapAction = "{http://webservice.print.ws.anyguard.kor.fujixerox.com/}PrintAllWebService";
	_ws.soapAction = soapAction;
	_ws.isDeviceReq = true;

	//var _targetURL = glbConfig.remoteHost + "PrintAll";//SmartUI 2017.02 복수의 Print Server 대응 refs #4184
	var _targetURL = remoteHost + "PrintAll";

	if (SSMILib.dummy) {
		var _docBox = null;
		//TODO Need to define dummy data
		SSMILib.onEvent("PrintAll", true, _docBox);
		return;
	}
	var _sdObj = sdObj || new SSMILib.AllPrnInfo();
	_sdObj.type = "PrintAll";
	var _msg = _sdObj.serializeToString();
	//KISUtil.debug("PrintAll/send",_msg);
	//KISUtil.debug("PrintAll/_targetURL",_targetURL);
	_ws.send(_targetURL, _msg);
};

/**
 * @private
 */
SSMILib.PrintAll.gsdSuccessCb = function(res)
{
	//KISUtil.debug("PrintAll.gsdErrorCb",res.responseText);
	var resObj = null;
	var _result = false;

	if(!res.responseXML) {
		SSMILib.onEvent("PrintAll", _result, _docList);
		return;
	}

	var _gsdrNode = res.responseXML.getElementsByTagName("return");
		//_gsdrNode : PrintAllResult
	if(_gsdrNode.length && _gsdrNode[0].hasChildNodes()){
		resObj = Common.xmlToJson(_gsdrNode[0]);
		_result = true;
		//console.log("resObj.status:"+resObj.status);
	}

	SSMILib.onEvent("PrintAll", _result, resObj);
};

/**
 * @private
 */
SSMILib.PrintAll.gsdErrorCb = function(res)
{
	//KISUtil.debug("PrintAll.gsdErrorCb", res.responseText);
	var _result = false;
	var soapFaultObj = null;
	if(res.responseXML){
		var _gsdrNode = res.responseXML.getElementsByTagName("soap:Fault");
			//_gsdrNode : GetUsagePrnCntResult
		if(_gsdrNode.length && _gsdrNode[0].hasChildNodes()){
			 soapFaultObj = (Common.xmlToJson)?Common.xmlToJson(_gsdrNode[0]):_gsdrNode[0].textContent;
		}
	}
	SSMILib.onEvent("PrintAll", _result, soapFaultObj);
};