﻿var Img = {
		////ICON
		SERVICE_ICON : "./image/SmartWhere_32x32.png",
		ALERT_ICON : "./image/IC_AL_01.png",
		INFORMATION_ICON : "./image/IC_IN_01.png",
		EMPTY_ICON : "./image/IC_ET_01.png",
		USER_ICON : "./image/IC_US_24.png",
		USER_ICON_CE : "./image/IC_CE_24.png",
		//プリント指示中 Pop-up Indicator
		PRINTING_PROGRESS_INDICATOR : "./image/Activity-Indicator_240-20.gif",

		//new
		IMG_MP_BG:"./skin/CS-GUI_Main_800x440.png",
		IMG_BOTTOM_BANNER:"./skin/bottom_banner.png",
		IMG_POPUP_ERROR_BG:"./image/CS-GUI-Error_800x440.png",
		IMG_SOFT_CORE_KEYPAD_BG:"./image/soft_core_keypad.png",
		
		// ECO Function
		IMG_CO2_CAMPAIGN:"./skin/co2_campaign_banner.png",
		ICN_CO2_ICON:"./skin/carbon_icon.png",
		
		// Soft core keypad
		BTN_SCK_AUTH_PRESS: "./image/btn_auth_key_press.png",
		BTN_SCK_AUTH_OFF: "./image/btn_auth_key_off.png",
		BTN_SCK_NUM_PRESS: "./image/btn_num_key_press.png",
		BTN_SCK_NUM_OFF: "./image/btn_num_key_off.png",
		
		BTN_SCK_MUL_OFF: "./image/btn_mul_key_off.png",
		BTN_SCK_SHARP_OFF: "./image/btn_sharp_key_off.png",
		BTN_SCK_PAUSE_OFF: "./image/btn_pause_key_off.png",
		BTN_SCK_COMEBACK_OFF: "./image/btn_comeback_key_off.png",
		BTN_SCK_SHORTEN_OFF: "./image/btn_shorten_key_off.png",
		
		BTN_SCK_MENU_OFF: "./image/btn_menu_key_off.png",
		BTN_SCK_STOP_OFF: "./image/btn_stop_key_off.png",
		BTN_SCK_MENU_STOP_PRESS: "./image/btn_menu_stop_key_press.png",
		BTN_SCK_START_OFF: "./image/btn_start_key_off.png",
		BTN_SCK_START_PRESS: "./image/btn_start_key_press.png",

		//チェックボックス用
		CHK_OFF :	"./image/BZ_CS3_1.png",
		CHK_PRESS :	"./image/BZ_CS3_2.png",
		CHK_ON :	"./image/BZ_CS3_3.png",
	
		//popup
		IMG_POPUP_BG :	"./image/IM_BK13_1.png",
		BTN_CONFIRM_OFF :	"./image/B_CM04_1.png",
		BTN_CONFIRM_PRESS :	"./image/B_CM04_2.png",
		BTN_CONFIRM_DIS :	"./image/B_CM04_4.png",
		BTN_CANCEL_OFF :	"./image/B_CM05_1.png",
		BTN_CANCEL_PRESS :	"./image/B_CM05_2.png",
		BTN_CANCEL_DIS :	"./image/B_CM05_4.png",
		//BTN_CANCEL_OFF :	"./image/BI_TC_11.png",
		//BTN_CANCEL_PRESS :	"./image/BI_TC_12.png",
		//BTN_CANCEL_DIS :	"./image/BI_TC_14.png",
		BTN_CLOSE_OFF :	"./image/B_CM04_1.png",
		BTN_CLOSE_PRESS :	"./image/B_CM04_2.png",
		BTN_CLOSE_DIS :	"./image/B_CM04_4.png",
		
		//error Popup
		IMG_POPUP_ERROR_BG :	"./image/IM_BK_PO02_1.png",
		
		//warn Popup
		IMG_POPUP_WARN_BG :	"./image/IM_BK_PO01_1.png",
		
		//message Area
		MESSAGE_AREA_BG :	"./image/IM_SP.png",
		
		//エラー通知ポップアップ用button
		BTN_ERROR_OFF :	"./image/BX_C2E_1.png",
		BTN_ERROR_PRESS :	"./image/BX_C2E_2.png",
		BTN_ERROR_DIS :	"./image/BX_C2E_4.png",


		////공통
		//버튼 이미지
		POPUP_YELLOW_CLOSE_BTN_OFF : "./image/Popup_Y_Close_Off.png",
		POPUP_YELLOW_CLOSE_BTN_PRESS : "./image/Popup_Y_Close_Press.png",
		BTN_150_34_OFF : "./image/Com_150-34_Off.png",
		BTN_150_34_PRESS : "./image/Com_150-34_Press.png",
		//部数入力ボックス
		TEXT_INPUT_BOX_ENABLE : "./image/T_ET01_3.png",
		TEXT_INPUT_BOX_DIS : "./image/T_NE01.png",
		//Pull-down background image
		PULLDOWN_BACKGROUND_3_ROW : "./image/G_PM09.png",
		PULLDOWN_BACKGROUND_2_ROW : "./image/G_PM09.png",
		//Pop-up Background image
		POPUP_BLUE_BACKGROUND_IMG : "./image/Popup_Blue_800-440.png",
		POPUP_RED_BACKGROUND_IMG : "./image/Popup_Red_800-440.png",
		POPUP_YELLOW_BACKGROUND_IMG : "./image/Popup_Yellow_800-440.png",

		////개별페이지
		//메뉴화면
		IMG_MP_REFRESH_OFF : "./image/off_refresh.png", 
		IMG_MP_REFRESH_PRESS : "./image/press_refresh.png",
		IMG_MP_REFRESH_DIS : "./image/disable_refresh.png",

		//문서리스트화면 
		//Background image
		FILE_LIST_BACKGROUND_IMG : "./image/FF_PP_440.png",
		//Command button
		FILE_LIST_COMMAND_BTN_OFF : "./image/B_CM02_1.png",
		FILE_LIST_COMMAND_BTN_PRESS : "./image/B_CM02_2.png",
		FILE_LIST_COMMAND_BTN_DIS : "./image/B_CM02_4.png",
		//上ボタン、下ボタン
		FILE_LIST_UP_BTN_OFF : "./image/B_PG01_1.png",
		FILE_LIST_UP_BTN_PRESS : "./image/B_PG01_2.png",
		FILE_LIST_UP_BTN_DIS : "./image/B_PG01_4.png",
		FILE_LIST_DOWN_BTN_OFF : "./image/B_PG02_1.png",
		FILE_LIST_DOWN_BTN_PRESS : "./image/B_PG02_2.png",
		FILE_LIST_DOWN_BTN_DIS : "./image/B_PG02_4.png",
		//文書選択ボタン
		FILE_LIST_BUTTON_OFF : "./image/BX_CB_01.png",
		FILE_LIST_BUTTON_PRESS : "./image/BX_CB_02.png",
		FILE_LIST_BUTTON_ON : "./image/BX_CB_03.png",
		FILE_LIST_BUTTON_SELECTED : "./image/BX_CB_05.png",
		//すべて選択ボタン
		SELECT_ALL_BTN_OFF : "./image/BI_CA_01.png",
		SELECT_ALL_BTN_PRESS : "./image/BI_CA_02.png",
		SELECT_ALL_BTN_ON : "./image/BI_CA_03.png",
		SELECT_ALL_BTN_DIS : "./image/BI_CA_04.png",
		//削除ボタン
		DELETE_FILE_BTN_OFF : "./image/BI_CD_01.png",
		DELETE_FILE_BTN_PRESS : "./image/BI_CD_02.png",
		DELETE_FILE_BTN_DIS : "./image/BI_CD_04.png",
		//表示更新ボタン
		DISPLAY_CHANGE_BTN_OFF : "./image/BI_CR_01.png",
		DISPLAY_CHANGE_BTN_PRESS : "./image/BI_CR_02.png",
		DISPLAY_CHANGE_BTN_DIS : "./image/BI_CR_04.png",
	
		//print setting popup
		IMG_PS_BG : "./image/Popup_Gray_800-440.png",
		ICN_PS_TITLE : "./image/I_FT510_1.png",
		BG_PS_INFODISPLAY : "./image/F_TB_550_64.png",
		ICN_PS_INFODISPLAY : "./image/IC_IN_01.png",
		ICN_PRIVATE_PRINT : "./image/I_SM301_1.png",
			
		PUL_PS_BASE_OFF:"./image/BI_PC_1.png",
		PUL_PS_BASE_PRESS:"./image/BI_PC_2.png",
		PUL_PS_BASE_ON:"./image/BI_PC_3.png",
		PUL_PS_BASE_DIS:"./image/BI_PC_4.png",
		
		PUL_PS_POPUP_BG_TOP:"./image/G_PM_01.png",
		PUL_PS_POPUP_BG_MID:"./image/G_PM_02.png",
		PUL_PS_POPUP_BG_BOT:"./image/G_PM_03.png",
		
		BTN_PS_BASE_OFF:"./image/BI_MC_1.png",
		BTN_PS_BASE_PRESS:"./image/BI_MC_2.png",
		BTN_PS_BASE_ON:"./image/BI_MC_3.png",
		BTN_PS_BASE_DIS:"./image/BI_MC_4.png",
		
		CBX_PS_AFTER_PRN_DELETE_OFF: "./image/BZ_CS3_1.png",
		CBX_PS_AFTER_PRN_DELETE_PRESS: "./image/BZ_CS3_2.png",
		CBX_PS_AFTER_PRN_DELETE_ON: "./image/BZ_CS3_3.png",
		CBX_PS_AFTER_PRN_DELETE_DIS: "./image/BZ_CS3_4.png",
		CBX_PS_AFTER_PRN_DELETE_ONDIS: "./image/BZ_CS3_5.png",
		
		PUL_PS_COLORMODE0_OFF : "./image/BI_PC_B1.png",
		PUL_PS_COLORMODE0_PRESS : "./image/BI_PC_B2.png",
		PUL_PS_COLORMODE0_ON : "./image/BI_PC_B3.png",
	
		PUL_PS_COLORMODE1_OFF : "./image/BI_PC_C1.png",
		PUL_PS_COLORMODE1_PRESS : "./image/BI_PC_C2.png",
		PUL_PS_COLORMODE1_ON : "./image/BI_PC_C3.png",
		
		IMG_PS_COLORMODE0_OFF : "./image/BI_MC_B1.png",
		IMG_PS_COLORMODE0_PRESS : "./image/BI_MC_B2.png",
		IMG_PS_COLORMODE0_ON : "./image/BI_MC_B3.png",
		
		IMG_PS_COLORMODE1_OFF : "./image/BI_MC_C1.png",
		IMG_PS_COLORMODE1_PRESS : "./image/BI_MC_C2.png",
		IMG_PS_COLORMODE1_ON : "./image/BI_MC_C3.png",
		
		PUL_PS_OUTPLEX0_OFF : "./image/BI_PD_11.png",
		PUL_PS_OUTPLEX0_PRESS : "./image/BI_PD_12.png",
		PUL_PS_OUTPLEX0_ON : "./image/BI_PD_13.png",
		
		PUL_PS_OUTPLEX1_OFF : "./image/BI_PD_21.png",
		PUL_PS_OUTPLEX1_PRESS : "./image/BI_PD_22.png",
		PUL_PS_OUTPLEX1_ON : "./image/BI_PD_23.png",
		
		PUL_PS_OUTPLEX2_OFF : "./image/BI_PD_31.png",
		PUL_PS_OUTPLEX2_PRESS : "./image/BI_PD_32.png",
		PUL_PS_OUTPLEX2_ON : "./image/BI_PD_33.png",
		
		IMG_PS_OUTPLEX0_OFF : "./image/BI_MD_11.png",
		IMG_PS_OUTPLEX0_PRESS : "./image/BI_MD_12.png",
		IMG_PS_OUTPLEX0_ON : "./image/BI_MD_13.png",
		
		IMG_PS_OUTPLEX1_OFF : "./image/BI_MD_21.png",
		IMG_PS_OUTPLEX1_PRESS : "./image/BI_MD_22.png",
		IMG_PS_OUTPLEX1_ON : "./image/BI_MD_23.png",
		
		IMG_PS_OUTPLEX2_OFF : "./image/BI_MD_31.png",
		IMG_PS_OUTPLEX2_PRESS : "./image/BI_MD_32.png",
		IMG_PS_OUTPLEX2_ON : "./image/BI_MD_33.png",
		
		PUL_PS_NUP0_OFF : "./image/BI_PE_11.png",
		PUL_PS_NUP0_PRESS : "./image/BI_PE_12.png",
		PUL_PS_NUP0_ON : "./image/BI_PE_13.png",
	
		PUL_PS_NUP1_OFF : "./image/BI_PE_21.png",
		PUL_PS_NUP1_PRESS : "./image/BI_PE_22.png",
		PUL_PS_NUP1_ON : "./image/BI_PE_23.png",
	
		PUL_PS_NUP2_OFF : "./image/BI_PE_31.png",
		PUL_PS_NUP2_PRESS : "./image/BI_PE_32.png",
		PUL_PS_NUP2_ON : "./image/BI_PE_33.png",
	
		PUL_PS_NUP3_OFF : "./image/BI_PE_41.png",
		PUL_PS_NUP3_PRESS : "./image/BI_PE_42.png",
		PUL_PS_NUP3_ON : "./image/BI_PE_43.png",
		
		IMG_PS_NUP0_OFF : "./image/BI_ME_11.png",
		IMG_PS_NUP0_PRESS : "./image/BI_ME_12.png",
		IMG_PS_NUP0_ON : "./image/BI_ME_13.png",
		
		IMG_PS_NUP1_OFF : "./image/BI_ME_21.png",
		IMG_PS_NUP1_PRESS : "./image/BI_ME_22.png",
		IMG_PS_NUP1_ON : "./image/BI_ME_23.png",
		
		IMG_PS_NUP2_OFF : "./image/BI_ME_31.png",
		IMG_PS_NUP2_PRESS : "./image/BI_ME_32.png",
		IMG_PS_NUP2_ON : "./image/BI_ME_33.png",
		
		IMG_PS_NUP3_OFF : "./image/BI_ME_41.png",
		IMG_PS_NUP3_PRESS : "./image/BI_ME_42.png",
		IMG_PS_NUP3_ON : "./image/BI_ME_43.png",
		
		IMG_PS_INFOUP_OFF : "./image/BS2VA1_1.png",
		IMG_PS_INFOUP_PRESS : "./image/BS2VA1_2.png",
		IMG_PS_INFOUP_DIS : "./image/BS2VA1_4.png",
		
		IMG_PS_INFODOWN_OFF : "./image/BS2VA2_1.png",
		IMG_PS_INFODOWN_PRESS : "./image/BS2VA2_2.png",
		IMG_PS_INFODOWN_DIS : "./image/BS2VA2_4.png",
		
		ICN_PS_PLEX_SIMPLEX_OFF : "./image/I_OBU03_11_1.png",
		ICN_PS_PLEX_SIMPLEX_DIS : "./image/I_OBU03_11_4.png",
		
		ICN_PS_PLEX_DUPLEX_OFF : "./image/I_OBU03_13_1.png",
		ICN_PS_PLEX_DUPLEX_DIS : "./image/I_OBU03_13_4.png",
		
		ICN_PS_PLEX_TUMBLE_OFF : "./image/I_OBU03_12_1.png",
		ICN_PS_PLEX_TUMBLE_DIS : "./image/I_OBU03_12_4.png",
		
		/**/
		ICN_PS_CM_COLOR_OFF : "./image/I_OBU03_01_1.png",
		ICN_PS_CM_COLOR_DIS : "./image/I_OBU03_01_4.png",
		
		ICN_PS_CM_GRAY_OFF : "./image/I_OBU03_02_1.png",
		ICN_PS_CM_GRAY_DIS : "./image/I_OBU03_02_4.png",
		
		/**/
		ICN_PS_NUP_1UP_OFF : "./image/I_OBU03_21_1.png",
		ICN_PS_NUP_1UP_DIS : "./image/I_OBU03_21_4.png",
		
		ICN_PS_NUP_2UP_OFF : "./image/I_OBU03_22_1.png",
		ICN_PS_NUP_2UP_DIS : "./image/I_OBU03_22_4.png",
		
		ICN_PS_NUP_4UP_OFF : "./image/I_OBU03_23_1.png",
		ICN_PS_NUP_4UP_DIS : "./image/I_OBU03_23_4.png",
		
		ICN_PS_NUP_8UP_OFF : "./image/I_OBU03_24_1.png",
		ICN_PS_NUP_8UP_DIS : "./image/I_OBU03_24_4.png",
		
		ICN_PS_NUP_16UP_OFF : "./image/I_OBU03_25_1.png",
		ICN_PS_NUP_16UP_DIS : "./image/I_OBU03_25_4.png",
		
		ICN_PS_NUP_32UP_OFF : "./image/I_OBU03_26_1.png",
		ICN_PS_NUP_32UP_DIS : "./image/I_OBU03_26_4.png",
		
		
		IMG_PR_BG : "./image/Popup_Green_800-440.png",
		
		SERVICE_HOME_OFF : "./image/off_service_home.png",
		SERVICE_HOME_PRESS : "./image/press_service_home.png",

		BRIDGE_APP_LOCKED_OFF : "./image/off_bridge_app_locked.png",
		BRIDGE_APP_UNLOCKED_OFF : "./image/off_bridge_app_unlocked.png",
		ECO_COPY_LOCKED_OFF : "./image/off_eco_copy_locked.png",
		ECO_COPY_UNLOCKED_OFF : "./image/off_eco_copy_unlocked.png",
		IPS_LOCKED_OFF : "./image/off_ips_locked.png",
		IPS_SCAN_LOCKED_OFF : "./image/off_ips_scan_locked.png",
		IPS_SCAN_UNLOCKED_OFF : "./image/off_ips_scan_unlocked.png",
		IPS_UNLOCKED_OFF : "./image/off_ips_unlocked.png",
		NATIVE_MENU_LOCKED_OFF : "./image/off_native_menu_locked.png",
		NATIVE_MENU_UNLOCKED_OFF : "./image/off_native_menu_unlocked.png",
		BRIDGE_APP_LOCKED_PRESS : "./image/press_bridge_app_locked.png",
		BRIDGE_APP_UNLOCKED_PRESS : "./image/press_bridge_app_unlocked.png",
		ECO_COPY_LOCKED_PRESS : "./image/press_eco_copy_locked.png",
		ECO_COPY_UNLOCKED_PRESS : "./image/press_eco_copy_unlocked.png",
		IPS_LOCKED_PRESS : "./image/press_ips_locked.png",
		IPS_SCAN_LOCKED_PRESS : "./image/press_ips_scan_locked.png",
		IPS_SCAN_UNLOCKED_PRESS : "./image/press_ips_scan_unlocked.png",
		IPS_UNLOCKED_PRESS : "./image/press_ips_unlocked.png",
		NATIVE_MENU_LOCKED_PRESS : "./image/press_native_menu_locked.png",
		NATIVE_MENU_UNLOCKED_PRESS : "./image/press_native_menu_unlocked.png",
		
		//////////////////
		IMG_RC_BG0 : "./image/CS_GUI_Card_Registration_intro.png",
		IMG_RC_BG1 : "./image/CS_GUI_Card_Registration_idpw.png",
		IMG_RC_BG2 : "./image/CS_GUI_Card_Registration_status.png",

		IMG_RC_OK_OFF:"./image/off_ok.png",
		IMG_RC_OK_PRESS: "./image/press_ok.png",
		IMG_RC_CANCEL_OFF: "./image/off_cancel.png",
		IMG_RC_CANCEL_PRESS: "./image/press_cancel.png",

		PRINT_ALL_BTN_OFF : "./image/BB_PA_01.png",
		PRINT_ALL_BTN_PRESS : "./image/BB_PA_02.png",
		PRINT_ALL_BTN_DIS : "./image/BB_PA_04.png",
		PRINT_BTN_OFF : "./image/BB_PT_01.png",
		PRINT_BTN_PRESS : "./image/BB_PT_02.png",
		PRINT_BTN_DIS : "./image/BB_PT_04.png",
	
		IMG_PS_PRINT_OFF : "./image/BB_PT_01.png",
		IMG_PS_PRINT_PRESS : "./image/BB_PT_02.png",
		IMG_PS_PRINT_DIS : "./image/BB_PT_04.png",

		//Common
		CS_TITLE : "./image/IM_PI01_1.png",
		
		//메뉴화면
		IMG_MP_SETTING_OFF : "./image/off_setting.png", 
		IMG_MP_SETTING_PRESS : "./image/press_setting.png",

		IMG_MP_PROMPT_OFF : "./image/off_prompt_print.png", 
		IMG_MP_PROMPT_PRESS : "./image/press_prompt_print.png",
		IMG_MP_PROMPT_ON : "./image/on_prompt_print.png", 

		IMG_MP_SELECTED_PRINT_OFF : "./image/off_select_print.png", 
		IMG_MP_SELECTED_PRINT_PRESS: "./image/press_select_print.png", 
		IMG_MP_SELECTED_PRINT_ON: "./image/on_select_print.png", 

		IMG_MP_SETUP_OFF : "./image/off_setup.png", 
		IMG_MP_SETUP_PRESS : "./image/press_setup.png",
		IMG_MP_TOOLS_OFF : "./image/off_tools.png", 
		IMG_MP_TOOLS_PRESS : "./image/press_tools.png",
		
		//인쇄중 화면
		IMG_PP_BG : "./image/CS_GUI_Printing.png",

		//menu button
		COPY_LOCKED_OFF : "./image/off_copy_locked.png",
		COPY_UNLOCKED_OFF : "./image/off_copy_unlocked.png",
		FAX_LOCKED_OFF : "./image/off_fax_locked.png",
		FAX_UNLOCKED_OFF : "./image/off_fax_unlocked.png",
		FORM_PRINTING_LOCKED_OFF : "./image/off_form_printing_locked.png",
		FORM_PRINTING_UNLOCKED_OFF : "./image/off_form_printing_unlocked.png",
		PRIVATE_PRINT_LOCKED_OFF : "./image/off_private_print_locked.png",
		PRIVATE_PRINT_UNLOCKED_OFF : "./image/off_private_print_unlocked.png",
		SCAN_EMAIL_LOCKED_OFF : "./image/off_scan_email_locked.png",
		SCAN_EMAIL_UNLOCKED_OFF : "./image/off_scan_email_unlocked.png",
		SCAN_JT_LOCKED_OFF : "./image/off_scan_jt_locked.png",
		SCAN_JT_UNLOCKED_OFF : "./image/off_scan_jt_unlocked.png",
		SCAN_MBOX_LOCKED_OFF : "./image/off_scan_mbox_locked.png",
		SCAN_MBOX_UNLOCKED_OFF : "./image/off_scan_mbox_unlocked.png",
		SCAN_PC_LOCKED_OFF : "./image/off_scan_pc_locked.png",
		SCAN_PC_UNLOCKED_OFF : "./image/off_scan_pc_unlocked.png",
		WEB_LOCKED_OFF : "./image/off_web_locked.png",
		WEB_UNLOCKED_OFF : "./image/off_web_unlocked.png",
		COPY_LOCKED_PRESS : "./image/press_copy_locked.png",
		COPY_UNLOCKED_PRESS : "./image/press_copy_unlocked.png",
		FAX_LOCKED_PRESS : "./image/press_fax_locked.png",
		FAX_UNLOCKED_PRESS : "./image/press_fax_unlocked.png",
		FORM_PRINTING_LOCKED_PRESS : "./image/press_form_printing_locked.png",
		FORM_PRINTING_UNLOCKED_PRESS : "./image/press_form_printing_unlocked.png",
		PRIVATE_PRINT_LOCKED_PRESS : "./image/press_private_print_locked.png",
		PRIVATE_PRINT_UNLOCKED_PRESS : "./image/press_private_print_unlocked.png",
		SCAN_EMAIL_LOCKED_PRESS : "./image/press_scan_email_locked.png",
		SCAN_EMAIL_UNLOCKED_PRESS : "./image/press_scan_email_unlocked.png",
		SCAN_JT_LOCKED_PRESS : "./image/press_scan_jt_locked.png",
		SCAN_JT_UNLOCKED_PRESS : "./image/press_scan_jt_unlocked.png",
		SCAN_MBOX_LOCKED_PRESS : "./image/press_scan_mbox_locked.png",
		SCAN_MBOX_UNLOCKED_PRESS : "./image/press_scan_mbox_unlocked.png",
		SCAN_PC_LOCKED_PRESS : "./image/press_scan_pc_locked.png",
		SCAN_PC_UNLOCKED_PRESS : "./image/press_scan_pc_unlocked.png",
		WEB_LOCKED_PRESS : "./image/press_web_locked.png",
		WEB_UNLOCKED_PRESS : "./image/press_web_unlocked.png",
		EDOC_LOCKED_OFF : "./image/off_edoc_locked.png",
		EDOC_LOCKED_PRESS : "./image/press_edoc_locked.png",
		EDOC_UNLOCKED_OFF : "./image/off_edoc_unlocked.png",
		EDOC_UNLOCKED_PRESS : "./image/press_edoc_unlocked.png"
};