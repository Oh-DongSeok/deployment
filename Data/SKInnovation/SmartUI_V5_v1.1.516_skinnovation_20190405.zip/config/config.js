﻿var CONFIG = {
	USER_SET : {
		/* Available Images :
		 * copy, scan_pc, scan_mbox, scan_email, fax, web, eco_copy, edoc
		 * private_print, form_printing, ips, ips_scan, bridge_app, native_menu
		 * */
		FUN_IMG_01 : "copy",
		FUN_IMG_02 : "scan_email",
		FUN_IMG_03 : "fax",
		FUN_IMG_04 : "ips_scan",
		FUN_IMG_05 : "native_menu",
		FUN_IMG_06 : "",
		FUN_IMG_07 : "",
		FUN_IMG_08 : "",
	    FUN_IMG_09 : ""
	    },
	FUNCTIONS : {
		FUC_01 : "copy",
		FUC_02 : "scan_email",
		FUC_03 : "fax",
		FUC_04 : "web1",
		FUC_05 : "native_menu",
		FUC_06 : "",
		FUC_07 : "",
		FUC_08 : "",
		FUC_09 : ""
	},
	// 버튼의 라벨을 변경할 필요가 있을 경우 하기의 내용을 변경해주세요.
	// 언어별로 변경할 필요가 있습니다.(사용하지 않는 경우는 문제없음)
	// 해당 언어의 정의가 없을 경우 영문으로 표기해주세요.
	// 버튼에 할당한 USER_SET.FUN_IMG_0?에 설정된 Index에 대응하여 변경하시면 됩니다.
	// Custom label을 사용하기 위해서는 CUSTOM_LABEL을 true로 설정해주세요.
	// "Default"치로 설정하면 기본 설정된 Label을 사용합니다.
	CUSTOM_LABEL: true,
	FUNC_LABEL: {
		// 영문
		en:{
			FUN_LABEL_01 : "Default",
			FUN_LABEL_02 : "Default",
			FUN_LABEL_03 : "Default",
			FUN_LABEL_04 : "Contract Mgr",
			FUN_LABEL_05 : "Default",
			FUN_LABEL_06 : "Default",
			FUN_LABEL_07 : "Default",
			FUN_LABEL_08 : "Default",
			FUN_LABEL_09 : "Default"
		},
		// 한글
		ko:{
			FUN_LABEL_01 : "Default",
			FUN_LABEL_02 : "Default",
			FUN_LABEL_03 : "Default",
			FUN_LABEL_04 : "계약서 관리",
			FUN_LABEL_05 : "Default",
			FUN_LABEL_06 : "Default",
			FUN_LABEL_07 : "Default",
			FUN_LABEL_08 : "Default",
			FUN_LABEL_09 : "Default"
		},
		// 중국어
		"zh-cn":{
			FUN_LABEL_01 : "Default",
			FUN_LABEL_02 : "Default",
			FUN_LABEL_03 : "Default",
			FUN_LABEL_04 : "Contract Mgr",
			FUN_LABEL_05 : "Default",
			FUN_LABEL_06 : "Default",
			FUN_LABEL_07 : "Default",
			FUN_LABEL_08 : "Default",
			FUN_LABEL_09 : "Default"
		}
	}
};

/**
 * Label은 
 * 한글/중국어 : 10자 이내
 * 영어 : 14자 이내
 * 숫자 : 14자 
 * Custom Label 적용 후에 표시 영역을 확인해주세요.
 *  
 * Label의 Default value 
 * 영문 ==================================
 * copy : "Copy"
 * scan_pc : "Scan(PC)"
 * scan_mbox : "Scan(MailBox Save)"
 * scan_email : "Scan(Mail)"
 * fax : "Fax"
 * web : "Web Application"
 * eco_copy : "eco COPY"
 * private_print : "Private Charge Print"
 * form_printing : "Form Access"
 * ips : "iPS"
 * ips_scan : "iPS MyScan"
 * bridge_app : "Bridge App"
 * native_menu : "Native-UI"
 * scan_jt : "NetworkScan"
 * edoc : "E-Doc"
 * 
 * 한글 ==================================
 * copy : "복사"
 * scan_pc : "스캔(PC전송)"
 * scan_mbox : "스캔(메일박스저장)"
 * scan_email : "스캔(메일송신)"
 * fax : "팩스"
 * web : "웹 애플리케이션"
 * eco_copy : "eco COPY"
 * private_print : "개인 프린트"
 * form_printing : "양식지 출력"
 * ips : "iPS"
 * ips_scan : "iPS MyScan"
 * bridge_app : "Bridge App"
 * native_menu : "Native-UI"
 * scan_jt : "NetworkScan"
 * edoc : "전자문서"
 * 
 * 중문 ==================================
 * copy : "複印"
 * scan_pc : "扫描(PC儲存)"
 * scan_mbox : "扫描(保存邮箱)"
 * scan_email : "扫描(送电子邮件)"
 * fax : "傳真"
 * web : "外部存取"
 * eco_copy : "eco COPY"
 * private_print : "个人的列印"
 * form_printing : "Form Access"
 * ips : "iPS"
 * ips_scan : "iPS MyScan"
 * bridge_app : "Bridge App"
 * native_menu : "Native-UI"
 * scan_jt : "NetworkScan"
 * edoc : "E-Doc"
 *
 */