﻿/**
 * @fileoverview : Data정의
 * @author FXKIS son.ch
 * @version 1.0.0
 */
var glbInfo = {};					//설정치 참조용 Data
var glbDevInfo = {permitInfo:["1","1","1"]};				//유저 정보 격납처
var glbConfig = {};					//조정 가능 항목의 격납처
var glbDataSet = null;				//Scan 에 사용되는 설정정보의 전역 Data

//2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193
var glbDbm;
var glbDbmEnable = true;			//Private print 이용 가능 유무 플래그 refs #4193
var glbProgress = {private_print : false, server_print : false}; //잡 실행시 private print문서, 서버 문서 각각 잡 유무 및 종료를 나타내는 플래그
var glbServerIdx = 0;
var glbServerURL;

/**********************************************************************************/

var gProtocol = "http://";
SSMILib.protocol = "http://";

var glbSetting = {};

var CARBON_PER_PAPER = 0.62;	//A4용지 1장당 배출되는 탄소량(2.88g)

var glbPrtQuantity = {//부수의 최대치, 최소치
	Min	: 1,
	Max	: 9999
};

var CON_TIMEOUT = {//서버연결시간
	Min : 5,
	Max : 999,
	Default : 10
};

var DOC_PRINT_TIMEOUT = 1000 * DATA.TIMEOUT;//문서출력후 Response받을 때 가지의 설정 시간
var MAX_GET_STORED_DOCUMENT = 100;//RemoteHost + 문서 99건
var MAX_ASYN = 3; //PDL정보 취득, 유저 정보 취득, PrintCapavility정보 취득 비동기 처리 판별
var MAX_ASYN_JOB = 3; //JobTicket생성, TCPIP정보 취득, 초기 표시언어 취득의 비동기 처리 판별

var OWNER_CHK = {
	USER_ID			: 1,
	IC_CARD_ID		: 2,
	RELATED_USER_ID	: 4,
	SUB_USER_ID		: 8,
};

var PERMIT_CHK ={
	FULL_COLOR		: 0,
	LIMITED_COLOR	: 1,
	BW				: 2,
};

//연결 TimeOut시간
var ACCESS_TIMEOUT = {
	MIN	:	5,
	MAX	:	999
};

//Port 번호
var PORT_NUMBER = {
	MIN	:	1,
	MAX	:	65535
};

var PRINTABLE_VALID_TYPE = {none : 0, info : 1, alert : 2};

//메뉴페이지 즉시/선택인쇄버튼 초기치 관련 정의
var DEFAULT_PRN_BTN_TYPES = {
	PROMPT : "prompt",
	SELECT : "select",
	NONE : "none",
	LAST : "last",
	AUTO : "auto" //2017.01.05 초기 버튼 설정 auto 추가
};
var AUTH_DATA_OPTION_LOC = "./config/auth.js"
var PRINT_DATA_OPTION_LOC = "./config/last.js";
var PREFERENCE_DATA_LOC = "./config/data.js";

// 유저 표시 정보 설정 정보 정의
var DISPLAY_USER_INFO = {
	AUTO : "auto",
	DISPLAYNAME : "displayname",
	USERID : "userid",
	RELATEDID : "relatedid"
};

//유저 제한 정보
var NO_PRINT = "0";		// Print금지
var YES_PRINT = "1";	// Print가능
var NONE_ACCESS = "2";	// 관련 기능 없음

var glbPrintBtnStatus = false;
var glbMpsPrintBtnStatus = false;

var MAX_GETUSER_COUNT = 3;//2016.11.03 KIS Chone CardID가 null일 때 GetUser 리트라이 3회 실시 대응
var glbGetUserCount = 0;//2016.11.03 KIS Chone CardID가 null일 때 GetUser 리트라이 3회 실시 대응

/**
 * 화면 표시와 관련된 Flag를 재초기화 한다.
 * @return
 */
function resetInfo()
{
	glbInfo.popupType = "";
	glbInfo.currentFLPage = 1;
	glbInfo.totalFLPage = 0;
	glbInfo.printCompletedNum = 0;
	glbInfo.deletedFileNum = 0;
	glbInfo.changePrtQuantity = false;
	glbInfo.hardKeyInput = false;
	glbInfo.isLoading = false;
	glbDevInfo.docList = [];
	glbInfo.passwordExpChk = false;
}

/**
 * User의 제한 정보를 취득
 */
function getUserPermitInfo()
{
	var tempInfo = (flg_Dummy_Beep)? "111,111,111,111": document.EwbClass.getPermitInfo();

	glbDevInfo.permitInfo = [];
	glbDevInfo.permitInfo[PERMIT_CHK.FULL_COLOR] = tempInfo.slice(4,5);
	glbDevInfo.permitInfo[PERMIT_CHK.LIMITED_COLOR] = tempInfo.slice(5,6);
	glbDevInfo.permitInfo[PERMIT_CHK.BW] = tempInfo.slice(6,7);
}

/**
 * Print금지 유저를 확인
 */
function getPrintPermitInfo()
{
	var isEnable = true;
	if(( glbDevInfo.permitInfo[PERMIT_CHK.FULL_COLOR] == NO_PRINT )&&(glbDevInfo.permitInfo[PERMIT_CHK.LIMITED_COLOR] == NO_PRINT )&&( glbDevInfo.permitInfo[PERMIT_CHK.BW] == NO_PRINT )){
		isEnable = false;
	}
	return isEnable;
}

/**
 * Devece의 보안 설정정보 취득(Port정보)
 */
function getHostAddress(host)
{
	var resultHost;
	if(host == gHost){
		//子機의 설정값을 반환한다.
		resultHost = gHost;
	}else{
		//親機의 설정값을 반환한다.
		for(var i=0;i<glbConfig.devices.length;i++){
			if(glbConfig.devices[i] == host){
				resultHost = glbConfig.devices[i];
			}
		}
	}
	return resultHost;
}

/**
 * Devece의 보안 설정정보 취득(Protocol정보)
 */
function getHostProtocol(host)
{
	var resultProtocol;
	if(host == gHost){
		//子機의 설정값을 반환한다.
		resultProtocol = gProtocol;
	}else{
		//親機의 설정값을 반환한다.
		for(var i=0;i<glbConfig.devices.length;i++){
			if(glbConfig.devices[i] == host){
				resultProtocol = glbConfig.devicesSSL[i];
			}
		}
	}
	return resultProtocol;
}

/**
 * SSMMLib.host、SSMMLib.protocol의 초기화 함수
 */
function setHostProtocol()
{
	// host정보와 Protocol정보를 子機의 Data로 반환한다.
	SSMILib.host = gHost;
	SSMILib.protocol = gProtocol;
}
/**********************************************************************************/


/**
 * 송신 Mail Address의 종류
 * -사양변경 대응(V1.6.0)
 */
var SourceAddressType = {
	Device			:"Device",
	User			:"User"
};

/**
 * Data의 초기화를 한다.
 */
function initModel()
{
	initConfig();
	initInfo();
	initObject();
}

/**
 * 조정가능 항목의 초기화(미사용)
 */
function initConfig()
{
}

/**
 * Contents가 취급하는 Data의 초기화
 */
function initInfo()
{
	glbInfo.usedPrivatePrintCount = 0;//2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193
	//image
	glbInfo.Img={};

	//슬라이드 팝업 메시지 표시시간
	glbInfo.MSG_TIMEOUT_LENGTH=7000;

	//복합기의 호스트명
	glbInfo.hostName="";

	//유저명 표시 사이즈(전각：2/반각：1)
	glbInfo.userNameLength = 14;

	/******************************** CS24 *********************************/
	glbInfo.usagePrnCnt={limitColor:"", limitGray:"", prnCount:0, usedColor:"", usedGray:"",functionCtrl:"",overCountPrint:""};////SmartUI 2017.02 복수의 Print Server 대응 refs #4184

	glbInfo.userInfo = null;

	glbInfo.isJobExcuted = false;

	glbInfo.getObjByKey = function(_type,_key){
		var result = null;
		var idx = this.getIndexByKey(_type,_key);
		if(idx>-1){
			result=this[_type][idx];
		}
		return result;
	};
	glbInfo.getIndexByKey = function(_type, _key, _default){
		var result = (typeof _default === "undefined")? -1 : _default;
		var _lst = this[_type];
		try{
			for(var i=0,iMax=_lst.length,_obj;i<iMax;i++){
				_obj=_lst[i];
				if(_obj.key==_key){
					result = i;
					break;
				}
			}
		}
		catch(e){
			//console.log(e);
		}
		return result;
	};
	glbInfo.getKeyByIndex = function(_type,_idx){
		var _lst = this[_type];
		var _obj = _lst[_idx];
		return _obj.key;
	};
	glbInfo.nup = [];
	glbInfo.nup[0] = {//"1up"
		key			: "1",
		text		: Msg.FILELIST.FILE_LIST_BTN_NUP_NOT_MSG,//문서 리스트 화면
		iconOff		: Img.ICN_PS_NUP_1UP_OFF,
		iconDis		: Img.ICN_PS_NUP_1UP_DIS,
		value	: JFLib.NUPNUM.ONE
	};
	glbInfo.nup[1] = {//"2up"
		key			: "2",
		text		: "2" + Msg.FILELIST.COMMON_PRINT_NUP_LABEL,
		iconOff		: Img.ICN_PS_NUP_2UP_OFF,
		iconDis		: Img.ICN_PS_NUP_2UP_DIS,
		value	: JFLib.NUPNUM.TWO
	};
	glbInfo.nup[2] = {//"4up"
		key			: "4",
		text		: "4" + Msg.FILELIST.COMMON_PRINT_NUP_LABEL,
		iconOff		: Img.ICN_PS_NUP_4UP_OFF,
		iconDis		: Img.ICN_PS_NUP_4UP_DIS,
		value	: JFLib.NUPNUM.FOUR
	};
	glbInfo.nup[3] = {//"6up" Mac전용
		key			: "6",
		text		: "6" + Msg.FILELIST.COMMON_PRINT_NUP_LABEL,
		iconOff		: Img.ICN_PS_NUP_6UP_OFF,
		iconDis		: Img.ICN_PS_NUP_6UP_DIS,
		value	: JFLib.NUPNUM.SIX
	};
	glbInfo.nup[4] = {//"8up"
		key			: "8",
		text		: "8" + Msg.FILELIST.COMMON_PRINT_NUP_LABEL,
		iconOff		: Img.ICN_PS_NUP_8UP_OFF,
		iconDis		: Img.ICN_PS_NUP_8UP_DIS,
		value	: JFLib.NUPNUM.EIGHT
	};
	glbInfo.nup[5] = {//"9up" Mac전용
		key			: "9",
		text		: "9" + Msg.FILELIST.COMMON_PRINT_NUP_LABEL,
		iconOff		: Img.ICN_PS_NUP_9UP_OFF,
		iconDis		: Img.ICN_PS_NUP_9UP_DIS,
		value	: JFLib.NUPNUM.NINE
	};
	glbInfo.nup[6] = {//"16up"
		key			: "16",
		text		: "16" + Msg.FILELIST.COMMON_PRINT_NUP_LABEL,
		iconOff		: Img.ICN_PS_NUP_16UP_OFF,
		iconDis		: Img.ICN_PS_NUP_16UP_DIS,
		value	: "16"
	};
	glbInfo.nup[7] = {//"32up"
		key			: "32",
		text		: "32" + Msg.FILELIST.COMMON_PRINT_NUP_LABEL,
		iconOff		: Img.ICN_PS_NUP_32UP_OFF,
		iconDis		: Img.ICN_PS_NUP_32UP_DIS,
		value	: "32"
	};

	glbInfo.color = [];
	glbInfo.color[0] = {
		key			: "C",
		text 		: Msg.FILELIST.FILE_LIST_BTN_COLOR_MODE_AUTO_MSG,
		iconOff		: Img.ICN_PS_CM_COLOR_OFF,
		iconDis 	: Img.ICN_PS_CM_COLOR_DIS,
		value		: JFLib.CM.AUTO
	};
	glbInfo.color[1] = {
		key			: "B",
		text 		: Msg.FILELIST.FILE_LIST_BTN_COLOR_MODE_BW_MSG,
		iconOff		: Img.ICN_PS_CM_GRAY_OFF,
		iconDis 	: Img.ICN_PS_CM_GRAY_DIS,
		value		: JFLib.CM.BW
	};
	glbInfo.destColor = [];
	glbInfo.destColor[0] = {
		key			: "C",
		text 		: Msg.FILELIST.FILE_LIST_BTN_COLOR_MODE_AUTO_MSG,
		iconOff		: Img.ICN_PS_CM_COLOR_OFF,
		iconDis 	: Img.ICN_PS_CM_COLOR_DIS,
		value		: JFLib.CM.AUTO
	};
	glbInfo.destColor[1] = {
		key			: "B",
		text 		: Msg.FILELIST.FILE_LIST_BTN_COLOR_MODE_BW_MSG,
		iconOff		: Img.ICN_PS_CM_GRAY_OFF,
		iconDis 	: Img.ICN_PS_CM_GRAY_DIS,
		value		: JFLib.CM.BW
	};

	glbInfo.plex = [];
	glbInfo.plex[0] = {
		key			: "S",
		text		: Msg.FILELIST.FILE_LIST_BTN_PLEX_SIMPLEX_MSG,
		iconOff		: Img.ICN_PS_PLEX_SIMPLEX_OFF,
		iconDis		: Img.ICN_PS_PLEX_SIMPLEX_DIS,
		value		: JFLib.OUTPLEX.SIMPLEX
	};
	glbInfo.plex[1] = {
		key			: "DL",
		text		: Msg.FILELIST.FILE_LIST_BTN_PLEX_DUPLEX_MSG,
		iconOff		: Img.ICN_PS_PLEX_DUPLEX_OFF,
		iconDis		: Img.ICN_PS_PLEX_DUPLEX_DIS,
		value		: JFLib.OUTPLEX.DUPLEX
	};
	glbInfo.plex[2] = {
		key			: "DS",
		text		: Msg.FILELIST.FILE_LIST_BTN_PLEX_DUPLEX_MSG,
		iconOff		: Img.ICN_PS_PLEX_TUMBLE_OFF,
		iconDis		: Img.ICN_PS_PLEX_TUMBLE_DIS,
		value		: JFLib.OUTPLEX.TUMBLE
	};
	glbInfo["delete"] = [];
	glbInfo["delete"][0] = {
		key			: "0",
		text		: Msg.FILELIST.FILE_DELETE_AFTER_PRINT_MSG,
		value		: "0"
	};
	glbInfo["delete"][1] = {
		key			: "1",
		text		: Msg.FILELIST.FILE_SAVE_AFTER_PRINT_MSG,
		value		: "1"
	};
	glbInfo.validation = [
		{iconOff:Img.EMPTY_ICON},
		{iconOff:Img.INFORMATION_ICON},
		{iconOff:Img.ALERT_ICON}
	];
	/******************************************/
	glbInfo.prefrenceSetting = {
		JOB_LIST_COUNT:[{text:"40", value:40}, {text:"80", value:80}],
		TIME_TYPE:[{text:"12", value:0}, {text:"24", value:1}],
		//TITLE_NAME	AnyGuard Print
		//TIMEOUT	60
		SKIP:[{text:Msg.PreferenceSettingPopup.LST_BAR_DIS0, value:0}, {text:Msg.PreferenceSettingPopup.LST_BAR_DIS1, value:1}],
		BUTTON_DEFAULT:[{text:Msg.PreferenceSettingPopup.DFT_BTN_SETTING0, value:"prompt"},
		                {text:Msg.PreferenceSettingPopup.DFT_BTN_SETTING1, value:"select"},
		                {text:Msg.PreferenceSettingPopup.DFT_BTN_SETTING2, value:"last"},
		                {text:Msg.PreferenceSettingPopup.DFT_BTN_SETTING3, value:"auto"}, //2017.01.05 초기 버튼 설정 auto 추가
		                {text:Msg.PreferenceSettingPopup.DFT_BTN_SETTING4, value:"none"}],//2017.01.05 초기 버튼 설정 auto 추가
		COLOR_DISPLAY:[{text:Msg.PreferenceSettingPopup.DIS_COLOR_USAGE0, value:false},{text:Msg.PreferenceSettingPopup.DIS_COLOR_USAGE1, value:true}],
		//SERVER_URL	null
		DELETE:[{text:Msg.PreferenceSettingPopup.DEL_AFT_PRINT0, value:0}, {text:Msg.PreferenceSettingPopup.DEL_AFT_PRINT1, value:1}],
		LIST_AUTO_SELECT : [{text:Msg.PreferenceSettingPopup.LIST_AUTO_SELECT0, value:0},{text:Msg.PreferenceSettingPopup.LIST_AUTO_SELECT1, value:1}],//SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
		LIST_SORT_ASC:[{text:Msg.PreferenceSettingPopup.DIS_LIST_SORT0, value:false},{text:Msg.PreferenceSettingPopup.DIS_LIST_SORT1, value:true}],
		MULTI_SERVER_TYPE:[{text:Msg.PreferenceSettingPopup.MULTI_SRV_TYPE0, value:0},{text:Msg.PreferenceSettingPopup.MULTI_SRV_TYPE0, value:1}],
		AGREE_DISPLAY:[{text:Msg.PreferenceSettingPopup.AGREE_DISPLAY0, value:false},{text:Msg.PreferenceSettingPopup.AGREE_DISPLAY1, value:true}]
	};

	glbConfig.DATA = {
		JOB_LIST_COUNT:40,
		TIME_TYPE:1,
		TITLE_NAME:"SmartWhere",
		TIMEOUT:10,
		SKIP:0,
		BUTTON_DEFAULT:"none",
		COLOR_DISPLAY:true,
		SERVER_URL:"http://0.0.0.0:8080/WebService/",
		DELETE:1,
		LIST_AUTO_SELECT:0,
		UPDATE_DELAY_TIME:1000,
		LIST_SORT_ASC:true,
		NAME_DISPLAY_SELECT:"relatedid",
		MULTI_SERVER_TYPE: 0,
		AGREE_DISPLAY: false,
		BANNER_URL: "http://0.0.0.0/data/main_msg.js"
	};
	if(DATA) Extend(glbConfig.DATA,DATA);

	//glbConfig.remoteHost = glbConfig.DATA.SERVER_URL;//SmartUI 2017.02 복수의 Print Server 대응 refs #4184 - 이 대응으로 사용하지 않음
	glbInfo.SERVER_NUM = 0;
	for(var i = 0;glbConfig.DATA.SERVER_URL.length > i;i++){
		for(var j = i+1;glbConfig.DATA.SERVER_URL.length > j;j++){
			if(glbConfig.DATA.SERVER_URL[i] == glbConfig.DATA.SERVER_URL[j]){
				glbConfig.DATA.SERVER_URL[j] = "Re-enter";
			}
		}
		if(glbConfig.DATA.SERVER_URL[i] != "Re-enter"){
			glbInfo.SERVER_NUM++;
		}
	}
	KISUtil.debug("SERVER_NUM = ", glbInfo.SERVER_NUM);
	// glbInfo.SERVER_NUM = glbConfig.DATA.SERVER_URL.length;//SmartUI 2017.02 복수의 Print Server 대응 refs #4184
	glbConfig.wsIp = Common.getWsIp();
	//SmartUI 2017.02 복수의 Print Server 대응 refs #4184
	glbInfo.serverCallCount = 0;//서버 호출 횟수
	glbInfo.serverErrCount = 0; //서버 호출 실패 횟수, 서버 호출 횟수와 실패 횟수가 같을 경우 에러 처리함
	glbInfo.DOC_PROC_COUNT = 0; //(삭제/프린트시) 서버가 1대일 경우 1, 서버가 여러대-삭제시에는 문서수, 프린트시에는 프린트하는 서버 수
	glbInfo.noResultCount = 0; // 서버에서 문서없음 횟수
	glbInfo.failParams = "";

	if(!glbConfig.DATA.SERVER_URL){
		glbInfo.SERVER_NUM = 0;
	}
}

/**
 * Scan, Mail Object의 초기화
 */
function initObject()
{
	//console.log("initObject");
	glbDevInfo.docList = [];
	glbDevInfo.pdlList = [];
}

/**
 * 페이지로 사용되는 Data의 격납용 Class
 */
var DataSet = function()
{
	//userInfo
	this.userInfo = {};
	//doclist
	this.docList = null;
	//selectedDoc
	this.selectedDoc = {};
	//printSetting
	this.userPolicyInfo = {};
};

/**
 * 문서 리스트 화면의 문서 선택 버튼의 Index취득
 * @param {string} id : 문서 선택 버튼의 ID
 * @return : 문서 선택 버튼의 Index
 */
function getFileButtonNumber(id){
	for(var i=0; i<glbDevInfo.docList.length; i++){
		if(id == "file_list_button" + i){
			return i;
		}
	}
	return -1;
}

/**
 * 선택된 문서수의 취득
 * @return 선택된 문서수
 */
function getNumberOfSelectFiles()
{
	var num = 0;
	for(var i=0; i<glbDevInfo.docList.length;i++){
		var obj = glbDevInfo.docList[i];
		if(obj.selected){
			num++;
		}
	}
	return num;
}

//2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193 Start
function createJobTemplate()
{
	var  jobTemplate = new JFLib.JobTemplate();
	jobTemplate.category = Jfs_Msg.CATEGORY;
	jobTemplate.header.name = Jfs_Msg.JOB_NAME;
	jobTemplate.name = Jfs_Msg.TEMPLATE_NAME;
	jobTemplate.header.description = ContentsLib.contentsId + " " + ContentsLib.contentsVersion;
	jobTemplate.header.identifier = Jfs_Msg.VENDOR_IDENTIFIER;
	jobTemplate.process = JFLib.PROCESS.ABORT;
	jobTemplate.setInputProcess(createMailboxObj());
	jobTemplate.addOutputProcess(createPrintObj());

	return jobTemplate;
};

function createMailboxObj()
{
	JFLib.Mailbox.MailboxFlow = true;

	var mailboxObj = new JFLib.Mailbox();
	mailboxObj.targetOrigin.print = true;
	mailboxObj.targetOrigin.pdl = true;
	mailboxObj.documentHandling.jobstatus = JFLib.JS.SUCCESS;
	mailboxObj.documentHandling.action = JFLib.DH.DELETE; //Private Print 문서는 프린트 후 삭제함

	return mailboxObj;
};

function createPrintObj()
{
	var printObj = new JFLib.Print();
	printObj.copies = null;
    printObj.outPlex = null;
    printObj.colorMode = null;

    return printObj;
};
//2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193 End
