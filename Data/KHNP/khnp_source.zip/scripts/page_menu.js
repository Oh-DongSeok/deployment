﻿/**
 * 개별 페이지의 표시 및 동작용
 * （메뉴 페이지용）
 */
var MenuPage = new TemplatePage();

MenuPage.ID = "page_menu";

/**
 * 개별 페이지의 Data정의
 */
MenuPage._initModel = function()
{
	this._data =
	{
		buttonList:[
			{id:"btn_MP_setting", type:WidgetLib.ButtonType.NORMAL, attr:{targetImgId:"img_MP_setting",offImg: Img.IMG_MP_SETTING_OFF, pressImg: Img.IMG_MP_SETTING_PRESS}},
			{id:"btn_MP_refresh", type:WidgetLib.ButtonType.NORMAL, attr:{offImg: Img.IMG_MP_REFRESH_OFF, pressImg: Img.IMG_MP_REFRESH_PRESS, disableImg: Img.IMG_MP_REFRESH_DIS}},
			{id:"btn_MP_promptPrint", type:WidgetLib.ButtonType.TOGGLE, status:{on:false}, attr:{targetImgId:"img_MP_promptPrint",offImg: Img.IMG_MP_PROMPT_OFF, pressImg: Img.IMG_MP_PROMPT_PRESS, onImg: Img.IMG_MP_PROMPT_ON, groupId:"BTN_MP_PRN"}},
			{id:"btn_MP_selectPrint", type:WidgetLib.ButtonType.TOGGLE, status:{on:false}, attr:{targetImgId:"img_MP_selectPrint",offImg: Img.IMG_MP_SELECTED_PRINT_OFF, pressImg: Img.IMG_MP_SELECTED_PRINT_PRESS, onImg: Img.IMG_MP_SELECTED_PRINT_ON, groupId:"BTN_MP_PRN"}},
			{id:"btn_MP_usageTools", type:WidgetLib.ButtonType.NORMAL, attr:{targetImgId:"img_MP_usageTools",offImg: Img.IMG_MP_SETUP_OFF, pressImg: Img.IMG_MP_SETUP_PRESS}}
		],
		imageList:[
			{id:"img_MP_bg", src:Img.IMG_MP_BG}
		],
		textList:[
			{id:"lbl_MP_setting", text:Msg.MENU.SETTING },
			{id:"lbl_MP_promptPrint", text:Msg.MENU.PROMPT_PRINT },
			{id:"lbl_MP_selectPrint", text:Msg.MENU.SELECT_PRINT },
			{id:"lbl_MP_printOpt",text:Msg.MENU.PRINT_OPTION},
			{id:"lbl_MP_docCnt",text:Msg.MENU.DOC_COUNT},
			{id:"lbl_MP_usage",text:Msg.MENU.USAGE}
		]
	};
};

/**
 * 즉시/선택 출력 버튼 초기상태값 취득용
 */
MenuPage.updateDefaultBtnStatus = function()
{
	var _status = this._getDefaultBtnStatus();
	WidgetLib.setWidgetStatus("btn_MP_promptPrint",{on:_status.prompt});
	WidgetLib.setWidgetStatus("btn_MP_selectPrint",{on:_status.select});
	WidgetLib.setWidgetStatus("btn_MP_promptPrint", {enable:false});
	Common.changeVisibility("btn_MP_promptPrint","none");
};

/**
 * 즉시/선택 출력 버튼 초기상태값 취득용
 */
MenuPage._getDefaultBtnStatus = function()
{
	var result = {"prompt":false, "select":false};
	var _type = glbConfig.DATA.BUTTON_DEFAULT;
	KISUtil.debug("_getDefaultBtnStatus/glbInfo.loginIdx",glbInfo.loginIdx);

	//2017.10 KIS [v1.5] SmartUI 출력방식 옵션 추가 refs #4497
	if((glbConfig.DATA.BUTTON_DEFAULT != DEFAULT_PRN_BTN_TYPES.AUTO) && (glbInfo.loginIdx > 1 || (!glbInfo.cardAuthFlg && glbInfo.loginIdx == 1) || glbConfig.DATA.BUTTON_DEFAULT == DEFAULT_PRN_BTN_TYPES.LAST)){
		//파일로부터 취득(last.js)
		_type = PRINT_DATA_OPTION||DEFAULT_PRN_BTN_TYPES.NONE;
	}else{
		var _dataContent = 'var PRINT_DATA_OPTION = "' + _type + '";';
		//선택상태 보존
		save_content_to_file(_dataContent, PRINT_DATA_OPTION_LOC);
		eval(_dataContent);
		KISUtil.debug("_getDefaultBtnStatus/_dataContent",_dataContent);
	}

	//즉시/선택인쇄 버튼 초기설정 반영
	switch(_type){
		case DEFAULT_PRN_BTN_TYPES.PROMPT:
			//즉시출력 On
			result["prompt"] = true;
			break;
		case DEFAULT_PRN_BTN_TYPES.SELECT:
			//선택출력 On
			result["select"] = true;
			break;
		case DEFAULT_PRN_BTN_TYPES.NONE:
			//즉시/선택출력 Off
			break;
		case DEFAULT_PRN_BTN_TYPES.LAST:
			//파일에서 불러와 반영하므로 이곳은 통과하면 안됨
			break;
		case DEFAULT_PRN_BTN_TYPES.AUTO://2017.10 [v1.5] SmartUI 출력방식 옵션 추가 refs #4497
			//즉시/선택출력 Off 상태로 유지
			break;
	}

	return result;
};

/**
 * 개별 페이지 고유의 항목을 구성
 * Step2.1
 */
MenuPage._initOthers = function()
{
	this.initList();
	var _lbl = {id:"lbl_MP_usageTools", text:Msg.MENU.USAGE_TOOLS };
	if(glbInfo.userInfo&&(glbInfo.userInfo.Index == -1||glbInfo.userInfo.Index == -2)){	//KO//CE
		_lbl.text = Msg.MENU.ADMIN_TOOLS;
	}
	this._data.textList.push(_lbl);
};

MenuPage._onPageChange = function()
{
	if(!glbInfo.userInfo){
		WidgetLib.setWidgetStatus("btn_MP_refresh", {enable:false});
	}

	if(glbInfo.isJobExcuted){
		//MenuPage.getUsagePrnCnt();
		glbDbm.getDocCount(); //2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
	}
	this.updateDisplay();
};

MenuPage.getUsagePrnCnt = function()
{
	function _getUsagePrnCnt(){
		for(var i=0; i<glbInfo.SERVER_NUM; i++){//2017.11 [v1.5] SmartUI 복수의 Print Server 대응 refs #4502
			var upcObj = new SSMILib.UsagePrnCnt();
			upcObj.userId = glbInfo.userInfo.RelatedUserID;
			upcObj.deviceIp = glbInfo.ipAddress;
			upcObj.wsIp = glbConfig.wsIp[i];
			SSMILib.GetUsagePrnCnt(upcObj, DOC_PRINT_TIMEOUT, glbConfig.DATA.SERVER_URL[i]);
		}
	}

	if(glbInfo.userInfo && typeof glbInfo.ipAddress !== "undefined"){
		_getUsagePrnCnt();
	}else{
		KISUtil.debug("glbInfo.userInfo", glbInfo.userInfo);
		KISUtil.debug("glbInfo.ipAddress", glbInfo.ipAddress);

		glbInfo.getUsagePrnCntInterval = setInterval(function(){
			if(glbInfo.userInfo && typeof glbInfo.ipAddress !== "undefined"){
				clearInterval(glbInfo.getUsagePrnCntInterval);
				_getUsagePrnCnt();
			}
		},100);
	}
};

MenuPage.updateDisplayUsagePrnCnt = function()
{
	with(glbInfo.usagePrnCnt){
		Common.setText("lbl_MP_prnCount", prnCount);
		Common.setText("lbl_MP_color_used", glbConfig.DATA.COLOR_DISPLAY?usedColor:"");
		Common.setText("lbl_MP_color_limit", glbConfig.DATA.COLOR_DISPLAY?limitColor:"");
		Common.setText("lbl_MP_gray_used", usedGray);
		Common.setText("lbl_MP_gray_limit", limitGray);
	}
};

MenuPage.clearDisplayUsagePrnCnt = function()
{
	Common.setText("lbl_MP_prnCount", "");
	Common.setText("lbl_MP_color_used", "");
	Common.setText("lbl_MP_color_limit", "");
	Common.setText("lbl_MP_gray_used", "");
	Common.setText("lbl_MP_gray_limit", "");
};

/**
 * 개별 페이지 고유의 항목을 구성
 */
MenuPage.initList = function()
{
	var attr, txtAttr;
	var lst = document.getElementById("lyr_funcList");
	//func 0-9
	var us;
	for(var i=0; i<9; i++){
		us = CONFIG.USER_SET["FUN_IMG_0"+(i+1)];
		if(Common.isNullOrEmpty(us)) continue;
		attr = {id:"btn_MP_func_" + i, type:WidgetLib.ButtonType.NORMAL, status:{enable:glbInfo.loginIdx>0}, attr:{targetImgId:"img_MP_func_"+i,  offImg : Img[us.toUpperCase() + "_UNLOCKED_OFF"], pressImg : Img[us.toUpperCase() + "_UNLOCKED_PRESS"], disableImg : Img[us.toUpperCase() + "_LOCKED_OFF"], groupId:"BTN_MP_FUNC"	}};
		txtAttr = {id:"lbl_MP_func_" + i, text:Msg.Funcs[us]};
		_btn = Common.getNewElement("div", {id:attr.id, className:"btn"});
		_btn.innerHTML = "<img id='img_MP_func_"+i+"' class='btnBg' /><div id='"+txtAttr.id+"' class='lbl'></div>";
		lst.appendChild(_btn);
		this._data.buttonList.push(attr);
		this._data.textList.push(txtAttr);
	}
};

/**
 * 화면 표시의 갱신(공통/화면전환시에 호출된다.)
 */
MenuPage.updateDisplay = function(){
	this.updateDisplayUsagePrnCnt();
};

/**
 * 메뉴리스트의 CS버튼의 락 해제
 */
MenuPage.updateMenuBtnLockStatus = function(flg)
{
	var attr,
		lst = document.getElementById("lyr_funcList"),
		_status = {enable:flg};
	for (var i=0, iMax=this._data.buttonList.length; i<iMax; i++) {
		WidgetLib.setWidgetStatus("btn_MP_func_" + i, _status);
	}
};

/**
 * 인증후이므로 선택시에는 천이가 되어야하므로 라디오버튼으로 변경
 */
MenuPage.updatePrnBtnType = function()
{
	WidgetLib._getWidget("btn_MP_promptPrint").type = WidgetLib.ButtonType.RADIO;
	WidgetLib._getWidget("btn_MP_selectPrint").type = WidgetLib.ButtonType.RADIO;
};

/**
 * 개별 페이지의 Event처리
 * @param {string} event : Event의 종류
 * @param {string} id : Event의 발생원
 */
MenuPage.EventHandler = function(event, id)
{
	KISUtil.debug("EventHandler", "event:" + event + "/id:" + id);
	switch(event){
		case "GetUser":
			if(glbInfo.userInfo){
				this.updateMenuBtnLockStatus(true);
				//등록/변경버튼 표시갱신
				if(glbInfo.userInfo.Index > 0)
				{
					var attr = { offImg: Img.IMG_MP_SETUP_OFF, pressImg: Img.IMG_MP_SETUP_PRESS};
					WidgetLib.setWidgetAttr("btn_MP_usageTools", attr);
					WidgetLib.setWidgetStatus("btn_MP_refresh", {enable:true});
					Common.changeVisibility("btn_MP_setting","none");
					//this.getUsagePrnCnt();
					glbDbm.getDocCount();	//2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
				}
				else if(glbInfo.userInfo.Index == -1||glbInfo.userInfo.Index == -2)	//KO//CE
				{
					var attr = { offImg: Img.IMG_MP_TOOLS_OFF, pressImg: Img.IMG_MP_TOOLS_PRESS};
					WidgetLib.setWidgetAttr("btn_MP_usageTools", attr);
					WidgetLib.setWidgetStatus("btn_MP_refresh", {enable:false});
					Common.changeVisibility("btn_MP_setting","block");
				}
				else{
					WidgetLib.setWidgetStatus("btn_MP_refresh", {enable:false});
					Common.changeVisibility("btn_MP_setting","none");
				}
			}
			else{
				this.updateMenuBtnLockStatus(false);
				Common.changeVisibility("btn_MP_setting","none");
			}
			break;
		case "GetUsagePrnCnt":
			KISUtil.debug("glbInfo.loginIdx",glbInfo.loginIdx);
			KISUtil.debug("glbConfig.DATA.SKIP",glbConfig.DATA.SKIP);
			KISUtil.debug("glbInfo.usagePrnCnt.prnCount",glbInfo.usagePrnCnt.prnCount);

			this.updatePrnBtnType();
			this.updateDisplayUsagePrnCnt();

			if(glbInfo.isJobExcuted){
				if((glbInfo.serverCallCount == glbInfo.SERVER_NUM)){
					glbInfo.isJobExcuted = false;
				}
			}
			else{
				if(glbInfo.loginIdx > 1){
					//기인증상태이므로 자동 실행/천이를 막음
					KISUtil.debug("*", "기인증상태이므로 자동 실행/천이를 막음");
					if(glbConfig.DATA.SKIP == 1){
						//리스트 팝업으로 천이/기인증 상태여도 조건없이 리스트 팝업으로 천이한다.
						KISUtil.debug("*", "리스트 팝업으로 천이");
						PageManager.changePage(FileListPage, PageManager.type.NORMAL);
					}
				}
				//리프레시버튼을 통한 갱신인경우  #707
				else if(glbInfo.isRefresh){
					if((glbInfo.serverCallCount == glbInfo.SERVER_NUM)){
						KISUtil.debug("*", "리프레시버튼을 통한 갱신이므로 자동 실행/천이를 막음");
						glbInfo.isRefresh = false;
						return;
					}
				}
				else{
					if(glbConfig.DATA.SKIP == 1){
						//리스트 팝업으로 천이
						KISUtil.debug("*", "리스트 팝업으로 천이");
						PageManager.changePage(FileListPage, PageManager.type.NORMAL);
					}
					//2017.10 [v1.5] SmartUI 출력방식 옵션 추가 refs #4497
					else if(glbConfig.DATA.BUTTON_DEFAULT == DEFAULT_PRN_BTN_TYPES.AUTO){
						if(glbInfo.usagePrnCnt.prnCount > 0){
							if(glbInfo.usagePrnCnt.prnCount == 1){//문서 1건일 땐 즉시 출력함
								this.doJobStart();
							}else{//2건 이상일 땐 선택 출력 화면으로 이동
								PageManager.changePage(FileListPage, PageManager.type.NORMAL);
							}
						}
					}
					//인쇄가능매수가 1매 이상인 경우
					else if(glbInfo.usagePrnCnt.prnCount > 0){
						KISUtil.debug("*", "인쇄가능매수가 1매 이상인 경우");
						//즉시 출력 flag가 1(on)일때 or 즉시 출력 버튼 상태가 on일때
						//선택 출력 버튼 상태가 on일때
						if(WidgetLib.getWidgetStatus("btn_MP_selectPrint").on){
							KISUtil.debug("*", "리스트 팝업으로 천이");
							//리스트 팝업으로 천이
							PageManager.changePage(FileListPage, PageManager.type.NORMAL);
						}
						else if(WidgetLib.getWidgetStatus("btn_MP_promptPrint").on){
							KISUtil.debug("*", "전체 인쇄 실행");
							//전체 인쇄 실행
							if(glbInfo.usagePrnCnt.prnCount > 0){
								this.doJobStart();
							}
							else{
								KISUtil.debug("GetUsagePrnCnt/glbInfo.usagePrnCnt.prnCount",glbInfo.usagePrnCnt.prnCount);
							}
						}
						else{
							//do nothing
						}
					}
					else{
						//do nothing
					}
				}
			}
			break;
		case "onbuttonup":
			MessageManager.clearMessageArea();
			BrowserExt.Beep(0);
			switch(id)
			{
				case "btn_MP_setting":
					PageManager.changePage(PreferenceSettingPopup, PageManager.type.NORMAL);
					break;
				case "btn_MP_refresh":
					//재취득시의 처리구분플래그 정의
					glbInfo.isRefresh = true;
					//인쇄 정보 재취득
					//this.getUsagePrnCnt();
					glbDbm.getDocCount();	//2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
					//표시 정보 클리어(인쇄관련)
					this.clearDisplayUsagePrnCnt();
					break;
				case "btn_MP_promptPrint":
					WidgetLib.setWidgetStatus("btn_MP_promptPrint",{enable:false});
					var _status = WidgetLib.getWidgetStatus(id);

					var _dataContent = 'var PRINT_DATA_OPTION = "'+DEFAULT_PRN_BTN_TYPES.NONE+'";';
					if(_status.on){
						WidgetLib.setWidgetStatus("btn_MP_selectPrint", {on:false});
						_dataContent = 'var PRINT_DATA_OPTION = "'+DEFAULT_PRN_BTN_TYPES.PROMPT+'";';
						Common.addClass(id,"on");
						Common.removeClass("btn_MP_selectPrint","on");
					}
					else{
						Common.removeClass(id,"on");
					}

					//선택상태 보존
					save_content_to_file(_dataContent, PRINT_DATA_OPTION_LOC);
					eval(_dataContent);
					KISUtil.debug("EventHandler/btn_MP_promptPrint/_dataContent",_dataContent);

					//미인증 유저인경우
					//pass
					//인증유저인경우
					if(glbInfo.userInfo != null){
						//인쇄가능매수가 1매 이상인 경우
						if(glbInfo.usagePrnCnt.prnCount > 0){
							//전체 인쇄 실행
							//Common.doJobStart();
							this.doJobStart();
						}
					}
					break;
				case "btn_MP_selectPrint":
					var _status = WidgetLib.getWidgetStatus(id);

					var _dataContent = 'var PRINT_DATA_OPTION = "'+DEFAULT_PRN_BTN_TYPES.NONE+'";';
					if(_status.on){
						WidgetLib.setWidgetStatus("btn_MP_promptPrint", {on:false});
						_dataContent = 'var PRINT_DATA_OPTION = "'+DEFAULT_PRN_BTN_TYPES.SELECT+'";';
						Common.addClass(id,"on");
						Common.removeClass("btn_MP_promptPrint","on");
					}
					else{
						Common.removeClass(id,"on");
					}

					//선택상태 보존
					save_content_to_file(_dataContent, PRINT_DATA_OPTION_LOC);
					eval(_dataContent);
					KISUtil.debug("EventHandler/btn_MP_promptPrint/_dataContent",_dataContent);

					//미인증 유저인경우
					//pass
					//인증유저인경우
					if(glbInfo.userInfo != null){
						//인쇄가능매수가 1매 이상인 경우
						if(glbInfo.usagePrnCnt.prnCount > 0){
							//선택 인쇄 리스트 페이지로 천이
							PageManager.changePage(FileListPage, PageManager.type.NORMAL);
						}
					}
					break;
				case "btn_MP_usageTools":
					BrowserExt.SetScreenChange("popup:tools_menu");
					break;
				case "btn_MP_func_0":
				case "btn_MP_func_1":
				case "btn_MP_func_2":
				case "btn_MP_func_3":
				case "btn_MP_func_4":
				case "btn_MP_func_5":
				case "btn_MP_func_6":
				case "btn_MP_func_7":
				case "btn_MP_func_8":
					//미인증상태에서 천이는 enable:false이므로 이벤트가 발생하지 않음
					//인증유저인경우
					if(glbInfo.userInfo != null){
						var _idx = parseInt(id.substring(id.length, id.length - 1)) + 1;
						if(CONFIG.FUNCTIONS["FUC_0" + _idx] == "password"){
							PageManager.changePage(PasswordExpPopup, PageManager.type.NORMAL);
						}else{
							BrowserExt.SetScreenChange("menuto:" + CONFIG.FUNCTIONS["FUC_0" + _idx]);
						}
					}
					break;
				default:
					break;
			}
			break;
		case "onhardkeydown":
			MessageManager.clearMessageArea();
			switch(id)
			{
				case BrowserExt.keyCode.FX_VK_START:
					BrowserExt.Beep(1);
					return;
					//기존사양은 다음과 같이 인쇄가능 문서 존재시 즉시출력을 실행하는 것이었음.
					//유저 오조작의 가능성과 논리적 오류(유저가 의도한 동작이 즉시출력과 선택출력중 어느것인지 알 수 없음)로 판단되어 해당 사양을 드랍시켜버림
					//추후 본건과 관련한 이슈 발생시 참고하기바람(2013/11/29 son.ch)
					if(WebServiceLib.getActiveRequestCount() != 0){
						BrowserExt.Beep(1);
						KISUtil.debug("[job return]","getActiveRequestCount()=" + WebServiceLib.getActiveRequestCount());
						return;
					}
					BrowserExt.Beep(0);
					if(glbInfo.userInfo != null){
						//인쇄가능매수가 1매 이상인 경우
						if(glbInfo.usagePrnCnt.prnCount > 0){
							//전체 인쇄 실행
							//Common.doJobStart();
							this.doJobStart();
						}
					}
					break;
				case BrowserExt.keyCode.FX_VK_CLEAR:
					//リセットキー
					BrowserExt.Beep(0);
					//window.location.reload(true);
					// Mantis No: 0000018
					BrowserExt.SetScreenChange("allservice");
					break;
				case BrowserExt.keyCode.FX_VK_PAUSE:
					break;
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		default:
			break;
	}
};

MenuPage.doJobStart = function()
{
	if(glbInfo.ipAddress){
		Common.doJobStart();
	}else{
		glbInfo.isPrintAllOn = true;
	}
};
