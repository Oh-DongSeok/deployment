﻿﻿var TemplateManager = {
    DataSource: {
        "DocItem": '<img id="bgDocItem{{Idx}}" /><div id="lblDocItemName{{Idx}}" class="lbl fileName"></div><div id="lblDocItemDate{{Idx}}" class="lbl fileDate"></div><div id="lblDocItemPages{{Idx}}" class="lbl filePages"></div><div id="lblDocItemQat{{Idx}}" class="lbl fileQat"></div><img id="icnDocItemColor{{Idx}}" class="icon fileColor" /><div id="lblDocItemColor{{Idx}}" class="lbl fileColor"></div><img id="icnDocItemPlex{{Idx}}" class="icon filePlex" /><div id="lblDocItemPlex{{Idx}}" class="lbl filePlex"></div><img id="icnDocItemNup{{Idx}}" class="icon fileNup"/><div id="lblDocItemNup{{Idx}}" class="lbl fileNup"></div><img id="icnDocItemAlert{{Idx}}" class="icon alert" /><div id="lblDocItemDelete{{Idx}}" class="lbl fileDelete"></div>',
        //ewb의 정규식 대응문제에 따른 임시 대처
        "DocItem0": '<img id="bgDocItem0" /><div id="lblDocItemName0" class="lbl fileName"></div><div id="lblDocItemDate0" class="lbl fileDate"></div><div id="lblDocItemPages0" class="lbl filePages"></div><div id="lblDocItemQat0" class="lbl fileQat"></div><img id="icnDocItemColor0" class="icon fileColor" /><div id="lblDocItemColor0" class="lbl fileColor"></div><img id="icnDocItemPlex0" class="icon filePlex" /><div id="lblDocItemPlex0" class="lbl filePlex"></div><img id="icnDocItemNup0" class="icon fileNup"/><div id="lblDocItemNup0" class="lbl fileNup"></div><img id="icnDocItemAlert0" class="icon alert" /><div id="lblDocItemDelete0" class="lbl fileDelete"></div>',
        "DocItem1": '<img id="bgDocItem1" /><div id="lblDocItemName1" class="lbl fileName"></div><div id="lblDocItemDate1" class="lbl fileDate"></div><div id="lblDocItemPages1" class="lbl filePages"></div><div id="lblDocItemQat1" class="lbl fileQat"></div><img id="icnDocItemColor1" class="icon fileColor" /><div id="lblDocItemColor1" class="lbl fileColor"></div><img id="icnDocItemPlex1" class="icon filePlex" /><div id="lblDocItemPlex1" class="lbl filePlex"></div><img id="icnDocItemNup1" class="icon fileNup"/><div id="lblDocItemNup1" class="lbl fileNup"></div><img id="icnDocItemAlert1" class="icon alert" /><div id="lblDocItemDelete1" class="lbl fileDelete"></div>',
        "DocItem2": '<img id="bgDocItem2" /><div id="lblDocItemName2" class="lbl fileName"></div><div id="lblDocItemDate2" class="lbl fileDate"></div><div id="lblDocItemPages2" class="lbl filePages"></div><div id="lblDocItemQat2" class="lbl fileQat"></div><img id="icnDocItemColor2" class="icon fileColor" /><div id="lblDocItemColor2" class="lbl fileColor"></div><img id="icnDocItemPlex2" class="icon filePlex" /><div id="lblDocItemPlex2" class="lbl filePlex"></div><img id="icnDocItemNup2" class="icon fileNup"/><div id="lblDocItemNup2" class="lbl fileNup"></div><img id="icnDocItemAlert2" class="icon alert" /><div id="lblDocItemDelete2" class="lbl fileDelete"></div>',
        "DocItem3": '<img id="bgDocItem3" /><div id="lblDocItemName3" class="lbl fileName"></div><div id="lblDocItemDate3" class="lbl fileDate"></div><div id="lblDocItemPages3" class="lbl filePages"></div><div id="lblDocItemQat3" class="lbl fileQat"></div><img id="icnDocItemColor3" class="icon fileColor" /><div id="lblDocItemColor3" class="lbl fileColor"></div><img id="icnDocItemPlex3" class="icon filePlex" /><div id="lblDocItemPlex3" class="lbl filePlex"></div><img id="icnDocItemNup3" class="icon fileNup"/><div id="lblDocItemNup3" class="lbl fileNup"></div><img id="icnDocItemAlert3" class="icon alert" /><div id="lblDocItemDelete3" class="lbl fileDelete"></div>'
    },

    getTemplate: function(data) {
        var obj = Common.getNewElement("div", { id: data.key + data.attrs.Idx, className: "btn" })
        var _template = this.DataSource[data.tmpl + data.attrs.Idx];
        if (_template) {
            //obj.innerHTML = this.convert(_template, data.attrs);
            //ewb의 정규식 대응문제에 따른 임시 대처
            obj.innerHTML = _template;
        } else {
            //write log
        }

        return obj;
    },

    convert: function(tmpl, attr) {
        var _ptrn;
        for (i in attr) {
            try {
                //_ptrn = new RegExp("\\\$\{" + i + "\}","gi");
                //tmpl = tmpl.replace(_ptrn, attr[i])
                eval("tmpl = tmpl.replace(/\{\{" + i + "\}\}/g, attr[i]);");
            } catch (e) {
                KISUtil.debug("convert", "exception");
            }
        }

        return tmpl;
    }
};

//2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
var DocuBoxManager = (function() {
    var sdObj,
        isDocCnt = false,
        isEventAttached,
        _eventOrigin,
        callback;

    //OWNERタイプ
    var OWNER_CHK = {
        USER_ID: 1,
        IC_CARD_ID: 2,
        RELATED_USER_ID: 4,
        SUB_USER_ID: 8,
    };

    //文書取得時のRespond設定
    var glbRespond = ["sd:StoreTime",
        "sd:Name",
        "sd:NumberOfPages",
        "sap:ColorMode",
        "sap:Nup",
        "sap:Copies",
        "sap:OutPlex",
        "sap:OutPlexOverWritePermission",
        "sap:ColorModeOverWritePermission",
        "sap:CopiesOverWritePermission",
        "sac:Printed"
    ];

    return {
        init: function(ownerType, _callback) {
            _init(ownerType, _callback);
        },
        getDocList: function(type, owner) {
            _getDocList(null, glbInfo.userInfo.RelatedUserID);
        },
        getDocCount: function() {
            _getDocCount(null, "249162f0");
        },
        deleteDoc: function(deleteDocObj) {
            _deleteDoc(deleteDocObj);
        }
    };

    function _init(ownerType, _callback) {
        sdObj = new SSMILib.StoredDocument();
        sdObj.boxFilter.types[0] = SSMILib.BOX.TYPE.SECURITY;
        sdObj.storeTypeFilters.push(SSMILib.BOX.FILTER.PRINT);
        if (ownerType) {
            sdObj = _setUserType(sdObj, ownerType);
        }
        callback = extendDeep(_callback, { onGetDocCntSuccessCallback: function() {}, onGetDocCntFailCallback: function() {}, onGetDocLstSuccessCallback: function() {}, onGetDocLstFailCallback: function() {}, onDeleteDocsSuccessCallback: function() {}, onDeleteDocsFailCallback: function() {} });

        isEventAttached = false;
        _attachEventHandler();
    }

    function _attachEventHandler() {
        if (!isEventAttached) {
            isEventAttached = true;
            _eventOrigin = SSMILib.listener;
            SSMILib.listener = function(event, result, obj) {
                if (!_onSSMIEvent(event, result, obj)) {
                    _eventOrigin(event, result, obj);
                }
            };
        }
    }

    function _dettachEventHandler() {
        if (isEventAttached) {
            delete SSMILib.listener;
            SSMILib.listener = _eventOrigin;
            isEventAttached = false;
        }
    }

    function _onSSMIEvent(event, result, obj) {
        if (event == "GetStoredDocumentCount") {
            LogLib.info("[CS] GetStoredDocumentCount " + result + ", " + arguments[2]);
        } else if (event == "GetStoredDocument") {
            if (result) {
                callback.onGetDocLstSuccessCallback(obj);
            } else {
                callback.onGetDocLstFailCallback(obj);
            }
        } else if (event == "DeleteStoredDocument") {
            if (obj instanceof Array) {
                var successCnt = 0;
                for (var i = 0, len = obj.length; i < len; i++) {
                    tmp = obj[i];
                    switch (typeof tmp) {
                        case "string":
                            var no = parseInt(tmp);
                            if (no.isNaN) {
                                //exception
                            } else {
                                successCnt++
                            }
                            break;
                        case "object":
                            if (tmp instanceof Array) {
                                //exception
                            } else {
                                //error
                                //KISUtil.debug("_onSSMIEvent/"+event, JSON.strigify(obj));
                            }
                            break;
                        default:
                            break;
                    }
                }

                if (successCnt == len) { //정상
                    callback.onDeleteDocsSuccessCallback(obj);
                } else if (successCnt < len) { //에러발생
                    callback.onDeleteDocsFailCallback(obj);
                } else {
                    //불가능
                    //에러발생
                    callback.onDeleteDocsFailCallback("onDeleteFail", obj);
                }
            } else { //에러발생
                callback.onDeleteDocsFailCallback("onDeleteFail", obj);
            }
            return true;
        } else {
            return false;
        }

        function getKeies(obj) {
            var result = [];
            for (var i in obj) {
                result[result.length] = i;
            }
            return result;
        }

        function _onComplete() {
            alert("complete");
        }

        function _onError() {
            alert("error");
        }
    }

    /**
     * ユーザタイプ設定
     */
    function _setUserType(sdObj, ownerType) {
        switch (ownerType) {
            case OWNER_CHK.USER_ID:
                sdObj.userIdentifierTypes.push(SSMILib.USER_IDTYPE.USER);
                break;
            case OWNER_CHK.IC_CARD_ID:
                sdObj.userIdentifierTypes.push(SSMILib.USER_IDTYPE.IC_CARD);
                break;
            case OWNER_CHK.RELATED_USER_ID:
                sdObj.userIdentifierTypes.push(SSMILib.USER_IDTYPE.RELATED_USER);
                break;
            case OWNER_CHK.SUB_USER_ID:
                sdObj.userIdentifierTypes.push(SSMILib.USER_IDTYPE.SUB_USER);
                break;
        }

        return sdObj
    }

    /**
     * SSMI GetStoredDocument呼び出し
     */
    function _getDocList(type) {
        isDocCnt = false;

        sdObj.boxFilter.types[0] = SSMILib.BOX.TYPE.SECURITY;
        sdObj.storeTypeFilters.push(SSMILib.BOX.FILTER.PRINT);
        sdObj.printJobState = type ? type : "";
        sdObj.sortPolicy.type = SSMILib.SORTPOLICY.DSC;
        sdObj.sortPolicy.key = "sd:StoreTime";
        sdObj.userIdentifierTypes.push(SSMILib.USER_IDTYPE.RELATED_USER);
        sdObj.respondTypes = glbRespond;
        sdObj.printJobState = SSMILib.PRINT_JOB_STATE.NOSTATE;

        SSMILib.GetStoredDocument(sdObj);
    }

    /**
     * userIdentifierTypesを指定する。
     * @param sdObj StoredDocument
     * @return sdObj StoredDocument
     */
    function setUserType(sdObj) {
        if (glbConfig.ownerType & OWNER_CHK.USER_ID) {
            sdObj.userIdentifierTypes.push(SSMILib.USER_IDTYPE.USER);
        }
        if (glbConfig.ownerType & OWNER_CHK.IC_CARD_ID) {
            sdObj.userIdentifierTypes.push(SSMILib.USER_IDTYPE.IC_CARD);
        }
        if (glbConfig.ownerType & OWNER_CHK.RELATED_USER_ID) {
            sdObj.userIdentifierTypes.push(SSMILib.USER_IDTYPE.RELATED_USER);
        }
        if (glbConfig.ownerType & OWNER_CHK.SUB_USER_ID) {
            sdObj.userIdentifierTypes.push(SSMILib.USER_IDTYPE.SUB_USER);
        }

        return sdObj;
    }

    /**
     * SSMI GetStoredDocumentCount呼び出し
     * @return
     */
    function _getDocCount(type, owner) {
        isDocCnt = true;
        sdObj.boxFilter.types[0] = SSMILib.BOX.TYPE.SECURITY;
        sdObj.storeTypeFilters.push(SSMILib.BOX.FILTER.PRINT);

        sdObj.userIdentifierTypes.push(SSMILib.USER_IDTYPE.RELATED_USER);
        sdObj.printJobState = SSMILib.PRINT_JOB_STATE.NOSTATE;

        SSMILib.GetStoredDocumentCount(sdObj);
    }

    /**
     * 文書削除処理
     */
    function _deleteDoc(deleteDocObj) {
        sdObj.documents = [];

        for (var i = 0; i < deleteDocObj.length; i++) {
            var docObj = new SSMILib.Document();
            docObj.id = deleteDocObj[i].info.Identifier;
            sdObj.documents.push(docObj);
        }

        SSMILib.DeleteStoredDocument(sdObj);
    }
});

/**
 * 문서 리스트용 모듈
 *
 * 초기화
 *  매수연산
 *  플래그 초기화
 *
 * 항목 선택시
 *  플래그 갱신 -> 전체 플래그 재연산
 *
 * 설정변경후 천이
 *  매수변경
 *  플래그 갱신 -> 전체 플래그 재연산
 */
var DocListManager = function(opt) {
    this.config = {
        key: "BASE",
        countPerPage: 4,
        targetId: "lyr_BASE_Display_Area"
    };
    this.init = function() {
        this.selectedItemIdx = -1;
        this.checkedList = [];
        this.totalSpendPageCount = 0;
    };

    /**
     * 문서리스트용 데이터 설정
     */
    this.setDataSource = function(_data) {
        //KISUtil.debug("setDataSouce","start");
        try {
            //KISUtil.debug("setDataSouce/_data.length",_data.length);
            this.dataSource = _data;
            KISUtil.debug("setDataSouce/dataSource.length", _data.length);
            //팝업으로의 천이시에도 리스트의 페이징을 유지를 위해 선별적으로 페이지 초기화
            if (this.currentPageIdx == null || typeof this.currentPageIdx == "undefined") {
                this.currentPageIdx = 1;
            }
            this.maxPageIdx = Math.ceil(this.dataSource.length / this.config.countPerPage);
            KISUtil.debug("setDataSouce/maxPageIdx", this.maxPageIdx);
        } catch (e) {
            KISUtil.debug("setDataSouce", "exception");
        }
    };

    /**
     * 문서리스트용 데이터 삭제
     */
    this.clearDataSouce = function() {
        this.dataSource = [];
        this.currentPageIdx = 1;
        this.maxPageIdx = 1;
        this.selectedItemIdx = -1;
        this.checkedList = [];
        this.totalSpendPageCount = 0;
    };

    /**
     * 설정변경데이터의 반영처리
     */
    this.updateSelectedDataSource = function(_docData) {
        this.dataSource[this.selectedItemIdx] = _docData;
    };

    this.getAllItems = function() {
        return this.dataSource;
    };

    this.getCheckedList = function() {
        return this.checkedList;
    };

    /**
     * 선택항목 리스트를 취득
     */
    this.getSelectedUUIDs = function(isSingleServer) { //2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498 - 서버로부터 취득한 문서만 처리함
        KISUtil.debug("getSelectedUUIDs", "start");
        var result = [];
        for (var i = 0, iMax = this.checkedList.length; i < iMax; i++) {
            if (!this.dataSource[this.checkedList[i]].boxId) {
                //2017.11 KIS [v1.5] SmartUI 복수의 Print Server 대응 refs #4502
                if (isSingleServer) {
                    result.push(this.dataSource[this.checkedList[i]].UUID);
                } else {
                    result.push({ uuid: this.dataSource[this.checkedList[i]].UUID, serverIdx: this.dataSource[this.checkedList[i]].serverIdx });
                }
            }
        }

        return result;
    };

    /**
     * 리스트의 페이징의 최종값을 반환
     */
    this.getTotalPages = function() {
        return this.maxPageIdx;
    };

    /**
     * 리스트의 항목수를 반환
     */
    this.getAllCount = function() {
        return this.dataSource.length;
    };

    /**
     * 선택된(체크) 항목수를 반환
     */
    this.getSelectedCount = function() {
        return this.checkedList.length;
    };

    /**
     * 페이지별 표시용 데이터취득
     */
    this.getDataByPageIdx = function() {
        var result = [];
        var offset = this.getStartIdx();
        var tmp;

        for (var i = 0, iMax = this.config.countPerPage; i < iMax; i++) {
            tmp = this.dataSource[offset + i];
            if (tmp)
                result.push(this.convertDisplayData(i, tmp));
        }

        return result;
    };

    /**
     * 선택항목수 갱신용 메소드
     * override하여 사용
     */
    this.updateSelectedFileCount = function() {};

    /**
     * 리스트의 페이지표시 갱신용 메소드
     * override하여 사용
     */
    this.updateCurrentPage = function() {};

    /**
     * (화면하단의)선택(활성화)항목의 인쇄매수 표시 갱신용 메소드
     * override하여 사용
     */
    this.updateTextPrnSet = function() {};

    /**
     *  취득한 문서 데이터를 표시용 데이터 변환
     */
    this.convertDisplayData = function(idx, _data) {
        //KISUtil.debug("convertDisplayData","start");
        var result = { text: {}, image: {} };
        result.text["lblDocItemName" + idx] = _data.docName;
        if (_data.prnType) {
            result.text["lblDocItemDate" + idx] = "";
            result.text["lblDocItemPages" + idx] = "";
            result.text["lblDocItemQat" + idx] = "";

            result.image["icnDocItemColor" + idx] = Img.EMPTY_ICON;
            result.text["lblDocItemColor" + idx] = "";

            result.image["icnDocItemNup" + idx] = Img.EMPTY_ICON;
            result.text["lblDocItemNup" + idx] = "";

            result.image["icnDocItemPlex" + idx] = Img.EMPTY_ICON;
            result.text["lblDocItemPlex" + idx] = "";

            result.text["lblDocItemDelete" + idx] = "";
            //2017.12 KIS [ABL] 모바일 프린트 대응판 refs #4535
            //result.image["icnDocItemAlert" + idx] = (_data.boxId) ? Img.ICN_PRIVATE_PRINT : Img.EMPTY_ICON;//2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
            if (_data.boxId) {
                result.image["icnDocItemAlert" + idx] = Img.ICN_PRIVATE_PRINT;
            } else {
                switch (_data.driverType) {
                    case "MOBILE": // Mobile Icon 표시
                        result.image["icnDocItemAlert" + idx] = Img.ICN_MOBILE;
                        break;
                    case "MOBILE_PCL":
                        result.image["icnDocItemAlert" + idx] = Img.ICN_MOBILE_PCL;
                        break;
                    case "MacOS": // Apple Icon 표시
                        result.image["icnDocItemAlert" + idx] = Img.ICN_MAC;
                        break;
                    default: // Icon 무표시
                        result.image["icnDocItemAlert" + idx] = Img.EMPTY_ICON;
                        break;
                }
            }
        } else {
            result.text["lblDocItemDate" + idx] = _data.printDate;
            result.text["lblDocItemPages" + idx] = _data.pageCnt + Msg.UNIT.PAGE; //"쪽";
            result.text["lblDocItemQat" + idx] = _data.printCnt + Msg.UNIT.PRN_SET; //"부";

            var _tmp = glbInfo["color"][_data.colorIdx];
            result.image["icnDocItemColor" + idx] = _tmp.iconOff;
            result.text["lblDocItemColor" + idx] = _tmp.text;

            _tmp = glbInfo["nup"][_data.nupIdx];
            result.image["icnDocItemNup" + idx] = _tmp.iconOff;
            result.text["lblDocItemNup" + idx] = _tmp.text;

            _tmp = glbInfo["plex"][_data.plexIdx];
            result.image["icnDocItemPlex" + idx] = _tmp.iconOff;
            result.text["lblDocItemPlex" + idx] = _tmp.text;

            result.text["lblDocItemDelete" + idx] = glbInfo["delete"][_data.deleteIdx].text;
            //2017.12 KIS [ABL] 모바일 프린트 대응판 refs #4535
            //result.image["icnDocItemAlert" + idx] = (_data.boxId) ? Img.ICN_PRIVATE_PRINT : glbInfo["validation"][_data.printInvalidType].iconOff;//2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
            if (_data.boxId) {
                result.image["icnDocItemAlert" + idx] = Img.ICN_PRIVATE_PRINT;
            } else {
                switch (_data.driverType) {
                    case "MOBILE": // Mobile Icon 표시
                        result.image["icnDocItemAlert" + idx] = Img.ICN_MOBILE;
                        break;
                    case "MOBILE_PCL":
                        result.image["icnDocItemAlert" + idx] = Img.ICN_MOBILE_PCL;
                        break;
                    case "MacOS": // Apple Icon 표시
                        result.image["icnDocItemAlert" + idx] = Img.ICN_MAC;
                        break;
                    default: // Icon 무표시
                        result.image["icnDocItemAlert" + idx] = glbInfo["validation"][_data.printInvalidType].iconOff;
                        break;
                }
            }
        }
        return result;
    };

    /**
     * 문서 리스트 초기구성(템플릿을 통한 HTML및 위젯 등록)
     */
    this.initDisplay = function() {
        //KISUtil.debug("initDisplay","start");
        var fileListButtonAttr = {
                offImg: Img.FILE_LIST_BUTTON_OFF,
                pressImg: Img.FILE_LIST_BUTTON_PRESS,
                onImg: Img.FILE_LIST_BUTTON_ON
            },
            data = {
                tmpl: "DocItem",
                key: "btnDocItem",
                attrs: {
                    Idx: 0
                }
            };

        if (WidgetLib.getWidgetNode(data.key + "0") == null) { //등록되지 않은 경우에만 생성
            this.registListItems(fileListButtonAttr, data);
        }
    };

    /**
     * 리스트의 항목 버튼 생성 및 위젯에 등록
     */
    this.registListItems = function(fileListButtonAttr, data) {
        //KISUtil.debug("registListItems", "start");
        for (var i = 0, iMax = this.config.countPerPage; i < iMax; i++) {
            try {
                data.attrs.Idx = i;
                fileListButtonAttr.targetImgId = "bgDocItem" + i;
                //Template를 이용한 HTML구성
                var btnElement = TemplateManager.getTemplate(data);
                document.getElementById(this.config.targetId).appendChild(btnElement);
                WidgetLib.registerButtonWidget(btnElement, WidgetLib.ButtonType.TOGGLE, fileListButtonAttr); // data[i].Id
            } catch (e) {
                KISUtil.debug("registListItems", "error");
            }
        }
    };

    /**
     * 리스트의 현재 페이지의 시작 인덱스를 반환
     */
    this.getStartIdx = function() {
        return (this.currentPageIdx - 1) * this.config.countPerPage;
    };

    /**
     * 선택(Check)문서상세정보리스트(인쇄용)취득
     */
    this.getCheckedDocInfo = function() {
        KISUtil.debug("getCheckedDocInfo", "start");
        var result = [];
        var tmp;
        var _min = this.getStartIdx();
        var _max = _min + this.config.countPerPage - 1;
        for (var i = 0, iMax = this.checkedList.length; i < iMax; i++) {
            tmp = this.checkedList[i];
            if (tmp >= _min && tmp <= _max) {
                result.push(this.dataSource[tmp]);
            }
        }

        return result;
    };

    /**
     * 체크항목 리스트를 취득
     */
    this.getCheckedItems = function() {
        KISUtil.debug("getCheckedItems", "start");
        var result = [];
        for (var i = 0, iMax = this.checkedList.length; i < iMax; i++) {
            result.push(this.dataSource[this.checkedList[i]]);
        }

        return result;
    };
    /**
     * "전체 프린트"에서 체크항목중 출력 가능한 목록만 취득
     */
    this.getPolicyCheckedItems = function() {
      var result = [];
      var cntGrayPrintOut = 0;
      var cntColorPrintOut = 0;
      var cntGrayPrintOutRemain = glbInfo.usagePrnCnt.limitGray - glbInfo.usagePrnCnt.usedGray;
      var cntColorPrintOutRemain = glbInfo.usagePrnCnt.limitColor - glbInfo.usagePrnCnt.usedColor;
      for (var i = 0, iMax = this.checkedList.length; i < iMax; i++) {
          //result.push(this.dataSource[this.checkedList[i]]);
          switch(glbInfo.usagePrnCnt.functionCtrl){
            case 0: // 기능제한 없음
            case 2: // 컬러/흑백 사용가능
              result.push(this.dataSource[this.checkedList[i]]);
              break;
            case 1: // 흑백만 사용가능
            case 4:
              if(this.dataSource[this.checkedList[i]].colorIdx == 1){
                result.push(this.dataSource[this.checkedList[i]]);
              }
              break;
            case 3: // 컬러만 사용가능
              if(this.dataSource[this.checkedList[i]].colorIdx == 0){
                result.push(this.dataSource[this.checkedList[i]]);
              }
              break;
            case 5: // 컬러/흑백 사용불가
              // 출력 불가
              break;
            case 6: // 사용량 제한
              if(this.dataSource[this.checkedList[i]].colorIdx == 1){
                cntGrayPrintOut = cntGrayPrintOut + this.dataSource[this.checkedList[i]].paperSpend;
                if(cntGrayPrintOutRemain >= cntGrayPrintOut){   // 흑백이 남은 사용량보다 많거나 같으면 추가
                  result.push(this.dataSource[this.checkedList[i]]);
                }
              }else{
                cntColorPrintOut = cntColorPrintOut + this.dataSource[this.checkedList[i]].paperSpend;
                if(cntColorPrintOutRemain >= cntColorPrintOut){ // 컬러가 남은 사용량보다 많거나 같으면 추가
                  result.push(this.dataSource[this.checkedList[i]]);
                }
              }
              break;
            default:
              break;
          }
      }
      return result;
    }

    this.setCheckedItems = function(_lst) {
        this.checkedList = _lst;
    };

    /**
     * 선택(SELECT)문서정보(설정변경용)취득
     */
    this.getSelectedDocInfo = function() {
        var result = { success: false, doc: {} };
        if (this.selectedItemIdx > -1) {
            result.doc = this.dataSource[this.selectedItemIdx];
            result.success = true;
        }

        return result;
    };

    this.updateInvalidFlag = function() {
        try {
            var item,
                remain,
                toBeUsed = [0, 0],
                _overFlow,
                _isChecked,
                selectedLst = this.getCheckedList();
            _forcedBlack = glbDataSet.userPolicyInfo.forcedBlack ? 1 : 0,
                _forcedNup = glbDataSet.userPolicyInfo.forced2Up ? 1 : 0,
                _forcedDuplex = glbDataSet.userPolicyInfo.forcedDuplex ? 1 : 0,
                _functionCtrl = glbDataSet.userPolicyInfo.functionCtrl;
            this.printValidFlag = true;
            if (glbDataSet.userPolicyInfo.functionCtrl == 6) {
                //매수관련만 선택에 따라 아이콘이 바뀜
                //선택항목의 경우
                //선택순서대로  사용가능매수를 차감하여 Flag판별
                for (var i = 0, iMax = selectedLst.length; i < iMax; i++) {
                    idx = selectedLst[i];
                    item = this.dataSource[idx];
                    remain = glbInfo.usagePrnCnt.remain[item.colorIdx];
                    item.availablePages = (remain > toBeUsed[item.colorIdx]) ? (remain - toBeUsed[item.colorIdx]) : 0;
                    toBeUsed[item.colorIdx] += item.paperSpend;
                    _overFlow = (remain < toBeUsed[item.colorIdx]);
                    item.printInvalidType = (remain == 0) ? PRINTABLE_VALID_TYPE.alert : _overFlow ? PRINTABLE_VALID_TYPE.alert : PRINTABLE_VALID_TYPE.none;
                    this.printValidFlag = this.printValidFlag && (item.printInvalidType != PRINTABLE_VALID_TYPE.alert);
                    item.overFlow = _overFlow;
                }
                for (var i = 0, iMax = this.dataSource.length; i < iMax; i++) {
                    item = this.dataSource[i];
                    remain = glbInfo.usagePrnCnt.remain[item.colorIdx];
                    _isChecked = Common.contains(selectedLst, i);
                    if (!_isChecked) { //선택문서가 아닌경우
                        //(인쇄 가능량 - 현재까지 선택된 문서의 필요매수) < 현재의 문서의 필요매수
                        item.printInvalidType = ((remain - toBeUsed[item.colorIdx]) < item.paperSpend) ? PRINTABLE_VALID_TYPE.info : PRINTABLE_VALID_TYPE.none;
                        item.overFlow = null;
                    }
                }
            } else if (glbDataSet.userPolicyInfo.functionCtrl >= 0) {
                //비선택항목의 경우
                //사용가능매수 + 사용 예정매수 를 기준으로 그보다 큰경우 Flag를 true로 작거나 같은경우 false로 설정
                for (var i = 0, iMax = this.dataSource.length; i < iMax; i++) {
                    item = this.dataSource[i];
                    //var _policy = FileListPage.validator.getBtnStatusByPolicy(_forceBlack, item.colorIdx, _functionCtrl).status;
                    var _policy = FileListPage.validator.getBtnStatusByPolicy(_functionCtrl, _forcedNup, _forcedDuplex, _forcedBlack, item);

                    //item.printInvalidType = _policy.printStatus?PRINTABLE_VALID_TYPE.none:PRINTABLE_VALID_TYPE.info;
                    item.printInvalidType = (_policy.status.invalidFlag != null) ? _policy.status.invalidFlag : PRINTABLE_VALID_TYPE.none;
                    //선택문서인경우
                    if (Common.contains(selectedLst, i)) {
                        //this.printValidFlag = this.printValidFlag&&(item.printInvalidType!=PRINTABLE_VALID_TYPE.alert);
                        this.printValidFlag = this.printValidFlag && _policy.status.printStatus;
                    }
                }
            } else {
                KISUtil.debug("updateInvalidFlag", glbDataSet.userPolicyInfo.functionCtrl);
            }
        } catch (e) {
            KISUtil.debug("updateInvalidFlag", "exception");
        }
    };

    /**
     * (화면하단의)선택(활성화)항목의 인쇄매수 표시를 갱신
     */
    this._updateQuantity = function() {
        if (this.selectedItemIdx > -1) {
            var _selectedData = this.dataSource[this.selectedItemIdx];
            if (_selectedData.prnType || this.dataSource[this.selectedItemIdx].boxId) { //2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
                Common.changeVisibility("lyr_FL_PrintQuantity", "none");
            } else {
                Common.setImage("img_FL_PrintQuantity", (_selectedData.prnType) ? Img.TEXT_INPUT_BOX_DIS : Img.TEXT_INPUT_BOX_ENABLE);
                Common.changeVisibility("lyr_FL_PrintQuantity", "block");
                this.updateTextPrnSet(_selectedData.printCnt); //선택문서의 인쇄부수를 설정
            }
        } else {
            Common.changeVisibility("lyr_FL_PrintQuantity", "none");
        }
    };

    /**
     * 문서리스트 연관버튼(리스트 외) 상태갱신
     * TODO:밖으로 빼야할듯
     */
    this.updateBtnStatus = function() {
        //선택개수 표시갱신
        this.updateSelectedFileCount();
        this.updateCurrentPage();
        //전체 개수!=선택수 true
        Common.setObjectEnable("btn_FL_SelectAll", this.dataSource.length > 0);

        WidgetLib.setWidgetStatus("btn_FL_SelectAll", { on: (this.checkedList.length == this.dataSource.length) });

        //선택수>0
        Common.setObjectEnable("btn_FL_DeleteFile", this.checkedList.length > 0);

        //선택수>1
        //Common.setObjectEnable("lyr_FL_PrintQuantity",this.selectedItemIdx>-1);
        this._updateQuantity();

        //선택수==1

        Common.setObjectEnable("btn_FL_Modi_PrintSetting",
            (this.selectedItemIdx > -1 && !this.dataSource[this.selectedItemIdx].prnType) &&
            (typeof this.dataSource[this.selectedItemIdx].boxId == 'undefined')
            &&
            (this.dataSource[this.selectedItemIdx].driverType != "MOBILE_PCL") //2018.04 모바일 프린트 PCL 대응
        );

		    //Common.setObjectEnable("btn_FL_Modi_PrintSetting", (this.checkedList.length > 0) ? this.printValidFlag : false);
        // 설정 변경은 출력이 아니므로 1건 이상이면 진입하도록 설정 (컬러불가시에도 설정을 할 수 없도록 막히는 현상 대응 20190923 ohdongseok)
    	  Common.setObjectEnable("btn_FL_Modi_PrintSetting", (this.checkedList.length > 0));

        //선택문서가 존재하고 모두가 인쇄가능한경우
        Common.setObjectEnable("btn_FL_Print", (this.checkedList.length > 0) ? this.printValidFlag : false);

        //pageIdx>0
        Common.setObjectEnable("btn_FL_pageUp", this.currentPageIdx > 1);

        //pageIdx<maxPageIdx
        Common.setObjectEnable("btn_FL_pageDown", this.currentPageIdx < this.maxPageIdx);

        //true
        Common.setObjectEnable("btn_FL_Refresh", true);

        //전체개수>0
        Common.setObjectEnable("btn_FL_PrintAll", this.dataSource.length > 0);
    };

	//2017.08~09 [삼정회계법인] 선택 출력의 프린트 설정 일괄 변경 기능 추가 refs #4429
    //선택한 문서중에 컬러 문서가 존재하는지 체크, private print 문서는 제외함
    this.isExistColorDocInSelectedDocs = function()
    {
    	var isColorDocExist = false;
    	var lst = this.getCheckedItems();
    	for(var i = 0; i < lst.length; i++) {
    		if(typeof lst[i].boxId != 'undefined')
    			continue;

            //if(lst[i].colorIdx == 0){
    		if(lst[i].originColorIdx == 0){
                isColorDocExist = true;
                break;
            }
        }
    	return isColorDocExist;
    };

    //2017.08~09 [삼정회계법인] 선택 출력의 프린트 설정 일괄 변경 기능 추가 refs #4429
    //선택한 문서가 전부 private print 문서인지 아닌지 체크
    this.selectedDocsIsAllPrivatePrintDocs = function()
    {
    	var isAllPrivatePrintDoc = true;
    	var lst = this.getCheckedItems();
    	for(var i = 0; i < lst.length; i++) {
    		if(typeof lst[i].boxId == 'undefined'){
    			isAllPrivatePrintDoc = false;
                break;
            }
        }
    	return isAllPrivatePrintDoc;
    };

    /**
     *
     * [[프린트버튼]]/하드키도
     * [액션 공통 동작]
     * 인쇄매수 변경되었을 시 / 반영
     * 소요매수 재연산
     *
     * [데이터수정] - 없음
     *
     * [동작]
     * !Flag를 갱신하여 인쇄 가능여부를 확인
     * 인쇄 RUN
     *
     *
     * [[전체프린트버튼]]
     * [액션 공통 동작]
     * 인쇄매수 변경되었을 시 / 반영
     * 소요매수 재연산
     *
     * [데이터수정] - 없음
     * 이동할 페이지 인덱스 비교(최대 최소) OK?
     * 페이지 인덱스 수정
     *
     * [동작]
     * 인쇄 RUN(조건확인? 무조건?)
     *
     *
     * [[액션 공통 동작]의 적용범위]
     * 항목버튼*
     * 페이징 버튼*
     * 전체선택 버튼*
     * 프린트버튼
     * 전체프린트버튼(확인필요)
     * 페이지 천이간
     * 하드키(시작)?
     *
     * [대상외]
     * 새로고침 / 어차피 다시 가져오므로
     * 삭제 / 어차피 삭제되므로
     */

    /**
     * [액션 공통 동작]
     * 인쇄매수 변경되었을 시 / 반영
     * 소요매수 재연산
     */

    /**
     * [[항목 선택/해제]]
     * [액션 공통 동작]
     * 인쇄매수 변경되었을 시 / 반영
     * 소요매수 재연산
     *
     * [데이터 수정]
     * 선택상태가
     * 미선택이면
     * 체크 + 선택 + InvalidFlag를 하나로 통합?
     * 인덱스 + 키
     *
     * -체크리스트에 추가
     * -선택인덱스에 입력
     * -소요매수 갱신(추가)
     *
     * 선택이면
     * -체크리스트에서 삭제
     *  선택인덱스에 있는경우
     *  -선택인덱스에서도 삭제
     * -소요매수 갱신(삭제)
     *
     * [표시갱신]
     * 현재 페이지의  리스트정보 취득
     * 현재 페이지의 선택정보 취득
     *
     * 순차로 이동하며
     * 매수와 !Flag를 갱신(항상)
     * ON이미지 및 상태 갱신
     * 기타 버튼의 상태갱신
     */
    this.selectItem = function(idx) {
        try {
            var offset = this.getStartIdx();
            var currentIdx = offset + idx;
            var _idx = Common.indexOf(this.checkedList, currentIdx);
            var _key = "bgDocItem";

            var _selectedData = this.dataSource[currentIdx];
            if (_selectedData.prnType) {
                //선택
                if (_idx == -1) {
                    //insert
                    this.selectedItemIdx = currentIdx; //selectedItem
                    this.checkedList.push(currentIdx); //checkedList
                }
                //해제
                else {
                    //remove
                    this.selectedItemIdx = -1;
                    this.checkedList.splice(_idx, 1);
                }
                this.refresh();
            } else {
                _selectedData.paperSpend = getPaperSpend(_selectedData);

                //선택
                if (_idx == -1) {
                    //insert
                    this.selectedItemIdx = currentIdx; //selectedItem
                    this.checkedList.push(currentIdx); //checkedList

                    //소요매수 갱신(추가)
                    this.totalSpendPageCount += _selectedData.paperSpend;

                    this.updateTextPrnSet(_selectedData.printCnt); //선택문서의 인쇄부수 표시를 갱신
                }
                //해제
                else {
                    //remove
                    this.selectedItemIdx = -1;
                    this.checkedList.splice(_idx, 1);

                    this.totalSpendPageCount -= _selectedData.paperSpend;
                }
                this.refresh();
            }
        } catch (e) {
            //console.log(e);
        }
    };

    this.updateDisplayListItems = function() {
        try {
            // [표시갱신]
            // 현재 페이지의  리스트정보 취득
            var pageDataList = this.getDataByPageIdx(this.currentPageIdx); //get Data For Display
            // 현재 페이지의 선택정보 취득
            //console.log(this.checkedList);
            var _btnIdKey = "btnDocItem";
            var _btnId, _item, _attr, _prevStatus, _status, _btnObj;
            var _idx = this.getStartIdx();
            //(this.currentPageIdx * this.config.countPerPage) + this.selectedItemIdx
            // 순차로 이동하며
            for (var i = 0, iMax = this.config.countPerPage; i < iMax; i++, _idx++) {
                _btnId = _btnIdKey + i;
                tmp = pageDataList[i];
                if (tmp) {
                    _btnObj = document.getElementById(_btnId);
                    _btnObj.style.visibility = "hidden";
                    //기본정보 갱신(선택적으로?)
                    this.updateDisplayListItem(tmp);
                    // 매수와 !Flag를 갱신(항상)
                    _status = (Common.indexOf(this.checkedList, _idx) > -1);

                    _attr = WidgetLib.getWidgetAttr(_btnId);
                    if (_idx == this.selectedItemIdx) {
                        if (_attr.onImg != Img.FILE_LIST_BUTTON_SELECTED) {
                            WidgetLib.setWidgetAttr(_btnId, { onImg: Img.FILE_LIST_BUTTON_SELECTED });
                        }
                    } else {
                        if (_attr.onImg != Img.FILE_LIST_BUTTON_ON) {
                            WidgetLib.setWidgetAttr(_btnId, { onImg: Img.FILE_LIST_BUTTON_ON });
                        }
                    }
                    _prevStatus = WidgetLib.getWidgetStatus(_btnId);
                    if (_prevStatus.on != _status) {
                        WidgetLib.setWidgetStatus(_btnId, { on: _status });
                    }
                    _btnObj.style.visibility = "visible";
                    Common.changeVisibility(_btnId, "block");
                } else {
                    //clear and hide
                    Common.changeVisibility(_btnId, "none");
                }

            }
        } catch (e) {
            KISUtil.debug(e);
        }
    };

    this.updateDisplayListItem = function(_data) {
        for (var img in _data.image) {
            Common.setImage(img, _data.image[img]);
        }
        for (var t in _data.text) {
            Common.setText(t, _data.text[t]);
        }
    };

    /**
     * [[전체선택/해제]]
     * [액션 공통 동작]
     * 인쇄매수 변경되었을 시 / 반영
     * 소요매수 재연산
     *
     * [데이터수정]
     * 체크리스트의 개수가 데이터의 개수와 같은경우
     * 해제
     * 체크리스트를 비움
     * 선택인덱스를 비움
     *
     * 다른경우
     * 선택
     * 체크리스트를 비움
     * 선택인덱스를 비움
     *
     * 체크리스트를 순차적으로 채움
     *
     * [표시갱신]
     * 현재 페이지의  리스트정보 취득
     * 현재 페이지의 선택정보 취득
     *
     * 순차로 이동하며
     * 매수와 !Flag를 갱신(항상)
     * ON이미지 및 상태 갱신
     * 기타 버튼의 상태갱신
     */
    this.selectAllItems = function() {
		KISUtil.debug("selectAllItems", "start");
        try {
            var _flag = (this.dataSource.length == this.checkedList.length);
            var offset = this.getStartIdx();

            this.selectedItemIdx = -1;
            this.checkedList = [];

            //전체선택
            if (!_flag) {
                //순서가 중요하지않으므로 기존 데이터를 삭제후 추가
                //체크리스트를 순차적으로 채움
                for (var i = 0, iMax = this.dataSource.length; i < iMax; i++) {
                    this.checkedList.push(i);
                }
            }
            //표시갱신
            this.refresh();
        } catch (e) {
            //console.log(e);
            KISUtil.debug("selectAllItems", "exception");
        }
    };

    /**
     * [[삭제]]
     * [액션공통동작-생략]
     *
     * [표시갱신]
     * 현재 페이지의  리스트정보 취득
     * 현재 페이지의 선택정보 취득
     *
     * 순차로 이동하며
     * 매수와 !Flag를 갱신(항상)
     * ON이미지 및 상태 갱신
     * 기타 버튼의 상태갱신
     *
     * 선택 항목을 삭제
     * (매니저가 관리중인)선택된 항목의 개수를 확인후
     * 개수가 1개 이상인경우 팝업을
     * 아닌경우 invalid를 출력
     */
    this.deleteItems = function() {
        var result = false;
        if (this.checkedList.length > 0) {
            //[데이터수정]
            this._eraseList(this.checkedList);
            //체크리스트를 비움
            this.checkedList = [];
            //선택인덱스를 비움
            this.selectedItemIdx = -1;
            //최종페이지 재연산
            this.maxPageIdx = Math.ceil(this.dataSource.length / this.config.countPerPage);
            //현재페이지 보정
            if (this.currentPageIdx > this.maxPageIdx) {
                this.currentPageIdx = this.maxPageIdx;
            }
            result = true;
        }

        return result;
    };

    /**
     * 선택항목 삭제
     */
    this._eraseList = function(lst) {
        //체크리스트의 항목을 값기준 역순으로 정렬
        var _lst = lst.sort(function(a, b) { return b - a; });
        for (var i = 0, iMax = _lst.length; i < iMax; i++) {
            //데이터소스에서 체크된항목을 제거
            this.dataSource.splice(_lst[i], 1);
        }
    };

    /**
     * [[페이징]]
     * [액션 공통 동작]
     * 인쇄매수 변경되었을 시 / 반영
     * 소요매수 재연산
     *
     * [데이터수정] - 없음
     * 이동할 페이지 인덱스 비교(최대 최소) OK?
     * 페이지 인덱스 수정
     *
     * [표시갱신]
     * 현재 페이지의  리스트정보 취득
     * 현재 페이지의 선택정보 취득
     *
     * 순차로 이동하며 리스트 정보를 수정(페이지 전환시에만)
     * 매수와 !Flag를 갱신(항상)
     * ON이미지 및 상태 갱신
     * 기타 버튼의 상태갱신
     */

    /**
     * 이전 페이지로 이동
     */
    this.goPrevPage = function() {
        if (this.currentPageIdx > 1) {
            this.currentPageIdx--;
            this.refresh();
        } else {
            KISUtil.debug("DocListManager/goPrevPage/currentPageIdx", this.currentPageIdx);
        }
    };

    /**
     * 다음 페이지로 이동
     */
    this.goNextPage = function() {
        if (this.currentPageIdx < this.maxPageIdx) {
            this.currentPageIdx++;
            this.refresh();
        } else {
            KISUtil.debug("DocListManager/goNextPage/currentPageIdx", this.currentPageIdx);
        }
    };

    this.refresh = function() {
        this.updateInvalidFlag();
        //표시갱신
        this.updateDisplayListItems();
        this.updateBtnStatus();
    };

    /**
     * 선택된 리스트의 인쇄매수를 반영
     */
    this.updateQuantity = function(_func, _flg) {
        if (this.selectedItemIdx > -1) {
            var _doc = this.dataSource[this.selectedItemIdx];
            if (!_doc.prnType) {
                //set data
                _func(_doc, _flg);

                var _selectedData = this.dataSource[this.selectedItemIdx];
                this.totalSpendPageCount -= _selectedData.paperSpend;
                _selectedData.paperSpend = getPaperSpend(_selectedData);
                this.totalSpendPageCount += _selectedData.paperSpend;
            }
        }
    };

    Extend(this.config, opt);
    this.init();
};

function getPaperSpend(_item) {
    var _nup = parseInt(glbInfo.nup[_item.nupIdx].value);
    return Math.ceil(_item.pageCnt / _nup) * _item.printCnt;
};

Date.prototype.toString = function() {
    switch (arguments.length) {
        case 1:
            var format = arguments[0];
            switch (typeof format) {
                case "string":
                    var result = format;
                    var _arg0 = this.getFullYear().toString();
                    var _arg1 = (this.getMonth() + 1).toString(); //0-11
                    var _arg2 = this.getDate().toString();
                    var _arg3 = this.getHours().toString();
                    var _arg4 = this.getMinutes().toString();
                    var _arg5 = this.getSeconds().toString();

                    if (_arg1.length == 1) _arg1 = "0" + _arg1;
                    if (_arg2.length == 1) _arg2 = "0" + _arg2;
                    if (_arg3.length == 1) _arg3 = "0" + _arg3;
                    if (_arg4.length == 1) _arg4 = "0" + _arg4;
                    if (_arg5.length == 1) _arg5 = "0" + _arg5;

                    result = result.replace(/yyyy/gi, _arg0)
                        .replace(/MM/gi, _arg1)
                        .replace(/dd/gi, _arg2)
                        .replace(/HH/gi, _arg3)
                        .replace(/mm/gi, _arg4)
                        .replace(/ss/gi, _arg5);
                    return result;
                case "object":
                    break;
                default:
                    break;
            }
            break;
        default:
            this.__proto__.toString(arguments);
            break;
    }
};

/**
 * 子ノードを削除する。
 * @param id 親ノードのID
 */
function removeChildObj(id) {
    var obj = document.getElementById(id);
    if (obj) obj.innerHTML = "";
}

function createXMLHttpRequest() {
    var obj;

    if (window.XMLHttpRequest) {
        obj = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        try {
            obj = new ActiveXObject("Msxml2.XMLHTTP");
        } catch (e) {
            obj = new ActiveXObject("Microsoft.XMLHTTP");
        }
    } else {
        return null;
    }

    return obj;
}

/**************************************************************
 * @contents set data in config folder
 * @public
 * @return
 * @Lang EN
 **************************************************************/
function save_content_to_file(content, filename) {
    KISUtil.debug("save_content_to_file/" + content, filename);
    if (flg_Dummy_Beep) return; //개발중엔 동작하지 않도록
    var httpRequest = createXMLHttpRequest();
    httpRequest.open("PUT", filename, true);
    httpRequest.onreadystatechange = onReadyStateChangeEventHandler["set"];
    httpRequest.send(content);
}

/**************************************************************
 * @contents Get Status Index from file
 * @public
 * @return
 * @Lang EN
 **************************************************************/
function load_content_to_file(filePath, callback) {
    var httpRequest = createXMLHttpRequest();

    //_requester.onreadystatechange = onReadyStateChangeEventHandler["get"];
    httpRequest.onreadystatechange = function() {
        // inline function to check the status
        // of our request
        // this is called on every state change
        //console.log("onreadystatechange/httpRequest.readyState:"+this.readyState+"/httpRequest.status:"+this.status);
        if (this.readyState === 4) {
            if (this.status === 200) {
                callback.call(this);
                // call the callback function
            } else {
                callback.call(this);
            }
        }
    };

    httpRequest.open("GET", filePath, true);
    httpRequest.send();
}

var onReadyStateChangeEventHandler = {
    set: function() {
        if (this.readyState == 4) {
            if (this.status == 200) {
                //KISUtil.debug("save_content_to_file",JSON.stringify(this));
                //alert("setConfigData success");
            } else {
                //alert("setConfigData fail");
                //KISUtil.debug("save_content_to_file",JSON.stringify(this));
                if (flg_Dummy_Beep) return;
                var param = { title: Msg.WarnPopup.title, type: "", message: Msg.errorMessage.ERRCODE017, targetPage: true };
                WarnPopup._message = param;
                PageManager.changePage(WarnPopup, PageManager.type.NORMAL);
            }
        } else {
            KISUtil.debug("save_content_to_file/this.readyState", this.readyState);
        }
    },

    /* 사용하지 않음 */
    get: function() {
        if (flg_Dummy_Beep) return;
        if (this.readyState == 4) {
            if (this.status == 200) {
                var response = this.responseText;
                callback.call(response);

                /* Browser Exception */
                BrowserExt.browserVersion = 4;
                /* Browser Privilege accept */
                if (BrowserExt.EnablePrivilege() == true) {
                    //loginStatus = "user";
                    //SSMILib.GetUsagePrnCnt();
                } else {
                    KISUtil.debug("load_content_to_file/onReadyStateChangeEventHandler/EnablePrivilege", "false");
                    var param = { title: Msg.WarnPopup.title, type: "", message: Msg.errorMessage.ERRCODE015, targetPage: true };
                    WarnPopup._message = param;
                    PageManager.changePage(WarnPopup, PageManager.type.NORMAL);
                }

            } else {
                KISUtil.debug("load_content_to_file/onReadyStateChangeEventHandler/status", this.status);
                var param = { title: Msg.WarnPopup.title, type: "", message: Msg.errorMessage.ERRCODE016, targetPage: true };
                WarnPopup._message = param;
                PageManager.changePage(WarnPopup, PageManager.type.NORMAL);
            }
        }
    }
};

var PrintCountManager = function() {
    this.config = { min: 1, max: 1000, enableFlag: true };
    this.currentNum = 1;
    this.updateDisplay = function(num) {
        //console.log("PrintCountManager/updateDisplay/num:"+num);
    };

    this.setNum = function(num) {
        this.insertFlg = false;
        this.currentNum = num;
        this.updateDisplay(this.currentNum);
    };

    this.setEnableFlag = function(flg) {
        this.config.enableFlag = flg;
    };

    this.getEnableFlag = function() {
        return this.config.enableFlag;
    };

    this.insertNum = function(num) {
        var result = false;
        //check flag
        if (this.config.enableFlag) {
            if (this.insertFlg) {
                //*10+num
                this.currentNum = this.currentNum * 10 + num;
                result = true;
            } else {
                if (num != 0) {
                    this.insertFlg = true;
                    this.currentNum = num;
                    result = true;
                }
            }
            if (this.currentNum > this.config.max) {
                this.currentNum = this.config.max;
                result = false;
            }
            this.updateDisplay(this.currentNum);
        }

        return result;
    };

    this.removeNum = function() {
        var result = false;
        try {
            //check flag
            if (this.currentNum > 9) {
                result = true;
                this.currentNum = (this.currentNum - (this.currentNum % 10)) / 10;
            } else {
                this.insertFlg = false;
                if (this.currentNum > this.config.min) {
                    result = true;
                    this.currentNum = this.config.min;
                }
            }
            this.updateDisplay(this.currentNum);
        } catch (e) {
            KISUtil.debug(e);
        }

        return result;
    };

    this.clearNum = function() {
        //reset flag
        this.insertFlg = false;
        this.currentNum = this.config.min;
        this.updateDisplay(this.currentNum);
    };

    this.setStatus = function(flag) {
        this.config.enableFlag = flag;
    };
};

/**
 *  deepCopy method
 */
var extendDeep = function(parent, child) {
    var toStr = Object.prototype.toString,
        astr = "[object Array]";

    child = child || {};

    for (var j in parent) {
        if (parent.hasOwnProperty(j)) {
            if (parent[j] == null & child[j] == undefined) {
                child[j] = null;
            } else if (typeof parent[j] === "object") {
                child[j] = (toStr.call(parent[j]) === astr) ? [] : {};
                extendDeep(parent[j], child[j]);
            } else {
                child[j] = parent[j];
            }
        } else {
            //pass
        }
    }

    return child;
};

/**
 * 정책 판단룰을 이용한 판단 모듈
 *
 * 프린트옵션정책(강제흑백) - 0:적용, 1:미적용
 * 문서컬러 - 0:흑백,1:컬러
 * 복합기기능 - 0:기능제한없음,1:흑백만사용가능,2:기능제한(컬러/흑백가능),3:기능제한(컬러가능/흑백불가),4:기능제한(컬러불가/흑백가능),5:기능제한(컬러/흑백불가),6:사용량제한
 */
function Validator() {
    this.rule = null;

    this.forceBW = { none: 0, forceBW: 1 };
    this.forceNup = { one: 0, others: 1 };
    this.forceDuplex = { simplex: 0, duplex: 1 };
    //this.color = {bw:0, color:1};
    this.color = { bw: 1, color: 0 };
    this.forbides = { none: 0, bwOnly: 1, bothUseable: 2, colorUsable: 3, bwUsable: 4, noneUsable: 5, usageLimit: 6 };

    this.getBtnStatusByPolicy = function(_forbid, _forcedNup, _forcedDuplex, _forceBW, _doc) {
        var _policy = { success: false };
        if (_doc.prnType) { //PS문서 체크 스킵
            _policy = { success: true, status: { invalidFlag: 0, printStatus: true } };
        } else {
            if (this.rule != null && _policy != null && _doc.colorIdx != null && _forbid != null) {
                try {
                    //result.status = this.rule[_policy][_docColor][_forbid];
                    _policy.status = this.rule[_forbid][_forcedNup][_forcedDuplex][_forceBW][_doc.colorIdx];
                    _policy.success = true;
                } catch (e) {
                    KISUtil.debug("Validator/getBtnStatusByPolicy", _policy + "," + _doc.colorIdx + "," + _forbid);
                }
            }

            //사용량제한중 사용량을 넘어서는 케이스와 그렇지 않은 케이스간의 메시지 리매핑처리
            //추후 두개의 플래그를 조합하는 형태로 리팩토링 되어야함
            if (glbDataSet.userPolicyInfo.functionCtrl == 6) {
                if (_doc.overFlow) {
                    switch (_policy.status.msg) {
                        case "FORCE_BW":
                        case "FORCE_DUPLEX":
                        case "FORCE_BW_DUPLEX":
                        case "FORCE_NUP":
                        case "FORCE_BW_NUP":
                        case "FORCE_NUP_DUPLEX":
                        case "FORCE_BW_NUP_DUPLEX":
                        case "":
                            _policy.status.msg = _policy.status.msg + "_USAGE_LIMIT_OVER";
                            break;
                        default:
                            //KISUtil.debug("getBtnStatusByPolicy/overflow",JSON.stringify(_policy));
                            break;
                    }
                    _policy.status.invalidFlag = 2;
                    _policy.status.printStatus = false;
                } else {
                    switch (_policy.status.msg) {
                        case "USAGE_LIMIT_OVER":
                        case "FORCE_BW_USAGE_LIMIT_OVER":
                        case "FORCE_DUPLEX_USAGE_LIMIT_OVER":
                        case "FORCE_BW_DUPLEX_USAGE_LIMIT_OVER":
                        case "FORCE_NUP_USAGE_LIMIT_OVER":
                        case "FORCE_BW_NUP_USAGE_LIMIT_OVER":
                        case "FORCE_NUP_DUPLEX_USAGE_LIMIT_OVER":
                        case "FORCE_BW_NUP_DUPLEX_USAGE_LIMIT_OVER":
                            _policy.status.msg = _policy.status.msg.replace("_USAGE_LIMIT_OVER", "");
                            break;
                        default:
                            //KISUtil.debug("getBtnStatusByPolicy/notOverflow",JSON.stringify(_policy));
                            break;
                    }
                    _policy.status.invalidFlag = 0;
                    _policy.status.printStatus = true;
                }
            }
        }

        return _policy;
    };

    this.init = function() {
        var printRule = getPrintRule();
        if (printRule instanceof Array) this.rule = extendDeep(printRule, this.rule);
    };
}

/**
 * 정책 판단룰을 이용한 판단 모듈 <- 다수 문서 선택시
 *
 * 프린트옵션정책(강제흑백) - 0:적용, 1:미적용
 * 문서컬러 - 0:흑백,1:컬러
 * 복합기기능 - 0:기능제한없음,1:흑백만사용가능,2:기능제한(컬러/흑백가능),3:기능제한(컬러가능/흑백불가),4:기능제한(컬러불가/흑백가능),5:기능제한(컬러/흑백불가),6:사용량제한
 */
function ValidatorMulti() {
    this.rule = null;

    this.init = function() {
        var printRule = getPrintRule();
        if (printRule instanceof Array) this.rule = extendDeep(printRule, this.rule);
    };

    this.getBtnStatusByPolicy = function(_functionCtrl, _forcedNup, _forcedDuplex, _forceBW, _docs) {
        var _policy = { success: false, status: { msg: "", printStatus: true, invalidFlag: 0 } };
        if (this.rule != null && _policy != null && _functionCtrl != null) {
            _policy.status = this.rule[_functionCtrl][_forcedNup][_forcedDuplex][_forceBW][1]; //디폴트 설정
            _policy.success = true;

            //기능제한 체크
            if (_functionCtrl == 1 || _functionCtrl == 4) { //1:흑백만사용가능, 4:기능제한(컬러불가/흑백가능)
                for (var i = 0; i < _docs.length; i++) {
                    var tmpIdx = PrintSettingMultiPopup._dataSet.selectedDocInfo['multicolorIdx'];
                    if (_docs[i].boxId) {
                        if (_docs[i].colorIdx == 0) { //여러건 문서중, private print 문서+ 컬러의 경우에는 print 불가 즉시 처리
                            _policy.status = this.rule[_functionCtrl][_forcedNup][_forcedDuplex][_forceBW][0];
                            _policy.success = true;
                            break;
                        }
                    }

                    if (_forceBW == 1) { //기능제한(흑백만 가능) + 기본흑백/강제흑백 적용시
                        _policy.status.printStatus = (tmpIdx == 0 || tmpIdx == 2) ? true : false;
                        _policy.success = true;
                        break;
                    } else {
                        //컬러 풀다운[기본값, 컬러]이고 문서중에 컬러가 있거나 or 컬러 풀다운[컬러]이고 흑백이지만 원본이 컬러인 경우)
                        if ((tmpIdx == 0 || tmpIdx == 1) && _docs[i].colorIdx == 0 || (tmpIdx == 1 && _docs[i].colorIdx == 1 && _docs[i].originColorIdx == 0)) { //컬러 문서
                            _policy.status = this.rule[_functionCtrl][_forcedNup][_forcedDuplex][_forceBW][0];
                            _policy.success = true;
                            break;
                        }
                    }
                }
            } else if (_functionCtrl == 3) { //3:기능제한(컬러가능/흑백불가)
                _policy.status = this.rule[_functionCtrl][_forcedNup][_forcedDuplex][_forceBW][0];
                for (var i = 0; i < _docs.length; i++) {
                    var tmpIdx = PrintSettingMultiPopup._dataSet.selectedDocInfo['multicolorIdx'];
                    if (_docs[i].boxId) {
                        if (_docs[i].colorIdx == 1) { //여러건 문서중, private print 문서+ 흑백의 경우에는 print 불가
                            _policy.status = this.rule[_functionCtrl][_forcedNup][_forcedDuplex][_forceBW][1];
                            _policy.success = true;
                            break;
                        }
                    }
                    //흑백(원본) 문서가 존재하거나 || 컬러문서인데 흑백으로 변경하거나 || 기본값이고 흑백일 때
                    if (_docs[i].originColorIdx == 1 || (tmpIdx == 2 && _docs[i].originColorIdx == 0) || (tmpIdx == 0 && _docs[i].colorIdx == 1)) {
                        _policy.status = this.rule[_functionCtrl][_forcedNup][_forcedDuplex][_forceBW][1];
                        _policy.success = true;
                        break;
                    }
                }
            } else if (_functionCtrl == 5) { // 5:기능제한(컬러/흑백불가)
                _policy.status = this.rule[_functionCtrl][_forcedNup][_forcedDuplex][_forceBW][0];
                _policy.success = true;
            }

            if (_functionCtrl == 6) { //사용량 제한
                switch (_policy.status.msg) {
                    case "USAGE_LIMIT_OVER":
                    case "FORCE_BW_USAGE_LIMIT_OVER":
                    case "FORCE_DUPLEX_USAGE_LIMIT_OVER":
                    case "FORCE_BW_DUPLEX_USAGE_LIMIT_OVER":
                        _policy.status.msg = _policy.status.msg.replace("_USAGE_LIMIT_OVER", "");
                        break;
                    default:
                        break;
                }

                _policy.success = true;
                _policy.status.invalidFlag = 0;
                _policy.status.printStatus = true;

                for (var i = 0; i < _docs.length; i++) {
                    if (_docs[i].overFlow) { //문서 다수 선택시 1건이라도 overFlow 발생시에는 print 불가
                        switch (_policy.status.msg) {
                            case "FORCE_BW":
                            case "FORCE_DUPLEX":
                            case "FORCE_BW_DUPLEX":
                            case "":
                                _policy.status.msg = _policy.status.msg + (_policy.status.msg == "" ? "" : "_") + "USAGE_LIMIT_OVER";
                                break;
                            default:
                                break;
                        }
                        _policy.success = true;
                        _policy.status.invalidFlag = 2;
                        _policy.status.printStatus = false;
                        break;
                    }
                }
            }
        }

        return _policy;
    };
};

/**
 * 文書の更新日時をYYYY/MM/DD　HH:MM:SSの形式で変える
 * @param {string} str 文書の更新日時
 * @return {string} dateStr 文書の更新日時（YYYY/MM/DD　HH:MM:SSの形式）
 */
function getDateString(str) {
    if (!str) {
        return;
    }

    var dateStr = str.replace(/-/g, '/');

    var dateEndPoint = dateStr.indexOf('T');
    var ymdStr = dateStr.substring(0, dateEndPoint);

    var timeEndPoint = dateStr.indexOf('+');
    var timeStr = dateStr.substring(dateEndPoint + 1, timeEndPoint);

    return ymdStr + " " + timeStr;
}

/**
 * 화면표시용 Data로 가공
 */
function convertToVMData(_lst) {
    var _result = {},
        _used = [],
        _notUsed = [],
        _tmp, _remain;

    //리스트 표시 제한 적용
    var iMax = (_lst.length > glbConfig.DATA.JOB_LIST_COUNT) ? glbConfig.DATA.JOB_LIST_COUNT : _lst.length;
    for (var i = 0; i < iMax; i++) {
        try {
            _tmp = {};
            _obj = _lst[i];
            _tmp.UUID = _obj.uuId;
            _tmp.docName = _obj.docName;
            _tmp.driverType = _obj.driverType;
            _tmp.prnType = (_obj.prnType == "Y");
            //_tmp.prnType = true;
            //초기화 사용가능매수보다  소요매수가 큰경우 true
            _tmp.printInvalidType = PRINTABLE_VALID_TYPE.none;

            //2017.11 KIS [v1.5] SmartUI 복수의 Print Server 대응 refs #4502
            _tmp.serverIdx = (typeof arguments[1] != 'undefined') ? parseInt(arguments[1]) : -1;

            //2017.12 KIS [ABL] 모바일 프린트 대응판 refs #4535
            _tmp.driverType = _obj.driverType;

            if (!_tmp.prnType) {
                _tmp.printDate = _obj.printDate;
                _tmp.pageCnt = parseInt(_obj.pageCnt);
                _tmp.printCnt = parseInt(_obj.printCnt);
                _tmp.useYn = (_obj.useYn == "Y");

                //_tmp.originColorIdx = _tmp.colorIdx = glbInfo.getIndexByKey("color", _obj.color, 1);	//1은 default값(흑백)
                /*
                if(_obj.driverType != "MOBILE"){
                	_tmp.originColorIdx = glbInfo.getIndexByKey("color", _obj.color, 1);	//1은 default값(흑백)
                	_tmp.colorIdx = glbInfo.getIndexByKey("destColor", _obj.destColor, 1);	//1은 default값(흑백)
                	if(glbDataSet.userPolicyInfo.forcedBlack||glbDataSet.userPolicyInfo.defaultBlack){		//방어적 코딩, 강제흑백상태에서 컬러문서가 온경우 흑백으로 전환
                		_tmp.colorIdx = 1;
                	}
                	_tmp.originPlexIdx = _tmp.plexIdx = glbInfo.getIndexByKey("plex", _obj.duplex, 0);		//0은 default값
                	//방어적 코딩, 강제양면상태에서 단면문서가 온경우 양면으로 전환, 1page이상인경우도 포함
                	//단면에 대한 조건이 빠져있던 부분 대응(2013/12/03 son.ch)
                	if((_tmp.plexIdx === 0 && glbDataSet.userPolicyInfo.forcedDuplex) && (1 < _tmp.pageCnt)){
                		_tmp.plexIdx = 1;																	// 1:DL
                	}
                	_tmp.originNupIdx = _tmp.nupIdx = glbInfo.getIndexByKey("nup", _obj.nUp, 0);			//0은 default값
                	_tmp.srcNupIdx = glbInfo.getIndexByKey("nup", _obj.SRCnUp, 0);							//0은 default값		//2013/4/3사양변경대응
                }else{
                	_tmp.colorIdx = _tmp.originColorIdx = glbInfo.getIndexByKey("color", _obj.color, 1);	//1은 default값(흑백)
                	_tmp.plexIdx = _tmp.originPlexIdx = glbInfo.getIndexByKey("plex", _obj.duplex, 0);		//0은 default값
                	_tmp.nupIdx = _tmp.originNupIdx = _tmp.srcNupIdx = glbInfo.getIndexByKey("nup", _obj.SRCnUp, 0);	//0은 default값(1up)
                }
                */
                _tmp.originColorIdx = glbInfo.getIndexByKey("color", _obj.color, 1); //1은 default값(흑백)
                _tmp.colorIdx = glbInfo.getIndexByKey("destColor", _obj.destColor, 1); //1은 default값(흑백)
                if (glbDataSet.userPolicyInfo.forcedBlack || glbDataSet.userPolicyInfo.defaultBlack) { //방어적 코딩, 강제흑백상태에서 컬러문서가 온경우 흑백으로 전환
                    _tmp.colorIdx = 1;
                }
                _tmp.originPlexIdx = _tmp.plexIdx = glbInfo.getIndexByKey("plex", _obj.duplex, 0); //0은 default값
                //방어적 코딩, 강제양면상태에서 단면문서가 온경우 양면으로 전환, 1page이상인경우도 포함
                //단면에 대한 조건이 빠져있던 부분 대응(2013/12/03 son.ch)
                if ((_tmp.plexIdx === 0 && glbDataSet.userPolicyInfo.forcedDuplex) && (1 < _tmp.pageCnt)) {
                    _tmp.plexIdx = 1; // 1:DL
                }
                _tmp.originNupIdx = _tmp.nupIdx = glbInfo.getIndexByKey("nup", _obj.nUp, 0); //0은 default값
                //방어적 코딩, 강제 2up상태에서 1up문서가 온경우 2up으로 전환, 1page이상인 경우도 포함.
                if ((_tmp.nupIdx === 0 && glbDataSet.userPolicyInfo.forced2Up) && (1 < _tmp.pageCnt)) {
                    _tmp.nupIdx = 1; // 1:DL
                }
                _tmp.srcNupIdx = glbInfo.getIndexByKey("nup", _obj.SRCnUp, 0); //0은 default값		//2013/4/3사양변경대응


                _tmp.deleteIdx = glbInfo.getIndexByKey("delete", glbConfig.DATA.DELETE, 0); //0은 default값

                //사용가능량
                _remain = glbInfo.usagePrnCnt.remain[_tmp.colorIdx];
                //소요매수 계산
                _tmp.paperSpend = getPaperSpend(_tmp);

                if (_tmp.useYn) {
                    _used.push(_tmp);
                } else {
                    _notUsed.push(_tmp);
                }
            } else {
                _notUsed.push(_tmp);
            }
        } catch (e) {
            //console.log(e);
            KISUtil.debug("convertToVMData", "exception");
            //KISUtil.debug("convertToVMData/_lst",JSON.stringify(_lst));
        }
    }
    _result.usedFileCount = _used.length;
    _result.lst = _notUsed.concat(_used);

    return _result;
}

/**
 * 인쇄용 Data로 가공
 */
function convertToPRNData(_lst) {
    var _result = [],
        _tmp;
    for (var i = 0, iMax = _lst.length; i < iMax; i++) {
        try {
            _tmp = {};
            _obj = _lst[i];
            _tmp.uuId = _obj.UUID;
            _tmp.prnType = _obj.prnType ? "Y" : "N";

            if (_obj.prnType) {
                _tmp.pageCnt = 1;
                _tmp.printCnt = 1;
                _tmp.prnSave = "N";
                _tmp.color = "C";
                _tmp.duplex = "S";
                _tmp.nUp = "1";
            } else {
                //_tmp.docName = _obj.docName;
                //_tmp.printDate = _obj.printDate;
                _tmp.pageCnt = _obj.pageCnt;
                _tmp.printCnt = _obj.printCnt;
                _tmp.prnSave = (glbInfo["delete"][_obj.deleteIdx].key == "1") ? "Y" : "N";
                //_tmp.useYn = _obj.useYn ? "Y" : "N";
                _tmp.color = glbInfo.color[_obj.colorIdx].key;
                _tmp.duplex = glbInfo.plex[_obj.plexIdx].key;
                _tmp.nUp = glbInfo.nup[_obj.nupIdx].key;
            }

            _result[i] = _tmp;
        } catch (e) {
            //console.log(e);
            KISUtil.debug("convertToPRNData", "exception");
            //KISUtil.debug("convertToPRNData/_lst", JSON.stringify(_lst));
        }
    }

    return _result;
}

function parseDate(str) //2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
{
    if (!str) {
        return "";
    }

    var dateStr = str.replace('-', '/');
    dateStr = dateStr.replace('-', '/');

    var dateEndPoint = dateStr.indexOf('T');
    var ymdStr = dateStr.substring(0, dateEndPoint);

    var timeEndPoint = dateStr.indexOf('+');
    var timeStr = dateStr.substring(dateEndPoint + 1, timeEndPoint);

    return ymdStr + " " + timeStr;
}

function sortingLogic(a, b) //2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
{
    // 2018.01.10 ABL Sorting 방식 변경
    if (a.printDate < b.printDate)
        return -1;
    if (a.printDate > b.printDate)
        return 1;
    return 0;
}

// 개인 프린트 및 Multi Server 대응으로 선택출력 List에서 Job이 중복 표시 되는 오류 수정
function regJobCheck(uuid, serverIdx) {
    var result = true;
    for (var i = 0; i < glbDataSet.docList.length; i++) {
        if ((glbDataSet.docList[i].UUID == uuid) && (glbDataSet.docList[i].serverIdx == serverIdx)) {
            result = false;
        }
    }
    return result;
}

/**
 * 신규 Password 입력시 정책에 따른 확인용 함수
 *
**/
function checkPasswordPolicy(password)
{
	// Password 최대 길이 30(1byte)
	// 최소 길이 1로 범위는 1~30 까지
	// password = password + "가"; // Test용
	var cntCapitalChar = 	parseInt(glbInfo.userInfo.passwordPolicy.neededCapitalCharCnt);
	var cntDigitChar = 		parseInt(glbInfo.userInfo.passwordPolicy.neededDigitCnt);
	var cntSpecialChar = 	parseInt(glbInfo.userInfo.passwordPolicy.neededSpecialCharCnt);
	var cntMinPW = 			parseInt(glbInfo.userInfo.passwordPolicy.minPasswordCnt);
	var cntMaxPW = 			parseInt(glbInfo.userInfo.passwordPolicy.maxPasswordCnt);

	var result = "OK";
	// 정규식 정리
	var spaceExp	= /\s/g;		// 공백 확인용
	var upperExp 	= /[^A-Z]/g;	// 대문자 확인용
	var digitExp 	= /[^0-9]/g;	// 숫자 확인용
	var specialExp	= /[^\{\}\[\]\/?.,;:|\)*~`!^\-_+<>@\#$%&\\\=\(\'\"]/gi;
	var apphabetExp	= /[^a-zA-Z]/g;	// 영문 확인용
	var cntPassword = password.length;
	var inputErrCnt = password.length;

	// 공백 채크 FAIL_SPACE
	/*
	if(password.match(spaceExp)){
		return result = "FAIL_SPACE";
	}
	*/
	var index = password.indexOf(' ');
	// match 함수를 사용할 수 없을 경우에 사용
	if( -1 != password.indexOf(' ')){
		return result = "FAIL_SPACE";
	}

	// 대문자 포함 확인 FAIL_CAPITAL_CHAR
	if(cntCapitalChar > 0){
		var upper = password.replace(upperExp, '');
		if(cntCapitalChar > upper.length){
			return result = "FAIL_CAPITAL_CHAR";
		}
	}

	// 숫자 포함 확인 FAIL_DIGIT
	var digit = password.replace(digitExp, '');
	inputErrCnt = inputErrCnt - digit.length;
	if(cntDigitChar > 0){
		//var digit = password.replace(digitExp, '');
		//inputErrCnt = inputErrCnt - digit.length;
		if(cntDigitChar > digit.length){
			return result = "FAIL_DIGIT";
		}
	}

	// 특수문자 포함 확인 FAIL_SPECIAL_CHAR
	var special = password.replace(specialExp, '');
	inputErrCnt = inputErrCnt - special.length;
	if(cntSpecialChar > 0){
		//var special = password.replace(specialExp, '');
		//inputErrCnt = inputErrCnt - special.length;
		if(cntSpecialChar > special.length){
			return result = "FAIL_SPECIAL_CHAR";
		}
	}

	// 영문 확인
	var check_eng = password.replace(apphabetExp, '');
	inputErrCnt = inputErrCnt - check_eng.length;
	if(inputErrCnt > 0){
		return result = "FAIL_INPUT_TEXT";
	}

	// 최소 길이 확인 FAIL_MIN_LENGTH
	if(cntMinPW > cntPassword){
		return result = "FAIL_MIN_LENGTH";
	}

	// 최대 길이 확인 FAIL_MAX_LENGTH
	if(cntMaxPW < cntPassword){
		return result = "FAIL_MAX_LENGTH";
	}

	return result;
}

/**
 * 신규 Password 입력시 정책에 따른 안내문구 생성용
 *
**/
function noticePasswordPolicy()
{
	// Password 최대 길이 30(1byte)
	// 최소 길이 1로 범위는 1~30 까지
	var result = " ";
	if(glbInfo.userInfo.passwordPolicy){
		var cntCapitalChar = 	parseInt(glbInfo.userInfo.passwordPolicy.neededCapitalCharCnt);
		var cntDigitChar = 		parseInt(glbInfo.userInfo.passwordPolicy.neededDigitCnt);
		var cntSpecialChar = 	parseInt(glbInfo.userInfo.passwordPolicy.neededSpecialCharCnt);
		var cntMinPW = 			parseInt(glbInfo.userInfo.passwordPolicy.minPasswordCnt);
		var cntMaxPW = 			parseInt(glbInfo.userInfo.passwordPolicy.maxPasswordCnt);

		var temp = (Msg.PASSWORD_EXP.PW_LENGTH_GUIDE).replace(/XX/, glbInfo.userInfo.passwordPolicy.minPasswordCnt);
		result = temp.replace(/YY/, glbInfo.userInfo.passwordPolicy.maxPasswordCnt);

		// 대문자 포함 확인 FAIL_CAPITAL_CHAR
		if(cntCapitalChar > 0){
			result = result + (Msg.PASSWORD_EXP.PW_CAPITAL_GUIDE).replace(/XX/, glbInfo.userInfo.passwordPolicy.neededCapitalCharCnt);
		}

		// 숫자 포함 확인 FAIL_DIGIT
		if(cntDigitChar > 0){
			result = result + (Msg.PASSWORD_EXP.PW_DIGIT_GUIDE).replace(/XX/, glbInfo.userInfo.passwordPolicy.neededDigitCnt);
		}

		// 특수문자 포함 확인 FAIL_SPECIAL_CHAR
		if(cntSpecialChar > 0){
			result = result + (Msg.PASSWORD_EXP.PW_SPECIAL_GUIDE).replace(/XX/, glbInfo.userInfo.passwordPolicy.neededSpecialCharCnt);
		}

		result = result + Msg.PASSWORD_EXP.PW_SPACE_GUIDE;
	}

	return result;
}
var ServiceManager = {
	targetFrameId:"",
	targetFrameEle:null,
	currentService:"",
	/**
	 * 서비스 매니저 초기화 
	 */
	init : function(param){
		if(param.targetFrameId && param.targetFrameLyrId){
			this.targetFrameId = param.targetFrameId;
			this.targetFrameLyrId = param.targetFrameLyrId;
			this.targetFrameEle = document.getElementById(this.targetFrameId);
			this.targetFrameEle.seamless = true;
		}
		else{
			//TODO: throw exception();
		}
	},
	/**
	 * 서비스 호출 
	 */
	callService : function(service, arg){
		//파라미터 점검
		//만약 현재 다른 서비스 사용중인경우 에러를 날려줌 
		if(!this.currentService && service) {
			//iframe모드일때
			if(glbConfig.SERVICE_CALL_MODE){
				this.currentService = service.name;
				//Note: jQuery code 배제
				//$("#"+this.targetFrameId).on("load",_onIframeLoadEvent).attr("src",service.url).prev().show();
				//$("#"+this.targetFrameLyrId).show();
				//$("#"+this.targetFrameId).contents().on("load",_onIframeLoadEvent);
				
				var _frame = document.getElementById(this.targetFrameId);
				//setEvent(_frame, "load", _onIframeLoadEvent); //trigger는 서비스에서 하도록 변경
				//setEvent((_frame.contentWindow.document || _frame.contentDocument), "load", _onIframeLoadEvent);
				
				_frame.setAttribute("src",service.url);
				_frame.previousSibling.previousSibling.style.display="block";

				var _lyr = document.getElementById(this.targetFrameLyrId);
				_lyr.style.display="block";
			}
			else{
				var loc = "changeDisplay:URL:" + service.url.replace(/http:/,"http-v5:")+";DISP:0";
				BrowserExt.SetScreenChange(loc);
			}
			if(arg&&arg.successFunc){
				arg.successFunc.apply(this);
			}
		}
		else{
			//TODO: throw exception();
			if(arg&&arg.errorFunc){
				arg.errorFunc.apply(this);
			}
		}
		if(arg&&arg.doneFunc){
			arg.doneFunc.apply(this);
		}
		function _onIframeLoadEvent(){
			//console.log("readyToDisplay");
			//console.log(this);
			//$(this).show().off("load").prev().hide();
			this.previousSibling.previousSibling.style.display="none";
			releaseEvent(this,"load",_onIframeLoadEvent);
			this.style.display="block";
		}
		function setEvent(_obj,_eventName,_event){
			if(_obj.attachEvent)_obj.attachEvent(_eventName,_event);
			else if(_obj.addEventListener)_obj.addEventListener(_eventName,_event,false);
		}
		function releaseEvent(_obj,_eventName,_event){
			if(_obj.detachEvent)_obj.detachEvent(_eventName,_event);
			else if(_obj.removeEventListener)_obj.addEventListener(_eventName,_event,false);
		}
	},
	displayIframe:function(){
		this.targetFrameEle.previousSibling.previousSibling.style.display="none";
		this.targetFrameEle.style.display="block";
	},
	/**
	 * 서비스를 종료함 
	 */
	removeService : function(){
		if(this.currentService){
			Common.changeVisibility(this.targetFrameLyrId,"none");
			//this.targetFrameEle.setAttrubute("src","");
			this.targetFrameEle.removeAttribute("src");
			this.targetFrameEle.style.display = "none";
			//$("#"+this.targetFrameLyrId).hide();
			//$("#"+this.targetFrameId).attr("src","").hide();
			this.currentService="";
		}
	},
	excuteScript:function(func){
		if(flg_Dummy_Beep&&this.targetFrameEle){
			//프래임 내 페이지에서 실행하는 방법
			//with(document.getElementsByTagName("iframe")[0].contentWindow){
			//PageManager.changePage(PrintingPopup , PageManager.type.NORMAL);
			//}
			this.targetFrameEle.contentWindow.eval.apply(this.targetFrameEle.contentWindow,func);
		}
	},
	
	/**
	 * 서비스를 종료함 
	 */
	refreshService : function(){
		if(this.currentService){
			var _frame = document.getElementById(this.targetFrameId);
			_frame.previousSibling.previousSibling.style.display="block";
			_frame.contentWindow.location.reload();
		}
	},
	
	/*function showIframe(){
		//console.log("showIframe");
		$("#iframe4onetouch").css({left:0}).parent().show();
		glbInfo.isOnetouchMode=true;
	}
	function hideIframe(){
		//console.log("hideIframe");
		$("#iframe4onetouch").unbind("load").removeAttr("src").css({left:800}).parent().hide();
		glbInfo.isOnetouchMode=false;
	}*/
};