﻿/**
 * 개별 페이지의 표시 및 동작용
 * （환경 설정 팝업)
 */
var PreferenceSettingPopup = new TemplatePage();

PreferenceSettingPopup.ID = "pop_preferenceSetting";
PreferenceSettingPopup.key = "PR";

/**
 * 개별 페이지의  Data정의
 */
PreferenceSettingPopup._initModel=function()
{
	this._data = {
		buttonList:[
			{id:"btn_PR_cancel",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PR_cancel",	offImg:Img["BTN_150_34_OFF"],	pressImg:Img["BTN_150_34_PRESS"]}	},
			{id:"btn_PR_confirm",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PR_confirm",	offImg:Img["BTN_150_34_OFF"],	pressImg:Img["BTN_150_34_PRESS"]}	},
			{id:"btn_PR_etc",		type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PR_etc",		offImg:Img["BTN_150_34_OFF"],	pressImg:Img["BTN_150_34_PRESS"]}	}
		],
		imageList:[
			{id:"img_PR_bg",	src:Img["IMG_PR_BG"]}
		],
		textList:[
			{id:"lbl_PR_title",			text:Msg.PreferenceSettingPopup.TITLE},					//환경설정
			{id:"lbl_PR_cancel",		text:Msg.PreferenceSettingPopup.CANCEL_BTN_LABEL},		//취소
			{id:"lbl_PR_confirm",		text:Msg.PreferenceSettingPopup.CONFIRM_BTN_LABEL},		//설정
			{id:"lbl_PR_etc",			text:Msg.PreferenceSettingPopup.ETC_BTN_LABEL},			//기타화면으로 이동
			{id:"lbl_PR_titleBarName",	text:Msg.PreferenceSettingPopup.TITBAR_NAME_LABEL},		//타이틀 바 제목명:
			{id:"lbl_PR_serverURL0",	text:Msg.PreferenceSettingPopup.SERVER_URL_LABEL0},		//Server주소(URL):
			{id:"lbl_PR_serverURL1",	text:Msg.PreferenceSettingPopup.SERVER_URL_LABEL1},		//Server주소(URL):
			{id:"lbl_PR_serverURL2",	text:Msg.PreferenceSettingPopup.SERVER_URL_LABEL2},		//Server주소(URL):
			{id:"lbl_PR_serverURL3",	text:Msg.PreferenceSettingPopup.SERVER_URL_LABEL3},		//Server주소(URL):
			{id:"lbl_PR_serverURL4",	text:Msg.PreferenceSettingPopup.SERVER_URL_LABEL4},		//Server주소(URL):
			{id:"lbl_PR_serverURL5",	text:Msg.PreferenceSettingPopup.SERVER_URL_LABEL5},		//Server주소(URL):
			{id:"lbl_PR_serverType",	text:Msg.PreferenceSettingPopup.MULTI_SERVER_TYPE},		//Multi Server대응 Type설정
			/********************************************** pulldown item *******************************/
			{id:"pul_PR_multiServerType0",		text:Msg.PreferenceSettingPopup.MULTI_SRV_TYPE0},
			{id:"pul_PR_multiServerType1",		text:Msg.PreferenceSettingPopup.MULTI_SRV_TYPE1},
		]
	};
};

/**
 * 개별 페이지 고유의 항목을 구성
 */
PreferenceSettingPopup._initOthers = function()
{
	var tbxTitBarName = document.getElementById("tbx_PR_titleBarName");
	tbxTitBarName.onfocus = function(){this.blur();};

	// Server URL 입력 EventHandler
	var tbxServerURL0 = document.getElementById("tbx_PR_serverURL0");
	tbxServerURL0.onblur=function(){
		var pattern  = /^(http(s)?:(\/\/)+[a-zA-Z0-9:_\\\.&]*)(:[0-9]+)?\//;
		if((!pattern.test(this.value))||(this.value.length < 18)){
			this.value = "Re-enter";
		}
	};
	var tbxServerURL1 = document.getElementById("tbx_PR_serverURL1");
	tbxServerURL1.onblur=function(){
		var pattern  = /^(http(s)?:(\/\/)+[a-zA-Z0-9:_\\\.&]*)(:[0-9]+)?\//;
		if((!pattern.test(this.value))||(this.value.length < 18)){
			this.value = "Re-enter";
		}
	};
	var tbxServerURL2 = document.getElementById("tbx_PR_serverURL2");
	tbxServerURL2.onblur=function(){
		var pattern  = /^(http(s)?:(\/\/)+[a-zA-Z0-9:_\\\.&]*)(:[0-9]+)?\//;
		if((!pattern.test(this.value))||(this.value.length < 18)){
			this.value = "Re-enter";
		}
	};
	var tbxServerURL3 = document.getElementById("tbx_PR_serverURL3");
	tbxServerURL3.onblur=function(){
		var pattern  = /^(http(s)?:(\/\/)+[a-zA-Z0-9:_\\\.&]*)(:[0-9]+)?\//;
		if((!pattern.test(this.value))||(this.value.length < 18)){
			this.value = "Re-enter";
		}
	};
	var tbxServerURL4 = document.getElementById("tbx_PR_serverURL4");
	tbxServerURL4.onblur=function(){
		var pattern  = /^(http(s)?:(\/\/)+[a-zA-Z0-9:_\\\.&]*)(:[0-9]+)?\//;
		if((!pattern.test(this.value))||(this.value.length < 18)){
			this.value = "Re-enter";
		}
	};
	var tbxServerURL5 = document.getElementById("tbx_PR_serverURL5");
	tbxServerURL5.onblur=function(){
		var pattern  = /^(http(s)?:(\/\/)+[a-zA-Z0-9:_\\\.&]*)(:[0-9]+)?\//;
		if((!pattern.test(this.value))||(this.value.length < 18)){
			this.value = "Re-enter";
		}
	};
};

PreferenceSettingPopup._onPageChange = function (e, args){
	this.updateDisplay();
};

PreferenceSettingPopup.onChangeEventHandler = function(e, args){};

/**
 * 화면 표시의 갱신 (공통/화면전환시에 호출된다.)
 */
PreferenceSettingPopup.updateDisplay = function()
{
	KISUtil.debug("function:","updateDisplay");
	var lst = [

	];

	var item;
	for(var i=0, iMax=lst.length; i<iMax; i++){
		item=lst[i];
		document.getElementById(item.id).value=item.value;
	}
	
	if(glbConfig.DATA.TITLE_NAME&&glbConfig.DATA.TITLE_NAME.length>0) Common.setText("tbx_PR_titleBarName",glbConfig.DATA.TITLE_NAME);
	if(glbConfig.DATA.SERVER_URL && glbInfo.SERVER_NUM > 0){//2017.11 KIS [v1.5] SmartUI 복수의 Print Server 대응 refs #4502
		//Common.setText("tbx_PR_serverURL", glbConfig.DATA.SERVER_URL[glbServerIdx]);
		for(var i=0;glbInfo.prefrenceSetting.SERVER_URL.length > i;i++){
			Common.setText("tbx_PR_serverURL" + i, glbInfo.prefrenceSetting.SERVER_URL[i]);
		}
	}
	Common.setIndex("pul_PR_multiServerType", Common.getIndex(glbInfo.prefrenceSetting.MULTI_SERVER_TYPE,glbConfig.DATA.MULTI_SERVER_TYPE));
};

/**
 * 개별 페이지의 Event처리
 * @param {string} event : Event의 종류
 * @param {string} id : Event발생원
 */
PreferenceSettingPopup.EventHandler = function(event, id)
{
	KISUtil.debug("EventHandler","event:"+event+"/id:"+id);
	switch(event){
		case "onbuttonup":
			MessageManager.clearMessageArea();
			BrowserExt.Beep(0);
			switch(id){
				case "btn_PR_cancel":
					//PageManager.changePage(PageManager.getPrevPage(),PageManager.type.CANCEL);
					BrowserExt.SetScreenChange("allservice");
					break;
				case "btn_PR_confirm":
					//widget으로 등록하지 않았으므로
					//컨펌 직전에 데이터를 반영해야함
					var setting = this.getSetting();
					glbConfig.DATA = Extend(glbConfig.DATA, setting);
					//save setting
					var _contents = "var DATA = " + JSON.stringify(setting);
					KISUtil.debug(_contents);
					save_content_to_file(_contents, PREFERENCE_DATA_LOC);
					alert("setConfigData success"); // Delay를 주기위해 alert를 사용함
					eval(_contents);				//2017.10 [v1.5] SmartUI 출력방식 옵션 추가 refs #4497 - 비관련 코드이나 eval 변수가 잘못 지정되어 있으므로(_dataContents) 수정함
					//PageManager.changePage(MenuPage,PageManager.type.CONFIRM);
					BrowserExt.SetScreenChange("allservice");
					break;
				case "btn_PR_etc":
					this.pageSave();
					PageManager.changePage(PreferenceSettingEtcPopup, PageManager.type.NORMAL);
					break;
				default:
					//clearMessageAreaTimer();
					break;
			}
			break;
		case "onhardkeydown":
			MessageManager.clearMessageArea();
			switch(id){
				//case BrowserExt.keyCode.FX_VK_START:
				//case BrowserExt.keyCode.FX_VK_CLEAR:
				case BrowserExt.keyCode.FX_VK_PAUSE:
					break;
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		default:
			break;
	}
};

PreferenceSettingPopup.getSetting = function()
{
	var setting = {};
	
	setting.JOB_LIST_COUNT = glbInfo.prefrenceSetting.JOB_LIST_COUNT.SET;
	setting.TIME_TYPE = glbInfo.prefrenceSetting.TIME_TYPE.SET;
	setting.TIMEOUT = glbInfo.prefrenceSetting.TIMEOUT;
	setting.SKIP = glbInfo.prefrenceSetting.SKIP.SET;
	setting.BUTTON_DEFAULT = glbInfo.prefrenceSetting.BUTTON_DEFAULT.SET;
	setting.COLOR_DISPLAY = glbInfo.prefrenceSetting.COLOR_DISPLAY.SET;
	setting.DELETE = glbInfo.prefrenceSetting.DELETE.SET;
	setting.LIST_AUTO_SELECT = glbInfo.prefrenceSetting.LIST_AUTO_SELECT.SET;
	setting.UPDATE_DELAY_TIME = glbInfo.prefrenceSetting.UPDATE_DELAY_TIME;
	setting.LIST_SORT_ASC = glbInfo.prefrenceSetting.LIST_SORT_ASC.SET;
	setting.NAME_DISPLAY_SELECT = glbInfo.prefrenceSetting.NAME_DISPLAY_SELECT;
	
	setting.TITLE_NAME = document.getElementById("tbx_PR_titleBarName").value;
	setting.SERVER_URL = glbConfig.DATA.SERVER_URL;
	for(var i=0;glbInfo.prefrenceSetting.SERVER_URL.length > i;i++){
		setting.SERVER_URL[i] = document.getElementById("tbx_PR_serverURL" + i).value;
	}
	var obj = document.getElementById("pul_PR_multiServerType");
	setting.MULTI_SERVER_TYPE = parseInt(obj.options[obj.selectedIndex].value);

	return setting;
};

PreferenceSettingPopup.pageSave = function()
{
	glbInfo.prefrenceSetting.TITLE_NAME = document.getElementById("tbx_PR_titleBarName").value;
	for(var i=0;glbInfo.prefrenceSetting.SERVER_URL.length > i;i++){
		glbInfo.prefrenceSetting.SERVER_URL[i] = document.getElementById("tbx_PR_serverURL" + String(i)).value;
	}
	var obj = document.getElementById("pul_PR_multiServerType");
	glbInfo.prefrenceSetting.MULTI_SERVER_TYPE.SET = parseInt(obj.options[obj.selectedIndex].value);
};
/**
 * 풀다운 닫기 처리용 메소드
 * templatePage.js로부터 이동
 */
PreferenceSettingPopup.onPageClick = function()
{
	switch(WidgetLib._popupId)
	{
		case "pul_PR_color_popup":
		case "pul_PR_plex_popup":
		case "pul_PR_nup_popup":
			WidgetLib.closePopupWidget(WidgetLib._popupId);
			MessageManager.clearMessageArea();
			break;
		default:
			break;
	}
};