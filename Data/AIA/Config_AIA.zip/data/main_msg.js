﻿var MAIN_Msg = {
	LOGIN_MSG		: " ",
	LOGIN_MSG2		: " ",
	LOGO_DEFAULT	: false,
	LOGO_URL		: "https://10.134.187.103:28000/image/logo.png",
}

/* ----------- Readme ---------------
	LOGIN_MSG		- 상단 Text Banner 첫째줄에 표시될 문구
	LOGIN_MSG2		- 상단 Text Banner 둘째줄에 표시될 문구
	LOGO_DEFAULT	- Logo 표시 방법
		true  : Installer 내장 Logo 이미지 사용
		false : LOGO_URL의 Logo 이미지 사용
	LOGO_URL 		- 표시할 Logo Image의 URL 주소
*/
