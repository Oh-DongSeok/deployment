var PRINT_DATA_OPTION = "none";
