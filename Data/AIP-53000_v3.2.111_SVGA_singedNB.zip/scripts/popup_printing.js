﻿/**
 * @fileoverview 프린트중 팝업
 * @author FXKIS son.ch
 * @version 1.0.0
 */
/**
 * 개별 페이지의 표시 및 동작용
 * 프린트중 팝업
 */
var PrintingPopup = new TemplatePage();

PrintingPopup.ID = "pop_printing";
PrintingPopup.key = "PP";	//메시지 영역 구분자

/**
 * 개별 페이지의 Data정의
 */
PrintingPopup._initModel=function()
{
	this._data=
	{
		buttonList:[
		],
		imageList:[
			{id:"img_PP_BG", src:Img["IMG_PP_BG"]}
		],
		textList:[
			{id:"lbl_PP_guide", text:Msg.PRINTING.CS_GUI_Printing}
		]
	};
};

/**
 * 화면 표시의 갱신 (공통/화면전환시에 호출된다.)
 */
PrintingPopup.updateDisplay=function(){
};

/**
 * 개별 페이지의 Event처리
 * @param {string} event : Event종류
 * @param {string} id : Event발생원
 */
PrintingPopup.EventHandler = function(event, id)
{
	switch(event){
		case "onbuttonup":
			MessageManager.clearMessageArea();
			switch(id)
			{
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		case "onhardkeydown":
			MessageManager.clearMessageArea();
			switch(id)
			{
				case BrowserExt.keyCode.FX_VK_CLEAR:
					//Reset Key
					BrowserExt.Beep(0);
					//window.location.reload(true);
					// Mantis No: 0000018
					BrowserExt.SetScreenChange("allservice");
					break;
				case BrowserExt.keyCode.FX_VK_PAUSE:
					break;
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		default:
			break;
	}
};