var CONFIG = {
	"Use_UserImage":
	{
		"Background"	: true
	}	
};