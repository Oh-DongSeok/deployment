﻿/**
 * @fileoverview CS기본동작과 공통기능을 정의하는 파일
 * @author FXKIS son.ch
 * @version 1.0.0
 */
var Common = {};
/**
 * Contents기동시의 초기설정을 실행한다.
 */
Common.onLoadBody = function()
{
	ContentsLib.init();
	ContentsLib.contentsIcon = "./info/smallicon.png";
	ContentsLib.setListener(Common.onLoadEvent);
	JFLib.setEventListener(Common.onLoadEvent);

	//2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193
	glbDbm = new DocuBoxManager();
	var dbmCallbacks = {
		onGetDocCntSuccessCallback:function(arg){
			SSMILib.onEvent("GetStoredDocumentCount", true, arg);
		},
		onGetDocCntFailCallback:function(arg){
			SSMILib.onEvent("GetStoredDocumentCount", false, arg);
		},
		onGetDocLstSuccessCallback:function(arg){
			SSMILib.onEvent("GetStoredDocList", true, arg);
		},
		onGetDocLstFailCallback:function(arg){
			SSMILib.onEvent("GetStoredDocList", false, arg);
		},
		onDeleteDocsSuccessCallback:function(arg){
			SSMILib.onEvent("DeleteDocs", true, arg);
		},
		onDeleteDocsFailCallback:function(arg){
			SSMILib.onEvent("DeleteDocs", false, arg);
		}};
	glbDbm.init(OWNER_CHK.IC_CARD_ID, dbmCallbacks);

	glbInfo.cardAuthFlg = false;
	glbInfo.isAuthEvent = true;
	glbInfo.isAdminUser = false;
	glbInfo.isPrintAllOn = false;	//전체문서인쇄플래그

	//BrowserExt.EnablePrivilege();	//타서버에의 접근 권한 부여
	BrowserExt.Initialize();
	BrowserExt.SetScreenChange("onConnectionError:CONTINUE"); //2016.12.22 접속 에러시 디바이스 접속 에러 화면 비표시 처리 refs #4176

	SystemEventLib.AddNotify("AuthEvent", this.onLoadEvent);
	if(DATA.BANNER_URL != ""){
		var bannerURLArray = DATA.BANNER_URL.split("/");
		if(bannerURLArray[3] !== undefined && bannerURLArray[3].indexOf("data") != -1){
			loadScript(DATA.BANNER_URL);
		}
	}
	/*
	BrowserExt.EnablePrivilege();	//타서버에의 접근 권한 부여
	BrowserExt.SetScreenChange("onConnectionError:CONTINUE"); //2016.12.22 접속 에러시 디바이스 접속 에러 화면 비표시 처리 refs #4176
	*/

	//복합기 언어설정에 따른 문자열과 이미지셋 선택
	var lang = BrowserExt.GetAcceptLanguage();
	var arrLang = lang.split(",");
	var _lang = arrLang[0]||"en";
	switch(_lang){
		case "ko":
		case "en":
		case "zh-cn":
			Common.changeMenuLabel(_lang);	// 설정의 변경된 Label로 재설정
			Msg = Msg_lang[_lang];
			break;
		default:
			Common.changeMenuLabel(_lang);	// 설정의 변경된 Label로 재설정
			Msg = Msg_lang["en"];
			break;
	}

	LogLib.setLogLevel(LogLib.LEVEL.WRN);

	// SoftKeypad.initKeypad("body");
	KISUtil.initDebug("body");
	initModel();

	ContentsLib.contentsName = glbConfig.DATA.TITLE_NAME;//Msg.Common.CSName;
	glbInfo.prefrenceSetting.SERVER_URL = glbConfig.DATA.SERVER_URL;

	if(flg_Dummy_Beep){
		//SSMILib.GetTcpIpInfo();
		//SSMILib.GetPrinterCapability();
		SSMILib.GetAccountConfig();
	}
	else{
		//인증모드 취득
		SSMILib.GetAuthStatus(true);
	}
	//SSMILib.ListCsv();
	//대기 페이지로 전환
	PageManager.changePage(WaitingPage, PageManager.type.NORMAL);

	//슬라이드 메시지 초기화
	MessageManager.init();

	//CS타이틀 영역 표시
	Common.displayTitleArea();
};

/**
 * 공통 이벤트 처리 메소드
 * 이곳에 정의 되지 않은 경우 각 페이지에서 이벤트가 처리됨
 * @param {event} event
 * @param {string} id
 */
Common.onLoadEvent = function(event, id)
{
	KISUtil.debug("Common.onLoadEvent","event:"+event+"/id:"+id);
	switch(event){
		// Mantis No: 0000018
		case "LogoutDev":
				KISUtil.debug("CommonEvent","allservice");
				BrowserExt.SetScreenChange("allservice");
			break;
		//기동후의 카드를 통한 인증
		case "AuthEvent":
			if(glbInfo.isAuthEvent){
				glbInfo.cardAuthFlg = true;
				glbInfo.isAuthEvent = false;
				glbInfo.alreadyLoginFlag = false;
				SSMILib.GetAuthStatus(true);
			}
			break;
		//인증정보 취득
		case "GetAuthStatus":
			if(arguments[1] == true){
				var authStatusConfig = arguments[2];
				if(authStatusConfig.User){
					var authUserConfig = authStatusConfig.User;
				}
				if(authStatusConfig.Status == "failure"){
					//if(authStatus == "none"){
						if(glbInfo.cardAuthFlg){	//card id exist
							glbInfo.cardInfo = glbInfo.userInfo.UserID;
							PageManager.changePage(RegistCardPopup, PageManager.type.NORMAL);
						}else{
							var param = {title:Msg.WarnPopup.title, type:"logout", targetPage:true};
							param.message = Msg.errorMessage.WS_FAIL;
							WarnPopup._message = param;
							PageManager.changePage(WarnPopup,PageManager.type.NORMAL);
						}
						return;
					//}
				}else if(authStatusConfig.Status == "continue"){
					//if(authStatus == "none"){
						KISUtil.debug("GetAuthStatus/authStatusConfig.Status",authStatusConfig.Status);
					//}
				}
				SSMILib.GetAccountConfig();
			}else {
				KISUtil.debug("GetAuthStatus/arguments","fail");
			}
			break;
		case "GetAccountConfig":
			/* Get accounting information */
			if (arguments[1] == true) {
				/* If user is authenticated, get info on user currently logged in */
				/* Otherwise, go to "Welcome" page */
				accountConfig = arguments[2];

				if (SSMILib.isDeviceAuth(accountConfig) == true) {
					load_content_to_file("./config/auth.js", function (){
		        		AUTH_STATUS_INDEX = (this.responseText.search("login") > 0)?"login":"logout";
						SSMILib.GetUser();
					});

					//SSMILib.GetUser();

					return;
				} else {
					KISUtil.debug("",  Msg.errorMessage.ERRCODE001);
					var param = {title:Msg.WarnPopup.title, type:"cs_out", targetPage:true};
					param.message = Msg.errorMessage.ERRCODE026;
					WarnPopup._message = param;
					PageManager.changePage(WarnPopup,PageManager.type.NORMAL);
					if(flg_Dummy_Beep){//디버그용 코드
						//SSMILib.GetUser();
						load_content_to_file("./config/auth.js", function (){
			        		AUTH_STATUS_INDEX = (this.responseText.search("login") > 0)?"login":"logout";
							SSMILib.GetUser();
						});
					}
					return;
				}
			} else {
				/* Error if account info retrieval fails */
				ContentsLib.writeLog("GetAccountConfig returns false");
				KISUtil.debug("", Msg.errorMessage.ERRCODE016);
				return;
			}
			break;
		//유저정보취득
		case "GetUser":
			glbInfo.tcpipFailCnt = 0;
			//SSMILib.GetTcpIpInfo();				//Load Speed대응
			//SSMILib.GetPrinterCapability();		//Load Speed대응
			var currentPage = PageManager.getCurrentPage();
			if(arguments[1] == true){
				var users = arguments[2];

				if(users && users[0]){
					glbInfo.userInfo = users[0];
					// glbInfo.userInfo = {CardID: "",DisplayName: "",Index: "-1",RelatedUserID: "11111",UserID: "11111",userId: "11111"};//TODO: delete test code
					if(flg_Dummy_Beep){ // 테스트용
						glbInfo.userInfo.RelatedUserID = "ohdongseok";		//TODO:delete dummy
					}
					// glbInfo.userInfo.RelatedUserID = Msg.Common.UnknownUserName;		// 카드 등록 테스트용
					// glbInfo.cardAuthFlg = true;										// 카드 등록 테스트용

					//__noUser(미인증카드)대응
					if (glbInfo.userInfo.RelatedUserID == Msg.Common.UnknownUserName) {
						//if(true){
						//if(glbInfo.cardAuthFlg){	//card id exist
						if(glbInfo.userInfo.UserID){	//card id exist
							glbInfo.cardInfo = glbInfo.userInfo.UserID;
							PageManager.changePage(RegistCardPopup, PageManager.type.NORMAL);
						}
						else{
							var param = {title:Msg.WarnPopup.title, type:"logout", targetPage:true};
							param.message = Msg.errorMessage.WS_FAIL;
							WarnPopup._message = param;
							PageManager.changePage(WarnPopup,PageManager.type.NORMAL);
						}
						break;
					}
					SSMILib.GetTcpIpInfo();				//Load Speed대응
					SSMILib.GetPrinterCapability();		//Load Speed대응
					if(gDummyFlag){
						MenuPage.getUsagePrnCnt();//Private Print 문서수 취득 후 서버 문서수 취득함
					}

					//유저명 표시
					glbInfo.userName = Common.getUserName();

					glbInfo.loginIdx = (AUTH_STATUS_INDEX !== "logout")?2:1;	//패널인증성공 케이스 보정
					if(glbInfo.cardAuthFlg){
						glbInfo.loginIdx = 1;
					}

					var _dataContent = "var AUTH_STATUS_INDEX = \"login\";";
					eval(_dataContent);
					save_content_to_file(_dataContent, AUTH_DATA_OPTION_LOC);
					KISUtil.debug("EventHandler/GetUser/_dataContent", _dataContent);
				}else{
					glbInfo.loginIdx = 0;
				}
			}else{
				// 테스트용
				if(flg_Dummy_Beep){ // 테스트용
					glbInfo.cardInfo = "test";
					PageManager.changePage(RegistCardPopup, PageManager.type.NORMAL);
				}
				//인증상태  보존
				glbInfo.loginIdx = 0;
				var _dataContent = "var AUTH_STATUS_INDEX = \"logout\";";
				eval(_dataContent);
				save_content_to_file(_dataContent, AUTH_DATA_OPTION_LOC);
				KISUtil.debug("EventHandler/GetUser/_dataContent", _dataContent);

				//인증실패대응
				if(glbInfo.cardAuthFlg){	//card id exist
					if(glbInfo.userInfo !=null && glbInfo.userInfo.UserID != null){		//2013/04/09 방어코드 추가
						glbInfo.cardInfo = glbInfo.userInfo.UserID;
						PageManager.changePage(RegistCardPopup, PageManager.type.NORMAL);
					}else{
						//2016.11.03 KIS Chone CardID가 null일 때 GetUser 리트라이 3회 실시 대응 Start
						//미인증 상태에서 카드 인증 AuthEvent 이벤트 발생 후 GetAuthStatus->GetAccountConfig->GetUser를 실시하는데
						//GetUser 호출시에 GetUser 정보가 취득되지 않는 경우가 발생하므로, 이러한 경우 3번 GetUser 리트라이를 실시함.
						glbGetUserCount++;
						if(glbGetUserCount != MAX_GETUSER_COUNT){
							LogLib.error("[CS]---CardAuth but GetUser false, retry count : " + glbGetUserCount);
							SSMILib.GetUser();
							return;
						}//2016.11.03 KIS Chone CardID가 null일 때 GetUser 리트라이 3회 실시 대응 End

						LogLib.error("[CS]---CardAuth but GetUser false, retry count : " + glbGetUserCount + ", ERRCODE007 popup");//2016.11.03 KIS Chone 로그 추가
						var param = {title:Msg.WarnPopup.title, type:"logout", targetPage:true};
						param.message = Msg.errorMessage.ERRCODE007;
						WarnPopup._message = param;
						PageManager.changePage(WarnPopup,PageManager.type.NORMAL);
					}
				}else{
					var param = {title:Msg.WarnPopup.title, type:"logout", targetPage:true};
					param.message = Msg.errorMessage.WS_FAIL;
					WarnPopup._message = param;
					PageManager.changePage(WarnPopup,PageManager.type.NORMAL);
				}
			}
			if(currentPage){
				if(currentPage == WaitingPage){
					PageManager.changePage(MenuPage, PageManager.type.NORMAL);
					currentPage = PageManager.getCurrentPage();
					currentPage.updateDefaultBtnStatus();
				}
				currentPage.EventHandler(arguments[0], arguments[1], arguments[2]);
			}
			break;
		case "GetTcpIpInfo":
			if(arguments[1] == true){
				var tcpIpInfo = arguments[2];
				glbInfo.ipAddress = tcpIpInfo.IPAddress;
				glbInfo.tcpipFailCnt = 0;

				//만약 즉시실행 플래그가 설정된경우
				if(glbInfo.isPrintAllOn){
					Common.doJobStart();		 //즉시인쇄를 실행
					glbInfo.isPrintAllOn = false;//플래그를 제거
				}
			}else{
				KISUtil.debug("GetTcpIpInfo Error/cnt",glbInfo.tcpipFailCnt);
				if(glbInfo.tcpipFailCnt < 500) {
					glbInfo.tcpipFailCnt++;
					setTimeout(SSMILib.GetTcpIpInfo, 200);
				}
				else{
					glbInfo.tcpipFailCnt = 0;
					var param = {title:Msg.WarnPopup.title, type:"logout", targetPage:true};
					param.message = Msg.errorMessage.WS_FAIL;
					WarnPopup._message = param;
					PageManager.changePage(WarnPopup,PageManager.type.NORMAL);
				}
			}
			break;
		case "GetPrinterCapability":
			if(arguments[1] == true){
				var capability = arguments[2];
				glbInfo.deviceColor = (capability.ColorMode=="color")?"C":(capability.ColorMode=="monochrome")?"B":"";
			}else{
				//KISUtil.debug("GetPrinterCapability Error", JSON.stringify(arguments));
				KISUtil.debug("GetPrinterCapability Error", "false");
			}
			break;
		case "ListCsv":
        	if(flg_Dummy_Beep||arguments[1]==true){
				glbInfo.SpecifyIndex = convertCsInfos(arguments[2]);
			}
			else{
				glbInfo.SpecifyIndex = 0;
				WarnPopup._message = {title:Msg.WarnPopup.title, type:"logout", targetPage:true, message:Msg.errorMessage.ERRCODE000};
				PageManager.changePage(WarnPopup,PageManager.type.NORMAL);
			}
			function convertCsInfos(obj){
				var result = 0;
				for(i in obj){
					tmp = obj[i];
					if(tmp.Name == "CS_RM_00157"){		// SmartUI Install Name
					//if(tmp.Name == "CS_RM_00139"){		// SmartUI Install Name
						result = tmp.Index;
					}
				}
				return result;
			}
			break;
		case "GetStoredDocumentCount"://2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193
			//참고 - Private Print 미설정 상태에서도 GetStoredDocumentCount 통신 성공
			glbInfo.usagePrnCnt.prnCountPrivate = 0;
			KISUtil.debug("GetStoredDocumentCount", arguments[1]);
			if(arguments[1] == true){
				var param = {title:Msg.WarnPopup.title, type:"logout", targetPage:true};
				var _result = arguments[2];
				if(_result.length > 0){
					if(!glbInfo.usagePrnCnt) glbInfo.usagePrnCnt = {};
					glbInfo.usagePrnCnt.prnCount = parseInt(_result[0]);
					glbInfo.usagePrnCnt.prnCountPrivate = parseInt(_result[0]);
					MenuPage.getUsagePrnCnt();//Private Print 문서수 취득 후 서버 문서수 취득함
				}else{
					glbDbmEnable = false;
					MenuPage.getUsagePrnCnt();
					LogLib.info("[CS] common.js GetStoredDocumentCount result length 0 ERROR");
				}
			}else{
				glbDbmEnable = false;
				MenuPage.getUsagePrnCnt();
				LogLib.info("[CS] common.js GetStoredDocumentCount result false ERROR");
			}
			break;
		case "GetStoredDocList"://2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193
			glbInfo.usedPrivatePrintCount = 0;
			if(arguments[1] == true){
				var lst = arguments[2];
				var i, len = lst.length, _tmp, _doc;
				glbInfo.docList = [];
				for(i=0;i<len;i++){
					_tmp = lst[i];
					_doc = {};
					_doc.printInvalidType = PRINTABLE_VALID_TYPE.none;
					_doc.UUID = parseInt(_tmp.Identifier);
					_doc.docName = _tmp.Name;
					_doc.pageCnt = parseInt(_tmp.NumberOfPages);
					_doc.printCnt = parseInt(_tmp.Copies);
					_doc.prnType = false;
					_doc.useYn = (_tmp.Printed == "true");
					if(_doc.useYn == true){
						glbInfo.usedPrivatePrintCount++;
					}
					_doc.colorIdx = _doc.originColorIdx = (_tmp.ColorMode=="monochrome")?1:0;
					_doc.srcNupIdx = _doc.originNupIdx = _doc.nupIdx = glbInfo.getIndexByKey("nup", parseInt(_tmp.Nup), 0);			//0은 default값
					_doc.deleteIdx = glbInfo.getIndexByKey("delete", glbConfig.DATA.DELETE, 0);				//0은 default값
					_doc.plexIdx = Common.indexOf(["simplex","duplex","tumble"],_tmp.OutPlex);
					_doc.printDate = parseDate(_tmp.StoreTime).toString();
					_doc.boxId = _tmp.boxId;
					_doc.plexUnlock = (_tmp.OutPlexOverWritePermission == "true");
					_doc.colorModeUnlock = (_tmp.ColorModeOverWritePermission == "true");
					_doc.copiesUnlock = (_tmp.CopiesOverWritePermission == "true");
					glbInfo.docList[i] = _doc;
				}

				if(glbInfo.isJobExcuted){//즉시 출력의 경우 private_print 문서 취득 후에 프린트 잡 실행
					if(glbInfo.docList.length > 0){
						Common.doJobPrivatePrintDocument(glbInfo.docList);
					}
					if(glbInfo.usagePrnCnt.prnCountServer > 0){
						Common.doImmediateJobServerDocument();
					}
					return;
				}

				var currentPage = PageManager.getCurrentPage();
				if(currentPage){
					currentPage.EventHandler(arguments[0], arguments[1], arguments[2]);
				}
			}else{
				glbDbmEnable = false;
				LogLib.info("[CS] common.js GetStoredDocList result false ERROR");

				if(glbInfo.isJobExcuted){//즉시 출력시 private_print 잡 취득 실패시 서버 문서 즉시 출력 처리
					Common.doImmediateJobServerDocument();
					return;
				}
			}
			break;
		case "ExecuteJFS"://2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193
			glbProgress.private_print = false;
 			if(!arguments[1]){
 				LogLib.info("[CS] ExecuteJFS result false ERROR");
            }

 			if(!glbProgress.private_print && !glbProgress.server_print){ //Private Print 문서 출력 지시와 서버 문서 출력 지시가 끝나면 화면 천이
				var _prevPage = PageManager.getPrevPage();
				if(_prevPage){
					PageManager.changePage(_prevPage, PageManager.type.CANCEL);
				}else{
					LogLib.info("[CS] Common.onLoadEvent/ExecuteJFS prevPage ERROR");
					PageManager.changePage(MenuPage, PageManager.type.CANCEL);
				}
			}
            break;
		case "DeleteDocs"://2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193
			glbProgress.private_print = false;
			if(!arguments[1]){
 				LogLib.info("[CS] DeleteDocs result false ERROR");
            }

			if(!glbProgress.private_print && !glbProgress.server_print){//Private Print 문서 삭제 지시와 서버 문서 삭제 지시가 끝나면 화면 천이
				var currentPage = PageManager.getCurrentPage();
				if(currentPage){
					currentPage.EventHandler("DeleteSelected", arguments[1], arguments[2]);
				}
			}
			break;
		case "GetUsagePrnCnt"://SmartUI 2017.02 복수의 Print Server 대응 refs #4184
			if(glbInfo.serverCallCount == 0){//glbInfo.usagePrnCnt.prnCountServer값이 누적되지 않도록 통신시마다 리셋함
				glbInfo.usagePrnCnt.prnCountServer = 0;//서버로부터 취득한 문서수, 즉시출력시 이 값이 0 이상일 경우 즉시출력 실시
			}
			glbInfo.serverCallCount++;
			if(arguments[1] == true){
				var _result = arguments[2];
				if(_result.status == "success"){
					if(_result.result){
						var _userInfo = _result.result;
						if(!glbInfo.usagePrnCnt) glbInfo.usagePrnCnt = {};

						if(glbInfo.usagePrnCnt.limitColor == ""){//첫번째 응답의 정보를 저장
							glbInfo.usagePrnCnt.limitColor = parseInt(_userInfo.limitColor);
							glbInfo.usagePrnCnt.limitGray = parseInt(_userInfo.limitGray);
							glbInfo.usagePrnCnt.prnCountServer = parseInt(_userInfo.prnCount);

							glbInfo.usagePrnCnt.usedColor = parseInt(_userInfo.usedColor);
							glbInfo.usagePrnCnt.usedGray = parseInt(_userInfo.usedGray);
							glbInfo.usagePrnCnt.functionCtrl = parseInt(_userInfo.functionCtrl);
							glbInfo.usagePrnCnt.overCountPrint = (_userInfo.overCountPrint == "Y");	//사양추가분 2013/02/22
							glbInfo.userInfo.userId = _userInfo.userId;

							glbInfo.usagePrnCnt.remain = [];
							glbInfo.usagePrnCnt.remain[0] = glbInfo.usagePrnCnt.limitColor - glbInfo.usagePrnCnt.usedColor;
							glbInfo.usagePrnCnt.remain[1] = glbInfo.usagePrnCnt.limitGray - glbInfo.usagePrnCnt.usedGray;
							if(glbInfo.usagePrnCnt.remain[0]<0) glbInfo.usagePrnCnt.remain[0] = 0;
							if(glbInfo.usagePrnCnt.remain[1]<0) glbInfo.usagePrnCnt.remain[1] = 0;
							// Watermark On/Off 정책 수신
							if(_userInfo.watermarkPolicy){
								glbInfo.userInfo.watermarkPolicy = _userInfo.watermarkPolicy;
							}else{
								glbInfo.userInfo.watermarkPolicy = "N"; // I/F에 없는 경우에는 해당 기능을 사용하지 않는다.
							}
							// Password 만료 통지 정책 수신
							if(_userInfo.noticePasswordExp){
								glbInfo.userInfo.dayPasswordExp = parseInt(_userInfo.dayPasswordExp);
								glbInfo.userInfo.noticePasswordExp = _userInfo.noticePasswordExp;
								glbInfo.userInfo.availLoginExp = _userInfo.availLoginExp;
							}else{
								// I/F에 없는 경우에는 해당 기능을 사용하지 않는다.
								glbInfo.userInfo.dayPasswordExp = 0;
								glbInfo.userInfo.noticePasswordExp = "N";
								glbInfo.userInfo.availLoginExp = "N";
							}
							if(_userInfo.passwordPolicy){
								glbInfo.userInfo.passwordPolicy =  _userInfo.passwordPolicy;
								//if(glbInfo.userInfo.passwordPolicy.minPasswordCnt > glbInfo.userInfo.passwordPolicy.maxPasswordCnt){
								var min = parseInt(_userInfo.passwordPolicy.minPasswordCnt);	// string type을 int type으로 변경이 필요함
								var max = parseInt(_userInfo.passwordPolicy.maxPasswordCnt);
								if(max < min){
									glbInfo.userInfo.passwordPolicy.maxPasswordCnt = glbInfo.userInfo.passwordPolicy.minPasswordCnt;
								}
							}
							///*
							if(flg_Dummy_Beep){ // I/F 없을 경우 테스트용
								glbInfo.userInfo.watermarkPolicy = "Y";
								glbInfo.userInfo.dayPasswordExp = 55;
								glbInfo.userInfo.noticePasswordExp = "N";
								glbInfo.userInfo.availLoginExp = "N";

								var _temp = {
									"neededCapitalCharCnt":"1",
									"neededDigitCnt":"1",
									"neededSpecialCharCnt":"1",
									"minPasswordCnt":"4",
									"maxPasswordCnt":"21"
								}
								glbInfo.userInfo.passwordPolicy = _temp;
							}
							//*/
						}else{
							glbInfo.usagePrnCnt.prnCountServer = parseInt(_userInfo.prnCount);
						}

						if(glbConfig.DATA.MULTI_SERVER_TYPE == 0){
							KISUtil.debug("prnCount:",_userInfo.prnCount);
							KISUtil.debug("glbInfo.usagePrnCnt.prnCount:",glbInfo.usagePrnCnt.prnCount);
							glbInfo.usagePrnCnt.prnCount += parseInt(_userInfo.prnCount); // 다중 DB인 경우에는 prnCount를 합산한다.
							KISUtil.debug("glbInfo.usagePrnCnt.prnCount:",glbInfo.usagePrnCnt.prnCount);
						}
						if(glbDbmEnable || glbInfo.SERVER_NUM > 1){//2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193
							if(glbConfig.DATA.MULTI_SERVER_TYPE == 1){
								glbInfo.usagePrnCnt.prnCount = parseInt(_userInfo.prnCount) + glbInfo.usagePrnCnt.prnCountPrivate;
							}
						}else{
							if(glbConfig.DATA.MULTI_SERVER_TYPE == 1){
								glbInfo.usagePrnCnt.prnCount = parseInt(_userInfo.prnCount);
							}
						}
					}
				}else{
					glbInfo.serverErrCount++;
					LogLib.info("[CS] GetUsagePrnCnt Error : " + _result.status);
				}
			}else{
				glbInfo.serverErrCount++;
				LogLib.info("[CS] Common.onLoadEvent/GetUsagePrnCnt Fail");
			}

			if((glbInfo.serverCallCount == glbInfo.SERVER_NUM)){
				if((glbInfo.serverCallCount == glbInfo.serverErrCount)&&(glbInfo.usagePrnCnt.prnCountPrivate <= 0)&&(glbInfo.usagePrnCnt.prnCount <= 0)){
					//WarnPopup._message = {title:Msg.WarnPopup.title, type:"logout", targetPage:true, message:Msg.errorMessage.ERRCODE000};
					WarnPopup._message = {title:Msg.WarnPopup.title, type:"logout", targetPage:true, message:Msg.errorMessage.ERRCODE011};
					PageManager.changePage(WarnPopup,PageManager.type.NORMAL);
				}else{
					var currentPage = PageManager.getCurrentPage();
					if(currentPage){
						currentPage.EventHandler("GetUsagePrnCnt", "");
					}
					if((glbInfo.userInfo.noticePasswordExp == "Y")&&(!glbInfo.passwordExpChk)){
						PageManager.changePage(PasswordExpPopup, PageManager.type.NORMAL);
					}
				}
				glbInfo.serverCallCount = 0;
				glbInfo.serverErrCount = 0;
			}else{
				// Count가 업데이트 되도록 한다.
				var currentPage = PageManager.getCurrentPage();
				if(currentPage){
					currentPage.EventHandler("GetUsagePrnCnt", "");
				}
			}
			break;
		case "PrintSelected":
			glbInfo.serverCallCount++;
			if(arguments[1] == true){
				var _result = arguments[2];
				if(_result.status != "success"){
					if(_result.status != "noResult"){
						glbInfo.serverErrCount++;
						LogLib.info("[CS] PrintSelected Error : " + _result.status);
					}else{
						glbInfo.noResultCount++;
						LogLib.info("[CS] PrintAll Error ERRCODE025");
					}
				}
			}else{
				glbInfo.serverErrCount++;
				LogLib.info("[CS] PrintSelected Error ERRCODE012");
			}

			if(glbInfo.serverCallCount == glbInfo.DOC_PROC_COUNT){
				if(glbInfo.serverCallCount == glbInfo.serverErrCount){
					WarnPopup._message = {title : Msg.WarnPopup.title, type : "logout", targetPage : true, message : Msg.errorMessage.ERRCODE000};
					PageManager.changePage(WarnPopup, PageManager.type.NORMAL);
				}else{
					glbProgress.server_print = false;
					if(!glbProgress.private_print && !glbProgress.server_print){ //2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193 - Private Print 문서 출력 지시와 서버 문서 출력 지시가 끝나면 화면 천이
						setTimeout(function(){PageManager.changePage(FileListPage, PageManager.type.CANCEL)}, 5000);
					}
				}
				if(glbInfo.serverCallCount == glbInfo.noResultCount){
					WarnPopup._message = {title : Msg.WarnPopup.title, type : "logout", targetPage : true, message : Msg.errorMessage.ERRCODE025};
					PageManager.changePage(WarnPopup, PageManager.type.NORMAL);
				}
				glbInfo.serverCallCount = 0;
				glbInfo.serverErrCount = 0;
				glbInfo.noResultCount = 0;
			}
			break;
		case "PrintAll":
			glbInfo.serverCallCount++;
			if(arguments[1] == true){
				var _result = arguments[2];
				if(_result.status != "success"){
					if(_result.status != "noResult"){
						glbInfo.serverErrCount++;
						LogLib.info("[CS] PrintAll Error : " + _result.status);

						if(_result.status == "fail"){
							if(typeof _result.result === String || typeof _result.result === "string"){
								var params = _result.result.split("|");
								LogLib.info("[CS] PrintAll fail detail : " + params[0].toLowerCase());
							}
						}
					}else{
						glbInfo.noResultCount++;
						LogLib.info("[CS] PrintAll Error ERRCODE025");
					}
				}
			}else{
				glbInfo.serverErrCount++;
				LogLib.info("[CS] PrintAll Error ERRCODE012");
			}

			if(glbInfo.serverCallCount == glbInfo.SERVER_NUM){
				if(glbInfo.serverCallCount == glbInfo.serverErrCount){
					WarnPopup._message = {title : Msg.WarnPopup.title, type : "logout", targetPage : true, message : Msg.errorMessage.ERRCODE000};
					PageManager.changePage(WarnPopup, PageManager.type.NORMAL);
				}else{
					glbProgress.server_print = false;
					if(!glbProgress.private_print && !glbProgress.server_print){ //2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193 - Private Print 문서 출력 지시와 서버 문서 출력 지시가 끝나면 화면 천이
						var _prevPage = PageManager.getPrevPage();
						if(_prevPage){
							setTimeout(function(){PageManager.changePage(_prevPage, PageManager.type.CANCEL)}, 5000);
						}else{
							LogLib.info("[CS] Common.onLoadEvent/PrintAll prevPage ERROR");
							PageManager.changePage(MenuPage, PageManager.type.CANCEL);
						}
					}
				}
				if(glbInfo.serverCallCount == glbInfo.noResultCount){
					WarnPopup._message = {title : Msg.WarnPopup.title, type : "logout", targetPage : true, message : Msg.errorMessage.ERRCODE025};
					PageManager.changePage(WarnPopup, PageManager.type.NORMAL);
				}
				glbInfo.serverCallCount = 0;
				glbInfo.serverErrCount = 0;
				glbInfo.noResultCount = 0;
			}
			break;
		case "DeleteSelected":
			glbInfo.serverCallCount++;
			if(arguments[1] == true){
				var _result = arguments[2];
				if(_result.status != "success"){
					glbInfo.serverErrCount++;
					LogLib.info("[CS] DeleteSelected Error : " + _result.status);
				}
			}else{
				glbInfo.serverErrCount++;
				LogLib.info("[CS] DeleteSelected Error ERRCODE012");
			}

			if(glbInfo.serverCallCount == glbInfo.DOC_PROC_COUNT){
				if(glbInfo.serverCallCount == glbInfo.serverErrCount){
					WarnPopup._message = {title : Msg.WarnPopup.title, type : "logout", targetPage : true, message : Msg.errorMessage.ERRCODE000};
					PageManager.changePage(WarnPopup, PageManager.type.NORMAL);
				}else{
					glbProgress.server_print = false;
					if(!glbProgress.private_print && !glbProgress.server_print){//2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193 - Private Print 문서 삭제 지시와 서버 문서 삭제 지시가 끝나면 화면 천이
						var currentPage = PageManager.getCurrentPage();
						if(currentPage){
							currentPage.EventHandler(arguments[0],arguments[1],arguments[2]);
						}
					}
				}
				glbInfo.serverCallCount = 0;
				glbInfo.serverErrCount = 0;
			}
			break;
		default:
			var currentPage = PageManager.getCurrentPage();
			if(currentPage)
			{
				currentPage.EventHandler(arguments[0], arguments[1], arguments[2]);
			}
			break;
	}
};

/**
 * Title의 Text와 Icon을 설정
 */
Common.displayTitleArea = function()
{

};

/**
 * 화면에 표시할 유저명을 취득<br>
 * 우선순위<br>
 * 1.정보취득중과 화면표시중에 취득된 유저명<br>
 * 2.1이 아닌 경우, 유저의 RelatedUserID<br>
 * 3.1,2이 아닌 경우, 「일반유저」<br>
 * @return {string} name 화면에 표시할 유저명
 */
Common.getUserName = function()
{
	var name = "";
	switch (glbConfig.DATA.NAME_DISPLAY_SELECT) {
		case DISPLAY_USER_INFO.DISPLAYNAME:
			if(glbInfo.userInfo.DisplayName){
				name = glbInfo.userInfo.DisplayName;
			}
			else{
				name = "Unknown";
			}
			break;
		case DISPLAY_USER_INFO.USERID:
			if(glbInfo.userInfo.UserID){
				name = glbInfo.userInfo.UserID;
			}
			else{
				name = "Unknown";
			}
			break;
		case DISPLAY_USER_INFO.RELATEDID:
			if(glbInfo.userInfo.RelatedUserID){
				name = glbInfo.userInfo.RelatedUserID;
			}
			else{
				name = "Unknown";
			}
			break;
		case DISPLAY_USER_INFO.AUTO:
		default:
			if(glbInfo.userInfo){
				if(glbInfo.userInfo.DisplayName){
					name = glbInfo.userInfo.DisplayName;
				}
				else if(glbInfo.userInfo.UserID){
					name = glbInfo.userInfo.UserID;
				}
				else if(glbInfo.userInfo.RelatedUserID){
					name = glbInfo.userInfo.RelatedUserID;
				}
				else{
					name = "Unknown";
				}
			}
			break;
	}
	return name;
};

/**
 * 화면에 표시할 유저명의 길이 설정<br>
 * 유저명의 길이가 길경우 표시 폭에 마추어 잘라내기 한다.
 * @return {string} name 화면에 표시할 유저명
 */
Common.getUserDisplayName = function(name)
{
	if(name){
		/*
		var byteNum = this.getStringByteNumber(name);
		if(byteNum > 32){
			name = cutStringBytes(name, 32);
		}
		*/
		var byteNum = this.getStringSize(name);
		if(byteNum > glbInfo.userNameLength)
		{
			name = this.cutStringWidth(name, glbInfo.userNameLength);
		}
	}
	return name;
};

/**
 *풀다운의 HTML을 작성
 * @param {string) _page : 적용될 페이지의 Key
 * @param {string} _key : 풀다운의 Key (각 Element의 ID를 작성해 사용한다.)
 * @param {int} _length : 항목 (항목을 나누어 HTML을 작성)
 * @return Full down HTML Element
 */
Common.createHTMLPulldown = function(_page,_key,_length){
	var _popup = Common.getNewElement("div",{id:"pul_" + _page + "_" + _key + "_popup", className:"pullPop hide"}),
		_bgTop = Common.getNewElement("img",{id:"img_" + _page + "_" + _key + "_popup_top", className:"bgTop"}),
		_bgBottom = Common.getNewElement("img",{id:"img_" + _page + "_" + _key + "_popup_bottom", className:"bgBottom"}),
		_body = Common.getNewElement("div",{id:"lst_" + _page + "_" + _key + "_popup", className:"bg"}),
		_list = document.createElement("ul"),
		_btn, _item, _node, _tmp;
	for(var i = 0; i < _length; i++)
	{
		_item =  Common.getNewElement("li",{id:"item" + i});
		_btn = Common.getNewElement("div",{id:"btn_" + _page + "_" + _key + "_menu_" + i, className:"popBtn"});
		_btn.appendChild(Common.getNewElement("img",{id:"img_" + _page + "_" + _key + "_menu_" + i, className:"bg"}));		//bg
		_btn.appendChild(Common.getNewElement("img",{id:"icn_" + _page + "_" + _key + "_menu_" + i, className:"icn"}));	//icon
		_btn.appendChild(Common.getNewElement("div",{id:"lbl_" + _page + "_" + _key + "_menu_" + i, className:"lbl"}));	//label
		_item.appendChild(_btn);
		_list.appendChild(_item);
	}
	_body.appendChild(_list);

	_popup.appendChild(_bgTop);
	_popup.appendChild(_bgBottom);
	_popup.appendChild(_body);

	return _popup;
};

/**
 * List를 입수시 Widget의 Status를 변경
 * @param {Array} list Widget Object Array
 * @param {boolean} flag Enable/Disable
 */
Common.changeStatus = function(list,flag)
{
	for(var i=0,il=list.length;i<il;i++)
	{
		WidgetLib.setWidgetStatus(list[i], {enable:flag});
	}
};

//SmartUI 2017.02 복수의 Print Server 대응 refs #4184
Common.getWsIp = function()
{
	var arr = [];

	for(var i=0; i<glbConfig.DATA.SERVER_URL.length; i++){
		if(glbConfig.DATA.SERVER_URL[i] != "Re-enter"){
			LogLib.info("Common.getWsIp/SERVER_URL[" + i + "] : " + glbConfig.DATA.SERVER_URL[i]);

			var regex = /^http:\/\/([A-Za-z0-9-]+\.)+[A-Za-z0-9-]{2,4}/;
			var result = regex.exec(glbConfig.DATA.SERVER_URL[i]);

			if(result == null){//2016.06.10 chone - data.js의 SERVER_URL이 https 일 경우 result가 null이 발생, 이 경우 https로 다시 한번 정규식 체크 실시
				regex = /^https:\/\/([A-Za-z0-9-]+\.)+[A-Za-z0-9-]{2,4}/;
				result = regex.exec(glbConfig.DATA.SERVER_URL[i]);
			}

			if(result != null){
				result = result[0].replace(/(http|https):\/\//, "");
			}else{
				var tmp = glbConfig.DATA.SERVER_URL[i].replace(/(http|https):\/\//, "");
				var idx = tmp.indexOf(":");
				if(idx < 0){
					idx = tmp.indexOf("/");
				}
				result = tmp.substr(0, idx);
			}
			LogLib.info("[CS] WebService IP : " + result);
			arr.push(result);
		}else{
			LogLib.info("Common.getWsIp/SERVER_URL[" + i + "] : " + glbConfig.DATA.SERVER_URL[i]);
		}
	}

	return arr;
};

/**************************************************************** 共通 ****************************************************************/
/**
 * 화면 Object의 문자열 표시 처리
 * @param {string} id :Object의 ID
 * @param {string} string :표시할 문자열
 */
Common.setText = function(id, str)
{
	var textNode
	if(typeof id === String||typeof id === "string"){
		textNode = document.getElementById(id);
		if(!textNode || str == undefined){
			alert("id=" + id + " : string=" + str);
			return;
		}
	}
	else if(typeof id === Object){
		textNode = id;
	}
	else{
		return;
	}
	switch(textNode.nodeName.toLowerCase())
	{
		case "div":
		case "textarea":
		case "option":
		case "span":
		case "p":
			while(textNode.firstChild){
				textNode.removeChild(textNode.firstChild);
			}
			if(str instanceof Array)
			{
				var tmp;
				for(var i = 0, il = str.length; i < il; i++)
				{
					tmp=document.createElement("p");
					tmp.innerHTML=str[i];
					textNode.appendChild(tmp);
				}
			}
			else
			{
				textNode.appendChild(document.createTextNode(str));
			}
			break;
		case "input":
			//textNode.setAttribute("value",str);
			textNode["value"] = str;				//textbox의 값 갱신 오류 대응
			break;
		default:
			break;
	}
};

/**
 * 화면 Object의 Image표시 처리
 * @param {string} id : Object ID
 * @param {string} src : Image의 Hendle
 */
Common.setImage = function (id, src)
{
	var imgNode = document.getElementById(id);
	if(!imgNode || !src || imgNode.src == src){
		alert("id=" + id + " : src=" + src);
		return;
	}
	imgNode.setAttribute("src", src);
};

/**
 * Text를 취득 한다.
 * @param {string} id : Text를 취득하는 Object ID
 * @return {string} : 지정된 ID의 Text
 */
Common.getText = function (id)
{
	var obj = document.getElementById(id);
	if(!obj || !id){
		return;
	}
	return obj.firstChild.nodeValue;
};

/**
 * 화면 Object의 Text Color변경 처리<br>
 * Off의 경우, #000000지정
 * disable의 경우, #ADAAAD지정
 * @param {string} id : Object의 ID
 * @param {string} color : Text의 Color
 */
Common.setTextColor = function(id, color)
{
	if(!id || !color){
		return;
	}
	var obj = document.getElementById(id);
	if(obj){
		obj.style.color = color;
	}
};

/**
 * Object의 표시/비표시를 처리
 * @param {string} id : 표시를 변경하는 Object ID
 * @param {string} attr : display를 지정하는 문자열(none, block)
 */
Common.changeVisibility = function(id, attr)
{
	var obj = document.getElementById(id);
	if(!id || !attr || !obj){
		return;
	}
	if(obj.style.display != attr) {
		obj.style.display = attr;
	}
};

/**
 * HTML Element를 작성
 * @param {string} tag : Tag명
 * @param {object} attrs: Teg에 할당된 속성
 * @return 작성된 Tag의 Element
 */
Common.getNewElement = function(tag,attrs)
{
	var result = null;
	if(tag)
	{
		result=document.createElement(tag);

		if(attrs.id){	result.setAttribute("id",attrs.id);	}
		if(attrs.className){	result.setAttribute("class",attrs.className);	}
	}
	return result;
};

/**
 * Event를 할당한다.（사용되지 않고 있다)
 * @param {string} id : Tag ID
 * @param {string} eventName : Event의 종류
 * @param {event} event : 할당된 Event
 */
Common.setEvent=function(id,eventName,event)
{
	var obj=document.getElementById(id);
	if(obj&&eventName&&event){
		if(obj.attachEvent)obj.attachEvent(eventName,event);
		else if(obj.addEventListener)obj.addEventListener(eventName,event,false);
	}
};

/**
 * 문자열의 Bytes수를 계산한다.
 * @param {string} str : 문자열
 * @return {int} cnt : 문자열의 Byte수(반각 기준)
 */
//Common.getStringByteNumber=function(str)
Common.getStringSize = function(str)
{
	var cnt = 0;
	var c;
	for(var i=0; i<str.length; i++){
		c = str.charCodeAt(i);
		//Shift_JIS: 0x0 ～ 0x80, 0xa0 , 0xa1 ～ 0xdf , 0xfd ～ 0xff
		//Unicode : 0x0 ～ 0x80, 0xf8f0, 0xff61 ～ 0xff9f, 0xf8f1 ～ 0xf8f3
		if((c >= 0x0 && c < 0x81) || (c == 0xf8f0) || (c >= 0xff61 && c < 0xffa0) || (c >= 0xf8f1 && c < 0xf8f4)){
			cnt++;
		}else{
			cnt += 2;
		}
	}
	return cnt;
};

/**
 * 지정된 문자열을 잘라 문자열을 분할 한다.
 * @param {string} str : 문자열
 * @param {int} num : 잘라낼 문자열 Bytes수
 * @return {array} strArray : 분할한 문자열 배열
 */

Common.splitString=function (str, num, cnt)
{
	var strArray = [];
	var tmp = [];

	var nowByte = 0;
	var i = 0,iMax=str.length;
	var c;

	var step=0;
	for(i=0;i<iMax;i++){
		c = str.charCodeAt(i);
	//while(c = str.charCodeAt(i)){
		step = this.isEmSizeCharacter(c)?2:1;		//refactoring(문자의 폭을 판단)

		if(nowByte + step < num)		//이하의 내용일 경우
		{
			//문자열을 Copy
			//tmp[tmp.length] = str.substr(i++, 1);
			tmp[tmp.length] = str.substr(i, 1);
			nowByte+=step;
		}
		else if(nowByte+step == num)	//상한에 도달한 경우
		{
			//문자열을 Copy
			//tmp[tmp.length] = str.substr(i++, 1);
			tmp[tmp.length] = str.substr(i, 1);
			nowByte+=step;
			//문자열을 격납하고, tmp를 초기화
			strArray[strArray.length] = tmp.join("");
			tmp = [];
			nowByte = 0;
		}
		else if(nowByte+step > num)	//상한을 초과하는 경우
		{
			//문자열을 격납하고, tmp를 초기화
			strArray[strArray.length] = tmp.join("");
			tmp = [];
			nowByte = 0;

			//문자열을 Copy
			//tmp[tmp.length] = str.substr(i++, 1);
			tmp[tmp.length] = str.substr(i, 1);
			nowByte+=step;
		}
	}

	if(tmp.length > 0){
		strArray[strArray.length] = tmp.join("");
	}
	tmp = null;

	if(cnt&&strArray.length<cnt)
	{
		for(var i=strArray.length;i<cnt;i++)
		{
			strArray[i]="";
		}
	}
	return strArray;
};

Common.splitStr = function (str, chunkSize){
	var chunks = [];
	while (str) {
	    if (str.length < chunkSize) {
	        chunks.push(str);
	        break;
	    }
	    else {
	        chunks.push(str.substr(0, chunkSize));
	        str = str.substr(chunkSize);
	    }
	}
	return chunks;
};

Common.getIdx=function(id){return parseInt(id.substring(id.length, id.length-1));};

/**
 * 문자의 폭을 판단한다.
 * @param {string} c : 문자열
 * @return {bool} true: 전각, false:반각
 */
Common.isEmSizeCharacter = function(c)
{
	var width = true;
	//Shift_JIS: 0x0 ～ 0x80, 0xa0 , 0xa1 ～ 0xdf , 0xfd ～ 0xff
	//Unicode : 0x0 ～ 0x80, 0xf8f0, 0xff61 ～ 0xff9f, 0xf8f1 ～ 0xf8f3
	if((c >= 0x0 && c < 0x81) || (c == 0xf8f0) || (c >= 0xff61 && c < 0xffa0) || (c >= 0xf8f1 && c < 0xf8f4)){
		width = false;
	}
	return width;
};

/**
 * 문자열을 지정된 Bytes수로 자른다
 * @param {string} str : 문자열
 * @param {int} bytes : 잘라낼 Bytes수
 * @return {string} : 지정 Bytes수로 잘라낸 문자열
 */
Common.cutStringWidth = function(str, num)
{
	var tmp = [];

	var nowByte = 0;
	var i = 0;
	var c;

	var step=0;
	while(c = str.charCodeAt(i)){
		step = this.isEmSizeCharacter(c)?2:1;		//refactoring(문자의 폭을 판단)

		if(nowByte + step <= num)
		{
			tmp[tmp.length] = str.substr(i++, 1);
			nowByte += step;
		}
		else
		{
			break;
		}
	}
	return tmp.join("");
};

/**
 * List에서 Index를 반환 /Lib문제로 Prototype대신 별도의 Function으로 작성
 * @param {Array} collection
 * @param {object} obj
 * @return {int} idx : 대상이 없는 경우는 -1
 */
Common.indexOf = function(collection,obj)
{
	var idx = -1;
	if(collection instanceof Array)
	{
		for(var i = 0,il = collection.length; i < il; i++)
		{
			if(collection[i] == obj)
			{
				idx=i;
				break;
			}
		}
	}
	return idx;
};

Common.contains = function(collection,obj){
	return (this.indexOf(collection,obj) > -1);
};

/**
 * 해당 Element의 CSS Class를 설정
 * @param {string} id : 해당 Object의 ID
 * @param {string} arg : 해당하는 Class의 이름
 */
Common.setClass = function(id, arg)
{
	var obj = document.getElementById(id);
	if(obj)
	{
		obj.className = arg;
	}
};

Common.getClassList = function(obj){
	return obj.className.split(" ");
};

Common.setClassList = function(obj, lst){
	obj.className = lst.join(" ");
};

/**
 * 해당 Element의 CSS Class를 추가
 * @param {string} id : 추가할 Object의 ID
 * @param {string} arg : 추가된 Class의 이름
 */
Common.addClass = function(id, arg)
{
	var obj = document.getElementById(id);
	if(obj)
	{
		if(obj.classList) {
			obj.classList.add(arg);
		}
		else{
			var lst = Common.getClassList(obj);
			var idx = Common.indexOf(lst, arg);
			if(idx == -1) {
				lst.push(arg);
				Common.setClassList(obj, lst);
			}
		}
	}
};

/**
 * 해당 Element의 CSS Class를 제거
 * @param {string} id : 해당 Object의 ID
 * @param {string} arg : 제거된 Class의 이름
 */
Common.removeClass = function(id, arg)
{
	var obj = document.getElementById(id);
	if(obj)
	{
		if(obj.classList){
			obj.classList.remove(arg);
		}
		else{
			var lst = Common.getClassList(obj);
			var idx = Common.indexOf(lst, arg);
			while(idx > -1) {
				lst.splice(idx, 1);
				idx = Common.indexOf(lst, arg);
			}
			Common.setClassList(obj, lst);
		}
	}
};
/**
 * 해당 Element의 CSS Class를 Toggle
 * @param {string} id : 해당 Object의 ID
 * @param {string} arg : Toggle된 Class의 이름
 */
Common.toggleClass = function(id, arg)
{
	var obj = document.getElementById(id);
	if(obj)
	{
		obj.classList2.toggle(arg);
	}
};


Common.compareStr = function(strInput, strOutput)
{
	var i;
	for( i = strOutput.length, il = 0; i > il; --i) {
		if(strInput[i] == strOutput[i]) {
			break;
		}
	}
	return i+1;
};

Common.trimByEncodingSize = function(str, size)
{
	var encodedStr = URLUTF8Encoder.encodeURIComponent(str);
	var trimedStr = encodedStr.substr(0, size)
	var pattern = /%[^%]?$/;
	var regexResult = trimedStr.replace(pattern,'');
	return Common.getDecode(regexResult)
};
Common.getDecode = function(str)
{
	var result;
	try
	{
		result = decodeURIComponent(str);
	}
	catch(ex)
	{
		var pattern = /%[^%]+$/;
		var trimStr = str.replace(pattern,'');
		result = Common.getDecode(trimStr);
	}
	return result;
};

Common.trimEncodedString = function(str, length)
{
	var encodedStr = URLUTF8Encoder.encodeURIComponent(str);
	var trimedStr = encodedStr.substr(0, length)
	var pattern = /%[^%]?$/;
	var regexResult = trimedStr.replace(pattern,'');
	return Common.getDecode(regexResult)
};

/**
 * 유저 제한 정보의 취득ユ?ザの制限情報の取得
 * -사양 변경(V1.5.0)
 * -Step2.1에 Refactoring(Copy/Print와 공통화)
 */
Common.getUserPermitInfo = function()
{
	var tempInfo = BrowserExt.getPermitInfo();
	glbDevInfo.permitInfo = [];
	glbDevInfo.permitInfo[PERMIT_CHK.FULL_COLOR] = tempInfo.slice(8,9);
	glbDevInfo.permitInfo[PERMIT_CHK.LIMITED_COLOR] = tempInfo.slice(9,10);
	glbDevInfo.permitInfo[PERMIT_CHK.BW] = tempInfo.slice(10,11);
};

/**
 * 유저의 Color이용 제한 의 판별
 * -Step2.1에 Refactoring
 */
Common.setCmType = function()
{
	with(glbDevInfo)
	{
		if(permitInfo[PERMIT_CHK.FULL_COLOR]==0)
		{
			if(permitInfo[PERMIT_CHK.BW]==0)
			{
				glbDevInfo.cmType = CMType.None;
			}
			else if(permitInfo[PERMIT_CHK.BW]==1)
			{
				glbDevInfo.cmType = CMType.BNW;
			}
		}
		else if(permitInfo[PERMIT_CHK.FULL_COLOR]==1)
		{
			if(permitInfo[PERMIT_CHK.BW]==0)
			{
				glbDevInfo.cmType = CMType.Color;
			}
			else if(permitInfo[PERMIT_CHK.BW]==1)
			{
				glbDevInfo.cmType = CMType.All;
			}
		}
	}
};

/**
 * 유저의 기준ColorMode를 취득
 * -사양변경(V1.5.0) Start
 */
Common.getColorModeDefault = function(){
	var result = 0;
	switch(glbDevInfo.cmType)
	{
		case CMType.All:
			result = 0;		//Color Auto
			break;
		case CMType.Color:
			result = 1;		//Full Color
			break;
		case CMType.BNW:
			result = 2;		//GrayScale
			break;
		case CMType.None:
			result = -1;	//대상외
			break;
		default:
			//error
			break;
	}
	return result;
};

/**
 * 유저의 Color Mode를 확인
 * -사양변경(V1.5.0)
 */
Common.chkColorMode = function(idx){
	var modes = Common.chkColorModes();
	var result = {forbid:modes.status[idx],msg:modes.msg};
	return result;
};
/**
 * 유저의 Color Mode를 확인
 * -사양변경(V1.5.0)
 */
Common.chkColorModes = function()
{
	var result = {};
	switch(glbDevInfo.cmType)
	{
		case CMType.All:
			result = {status:[false,false,false,false],msg:""};
			break;
		case CMType.Color:
			result = {status:[true,false,true,true],msg:Msg.CONFLICT.MSG_R2};
			break;
		case CMType.BNW:
			result = {status:[true,true,false,false],msg:Msg.CONFLICT.MSG_R1};
			break;
		case CMType.None:
			result = {status:[true,true,true,true],msg:""};	//invalid parameter
			LogLib.write("Common.chkColorModes/invalid parameter:0_0",LogLib.LEVEL.WRN);
			break;
		default:
			LogLib.write("Common.chkColorModes/invalid parameter:" + glbDevInfo.cmType, LogLib.LEVEL.WRN);		//error
			break;
	}
	return result;
};

/**
 * 송신 Mail에 Set된 메일 Address를 취득(미사용 함수)
 * -사양변경(V1.6.0)
 */
Common.getSourceAddress = function()
{
	var result = "";
	if(CONFIG.SourceAddress == SourceAddressType.Device) {
		result = "";
	}
	else
	if(CONFIG.SourceAddress == SourceAddressType.User) {
		result = glbEmail.address;
	}
	else {
		result = "";
		LogLib.write("getSourceAddress/CONFIG.SourceAddress:" + CONFIG.SourceAddress, LogLib.LEVEL.WRN);
	}
	return result;
};

/**
 * Page를 Click할 때의 Event/현재의 Page의 OnPageClick Event
 */
function onPageClick()
{
	var currentPage = PageManager.getCurrentPage();
	if(currentPage){
		if(currentPage.onPageClick)currentPage.onPageClick();
	}
};

/**
 * 화면 Object의 enable, disable처리
 * @param id {string} : Object의 ID
 * @param enable {boolean} true:enable한다, false:disable한다.
 */
Common.setObjectEnable = function(id, enable){
	if(!id){
		return;
	}
	if(enable){
		WidgetLib.setWidgetStatus(id, {enable:true});
	}else{
		WidgetLib.setWidgetStatus(id, {enable:false});
	}
};

/**
 * Object가 Null 또는 Empty상태일 때의 판별
 */
Common.isNullOrEmpty = function(obj){
	var result = false;
	switch(typeof obj){
		case "undefined":
			result = true;
			break;
		case "object":
			if(obj === null){
				result = true;
			}
			break;
		case "string":
			if(obj === null || obj === ""){
				result = true;
			}
			break;
		default:
			//console.log(obj);
			break;
	}
	return result;
};

Common.removePrefix = function(str){
	var pattern = /([^:]+)$/;
	var result = str.match(pattern);
	return result[1];
}
// Changes XML to JSON

Common.xmlToJson = function(xml)
{
	// Create the return object
	var obj = {};
	/*if (xml.attributes.length > 0) {
		obj["@attributes"] = {};
		for (var j = 0; j < xml.attributes.length; j++) {
			var attribute = xml.attributes.item(j);
			obj["@attributes"][this.removePrefix(attribute.nodeName)] = attribute.nodeValue;
		}
	}*/
	// do children
	if (xml.hasChildNodes()) {
		for (var i = 0, iMax = xml.childNodes.length; i < iMax; i++) {
			var item = xml.childNodes.item(i);
			var nodeName = this.removePrefix(item.nodeName);
			if (item.nodeType == 1) {//object
				if (typeof (obj[nodeName]) == "undefined") {
					obj[nodeName] = this.xmlToJson(item);
				}
				else {
					if (typeof (obj[nodeName].length) == "undefined") {
						var old = obj[nodeName];
						obj[nodeName] = [];
						obj[nodeName].push(old);
						obj.flg=true;
					}
					obj[nodeName].push(this.xmlToJson(item));
				}
			}
			else if (item.nodeType == 3) {// text
				obj = item.nodeValue;
			}
		}
		if(obj.flg == true){
			var old = obj[nodeName];
			obj = old;
		}
	}
	return obj;
};
Common.getObjLength = function(obj){
	var cnt=0;
	for(var tmp in obj){
		cnt++;
	}
	return cnt;
};
Common.getIndex = function(collection,_value){
	var idx = -1;
	var tmp;
	for(var i = 0, iMax = collection.length; i < iMax; i++){
		tmp = collection[i];
		if(tmp.value == _value){
			idx = i;
			break;
		}
	}
	return idx;
};

Common.getKey = function(collection,_value){
	var key = "";
	var tmp;
	for(var i = 0, iMax = collection.length; i < iMax; i++){
		tmp = collection[i];
		if(tmp.value == _value){
			key = tmp.key;
			break;
		}
	}
	return key;
};

Common.setIndex = function(_id,_idx){
	var obj = document.getElementById(_id);
	if(obj && obj.tagName.toLowerCase() == "select"){
		obj.selectedIndex=_idx;
	}
};

function parseBool(value) {
    return (typeof value === "undefined") ?
           false :
           // trim using jQuery.trim()'s source
           value.replace(/^\s+|\s+$/g, "").toLowerCase() === "true";
};
function loadScript(loc){
	var tag = document.createElement("script");
	tag.setAttribute("type", "text/javascript");
	tag.setAttribute("src", loc);
	tag.setAttribute("charset", "UTF-8");
	document.getElementsByTagName("head")[0].appendChild(tag);
};

/**
 * 프린트잡 실행
 */
//2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193 Start
Common.doJobStart = function(_lst)
{
	glbInfo.isJobExcuted = true;

	PageManager.changePage(PrintingPopup, PageManager.type.NORMAL);//인쇄중 화면으로 천이

	glbProgress = {private_print : false, server_print : false};

	if(!_lst || (_lst && _lst.length == 0)){//즉시 출력
		Common.doImmediateJob();
		return;
	}

	var privatePrintLst = [];
	var serverPrintLst = [];

	for(var i=0; i<_lst.length; i++){//Private Print 문서와 서버로부터 받은 문서를 분리해서 잡 실행 준비
		if(_lst[i].boxId){
			privatePrintLst.push(_lst[i]);
		}else{
			serverPrintLst.push(_lst[i]);
		}
	}

	if(privatePrintLst.length > 0){//Private Print 문서가 있을 경우 - Private Print 문서를 우선해서 잡 실행함
		Common.doJobPrivatePrintDocument(privatePrintLst);
	}

	if(serverPrintLst.length > 0){//서버 문서가 있을 경우 잡 실행함
		Common.doJobServerDocument(serverPrintLst)
	}
};
Common.doImmediateJob = function()//즉시 출력, private_print 문서 취득 후, private_print, 서버 순으로 출력 지시를 내림.
{
	if(glbDbmEnable && glbInfo.usagePrnCnt.prnCountPrivate > 0){
		glbDbm.getDocList();
	}else{
		if(glbInfo.usagePrnCnt.prnCountServer > 0){
			Common.doImmediateJobServerDocument();
		}
	}
};

Common.doJobPrivatePrintDocument = function(_lst)//Private Print 선택 출력
{
	glbProgress.private_print = true;

	var exeJfsObj = Common.createExecuteJfsObject(_lst);
	SSMILib.ExecuteJFS.Send(exeJfsObj);
};

Common.createExecuteJfsObject = function(_lst)//ExecuteJFS 용 지시서 작성
{
	var i, _tmp, mailBox, jftMailbox, jftDocument, boxesInfo = [], boxesInfo, exeJfsObj;
	for(i in _lst){
		_tmp = _lst[i];
		mailBox = new SSMILib.ExecuteJFS.MailBox();

		jftMailbox = new JfsUtil.MailBox();
		jftMailbox.Identifier = _tmp.boxId;//boxID設定
		mailBox.MailBox = jftMailbox;

		jftDocument = new JfsUtil.Document();
		jftDocument.Identifier = _tmp.UUID;
		mailBox.Document = jftDocument;

		boxesInfo.push(mailBox);
	}

	exeJfsObj = new SSMILib.ExecuteJFS(createJobTemplate());
	exeJfsObj.boxesInfo = boxesInfo;

	return exeJfsObj;
};

//SmartUI 2017.02 복수의 Print Server 대응 refs #4184
Common.doJobServerDocument = function(_lst)//서버 문서 선택 출력
{
	glbProgress.server_print = true;

	if(glbInfo.SERVER_NUM == 1){
		glbInfo.DOC_PROC_COUNT = 1;
		var splObj = new SSMILib.SelectedPrnInfo4Print();
		splObj.userId = glbInfo.userInfo.userId;
		splObj.deviceIp = glbInfo.ipAddress;
		splObj.wsIp = glbConfig.wsIp[0];
		splObj.listSelected = convertToPRNData(_lst);
		SSMILib.PrintSelectedPrnInfo(splObj, DOC_PRINT_TIMEOUT, glbConfig.DATA.SERVER_URL[0]);
	}else{
		var tmp = [];
		glbInfo.DOC_PROC_COUNT = 0;

		for(var i = 0;glbConfig.DATA.SERVER_URL.length > i;i++){
			if(glbConfig.DATA.SERVER_URL[i] != "Re-enter"){
				tmp[i] = [];
				for(var j=0; j<_lst.length; j++){
					var idx = _lst[j].serverIdx;
					if(i == idx){
						tmp[i].push(_lst[j]);
					}
				}


				if(tmp[i].length > 0){
					glbInfo.DOC_PROC_COUNT++;
					var splObj = new SSMILib.SelectedPrnInfo4Print();
					splObj.userId = glbInfo.userInfo.userId;
					splObj.deviceIp = glbInfo.ipAddress;
					splObj.wsIp = glbConfig.wsIp[i];
					splObj.listSelected = convertToPRNData(tmp[i]);
					SSMILib.PrintSelectedPrnInfo(splObj, DOC_PRINT_TIMEOUT, glbConfig.DATA.SERVER_URL[i]);
				}
			}
		}
	}
};

Common.doImmediateJobServerDocument = function()//서버 문서 즉시 출력
{
	glbProgress.server_print = true;

	for(var i = 0;glbConfig.DATA.SERVER_URL.length > i;i++){
		if(glbConfig.DATA.SERVER_URL[i] != "Re-enter"){
			var apiObj = new SSMILib.AllPrnInfo();
			apiObj.userId = glbInfo.userInfo.userId;
			apiObj.deviceIp = glbInfo.ipAddress;
			apiObj.wsIp = glbConfig.wsIp[i];
			apiObj.deviceColor = glbInfo.deviceColor;
			SSMILib.PrintAll(apiObj, DOC_PRINT_TIMEOUT, glbConfig.DATA.SERVER_URL[i])
		}
	}
};

Common.doDeleteStart = function()
{
	glbProgress = {private_print : false, server_print : false};

	var privatePrintLst = [];
	var serverPrintLst = FileListPage.docListManager.getSelectedUUIDs((glbInfo.SERVER_NUM == 1));
	var lst = FileListPage.docListManager.getCheckedItems()

	for(var i=0; i<lst.length; i++){
		if(lst[i].boxId){
			privatePrintLst.push(lst[i]);
		}
	}

	if(privatePrintLst.length > 0){//Private Print 문서가 있을 경우 - Private Print 문서를 우선 삭제
		Common.doDeletepPrivatePrintDocument(privatePrintLst);
	}

	if(serverPrintLst.length > 0){//서버 문서가 있을 경우 삭제 실행함
		Common.doDeleteServerDocument(serverPrintLst);
	}
};

Common.doDeletepPrivatePrintDocument = function(lst)
{
	glbProgress.private_print = true;

	var _docs = [];
	var sdObj = new SSMILib.StoredDocument();
	sdObj.userIdentifierTypes.push(SSMILib.USER_IDTYPE.IC_CARD);
	sdObj.userIdentifierTypes.push(SSMILib.USER_IDTYPE.RELATED_USER);

	for(var i=0; i<lst.length; i++){
		var _tmp = lst[i];
		var _doc = new SSMILib.Document();
	    _doc.id = _tmp.UUID;
	    sdObj.documents.push(_doc);
	}

	SSMILib.DeleteStoredDocument(sdObj);
};

//SmartUI 2017.02 복수의 Print Server 대응 refs #4184
Common.doDeleteServerDocument = function(lst)
{
	glbProgress.server_print = true;

	if(glbInfo.SERVER_NUM == 1){
		glbInfo.DOC_PROC_COUNT = 1;
		var spList = new SSMILib.SelectedPrnInfo4Delete();
		spList.userId = glbInfo.userInfo.userId;
		spList.wsIp = glbConfig.wsIp[0];
		spList.listSelected = lst;
		SSMILib.DeleteSelectedPrnInfo(spList, null, glbConfig.DATA.SERVER_URL[0]);
	}else{
		glbInfo.DOC_PROC_COUNT = lst.length;
		for(var i=0; i<lst.length; i++){
			var idx = lst[i].serverIdx;
			var spList = new SSMILib.SelectedPrnInfo4Delete();
			spList.userId = glbInfo.userInfo.userId;
			spList.wsIp = glbConfig.wsIp[idx];
			spList.listSelected = [lst[i].uuid];
			SSMILib.DeleteSelectedPrnInfo(spList, null, glbConfig.DATA.SERVER_URL[idx]);
		}
	}
};

//2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193 End

Common.replaceStrAtArray = function(_collection,_key,_value){
	var _result = new Array(_collection.length);
	for(var i = 0, iMax = _collection.length; i < iMax; i++){
		_result[i] = _collection[i].replace(_key,_value);
	}
	return _result;
};

/**
 * Label 문구 변경
 * Custom Label을 사용할 경우에 설정된 Label로 변경.
 */
Common.changeMenuLabel = function(_lang){
	if(CONFIG.CUSTOM_LABEL){
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_01 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_01] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_01;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_02 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_02] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_02;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_03 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_03] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_03;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_04 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_04] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_04;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_05 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_05] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_05;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_06 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_06] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_06;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_07 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_07] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_07;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_08 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_08] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_08;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_09 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_09] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_09;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_10 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_10] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_10;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_11 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_11] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_11;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_12 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_12] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_12;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_13 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_13] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_13;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_14 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_14] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_14;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_15 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_15] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_15;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_16 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_16] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_16;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_17 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_17] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_17;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_18 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_18] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_18;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_19 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_19] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_19;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_20 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_20] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_20;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_21 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_21] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_21;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_22 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_22] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_22;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_23 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_23] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_23;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_24 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_24] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_24;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_25 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_25] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_25;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_26 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_26] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_26;
		}
		if(CONFIG.FUNC_LABEL[_lang].FUN_LABEL_27 != "Default"){
			Msg_lang[_lang].Funcs[CONFIG.USER_SET.FUN_IMG_27] = CONFIG.FUNC_LABEL[_lang].FUN_LABEL_27;
		}
	}
}
