﻿/**
 * 개별 페이지의 표시 및 동작용
 * （IC Card등록용 팝업）
 */
var FileListPage = new TemplatePage();

FileListPage.ID = "page_FileList";
FileListPage.key = "FL";

/**
 * 개별 페이지의 Data정의
 */
FileListPage._initModel=function()
{
	this._data=
	{
		buttonList:[
			{	//전체선택버튼
				id:"btn_FL_SelectAll",
				type:WidgetLib.ButtonType.NORMAL,
				status:{enable:false},
				attr:{targetImgId:"img_FL_SelectAll", offImg:Img["SELECT_ALL_BTN_OFF"], pressImg:Img["SELECT_ALL_BTN_PRESS"], onImg:Img["SELECT_ALL_BTN_ON"], disableImg:Img["SELECT_ALL_BTN_DIS"],
						iconAttr:{targetImgId:"img_FL_SelectAllIcon",offImg: Img.FILE_LIST_SELECTALL_ICON_OFF, pressImg: Img.FILE_LIST_SELECTALL_ICON_PRESS}}
			},
			{	//전체프린트버튼
				id:"btn_FL_PrintAll",
				type:WidgetLib.ButtonType.NORMAL,
				status:{enable:false},
				attr:{targetImgId:"img_FL_PrintAll",offImg:Img["PRINT_ALL_BTN_OFF"], pressImg:Img["PRINT_ALL_BTN_PRESS"], disableImg:Img["PRINT_ALL_BTN_DIS"]}
			},
		    {	//새로고치버튼
		    	id:"btn_FL_Refresh",
		    	type:WidgetLib.ButtonType.NORMAL,
		    	status:{enable:false},
		    	attr:{targetImgId:"img_FL_Refresh", offImg:Img["DISPLAY_CHANGE_BTN_OFF"], pressImg:Img["DISPLAY_CHANGE_BTN_PRESS"], disableImg:Img["DISPLAY_CHANGE_BTN_DIS"]}
		    },
		    {	//페이지업버튼
		    	id:"btn_FL_pageUp",
		    	type:WidgetLib.ButtonType.NORMAL,
		    	status:{enable:false},
		    	attr:{offImg:Img["FILE_LIST_UP_BTN_OFF"], pressImg:Img["FILE_LIST_UP_BTN_PRESS"], disableImg:Img["FILE_LIST_UP_BTN_DIS"]}
		    },
		    {	//페이지다운버튼
		    	id:"btn_FL_pageDown",
		    	type:WidgetLib.ButtonType.NORMAL,
		    	status:{enable:false},
		    	attr:{offImg:Img["FILE_LIST_DOWN_BTN_OFF"], pressImg:Img["FILE_LIST_DOWN_BTN_PRESS"], disableImg:Img["FILE_LIST_DOWN_BTN_DIS"]}
		    },
		    {	//파일삭제버튼
		    	id:"btn_FL_DeleteFile",
		    	type:WidgetLib.ButtonType.NORMAL,
		    	status:{enable:false},
		    	attr:{targetImgId:"img_FL_DeleteFile", offImg:Img["DELETE_FILE_BTN_OFF"], pressImg:Img["DELETE_FILE_BTN_PRESS"], disableImg:Img["DELETE_FILE_BTN_DIS"],
		    			iconAttr:{targetImgId:"img_FL_DeleteIcon",offImg: Img.FILE_LIST_DELETE_ICON_OFF, pressImg: Img.FILE_LIST_DELETE_ICON_PRESS}}
		    },
		    {	//프린트설정변경버튼
		    	id:"btn_FL_Modi_PrintSetting",
		    	type:WidgetLib.ButtonType.NORMAL,
		    	status:{enable:false},
		    	attr:{targetImgId:"img_FL_Modi_PrintSetting", offImg:Img["FILE_LIST_COMMAND_BTN_OFF"], pressImg:Img["FILE_LIST_COMMAND_BTN_PRESS"], disableImg:Img["FILE_LIST_COMMAND_BTN_DIS"],
		    			iconAttr:{targetImgId:"img_FL_Modi_PrintSettingIcon",offImg: Img.FILE_LIST_PS_SETTING_ICON_OFF, pressImg: Img.FILE_LIST_PS_SETTING_ICON_PRESS}}
		    },
		    {	//프린트버튼
		    	id:"btn_FL_Print",
		    	type:WidgetLib.ButtonType.NORMAL,
		    	status:{enable:false},
		    	attr:{targetImgId:"img_FL_Print", offImg:Img["PRINT_BTN_OFF"], pressImg:Img["PRINT_BTN_PRESS"], disableImg:Img["PRINT_BTN_DIS"],
		    			iconAttr:{targetImgId:"img_FL_PrintIcon",offImg: Img.FILE_LIST_PRINT_ICON_OFF, pressImg: Img.FILE_LIST_PRINT_ICON_PRESS}}
		    },
       	    {
       	    	id:"btn_FL_PrintAdd",
       	    	type:WidgetLib.ButtonType.NORMAL,
       	    	status:{enable:false},
       	    	attr:{targetImgId:"img_FL_PrintAdd", offImg:Img["PRINT_ADD_BTN_OFF"], pressImg:Img["PRINT_ADD_BTN_PRESS"], disableImg:Img["PRINT_ADD_BTN_DIS"]}},
       	    {
       	    	id:"btn_FL_PrintRemove",
       	    	type:WidgetLib.ButtonType.NORMAL,
       	    	status:{enable:false},
       	    	attr:{targetImgId:"img_FL_PrintRemove", offImg:Img["PRINT_REMOVE_BTN_OFF"], pressImg:Img["PRINT_REMOVE_BTN_PRESS"], disableImg:Img["PRINT_REMOVE_BTN_DIS"]}
       	    },
			// Watermark 해제 버튼
			{
				id		: "btn_FL_Modi_WmDisable",
				type	: WidgetLib.ButtonType.NORMAL,
		    	status	: {
					enable : false
				},
		    	attr	: {
					targetImgId : "img_FL_Modi_WmDisable", 
					offImg		: Img["FILE_LIST_COMMAND_BTN_OFF"], 
					pressImg	: Img["FILE_LIST_COMMAND_BTN_PRESS"], 
					disableImg	: Img["FILE_LIST_COMMAND_BTN_DIS"]
				}
			},
			// Watermark 활성 버튼
			{
				id		: "btn_FL_Modi_WmEnable",
				type	: WidgetLib.ButtonType.NORMAL,
		    	status	: {
					enable:false
				},
		    	attr	: {
					targetImgId	: "img_FL_Modi_WmEnable", 
					offImg		: Img["FILE_LIST_COMMAND_BTN_OFF"], 
					pressImg	: Img["FILE_LIST_COMMAND_BTN_PRESS"], 
					disableImg	: Img["FILE_LIST_COMMAND_BTN_DIS"]
				}
			},
       	    //사용안함
       	    {id:"btn_AP_Close",	type:WidgetLib.ButtonType.NORMAL, status:{enable:false}, attr:{targetImgId:"img_AP_Close", offImg:Img["POPUP_YELLOW_CLOSE_BTN_OFF"], pressImg:Img["POPUP_YELLOW_CLOSE_BTN_PRESS"]}}
		],
		imageList:[
			/*{id:"img_FL_bg",	src:Img["IMG_FL_BG"]},*/
			{ id: "img_FL_bg", 			src: Img["FILE_LIST_BACKGROUND_IMG"] },
            { id: "img_FL_NotifyImg", 	src: Img["FILE_LIST_LODING_ICON"] }
		],
		textList:[
			//{id:"lbl_FL_Refresh",	text:Msg.FILELIST.DISPLAY_CHANGE_BTN_LABEL},
			{ id : "lbl_FL_PrintAll",			text : Msg.FILELIST.PRINT_ALL},
			{ id : "lbl_FL_Print",				text : Msg.FILELIST.PRINT},
			{ id : "lbl_FL_SelectedFile",		text : Msg.FILELIST.SELECTED_FILE_NUMBER_MSG},
			{ id : "lbl_FL_SelectAll0",			text : Msg.FILELIST.SELECT_ALL_BTN_LABEL_0},
			{ id : "lbl_FL_SelectAll1",			text : Msg.FILELIST.SELECT_ALL_BTN_LABEL_1},
			{ id : "lbl_FL_DeleteFile",			text : Msg.FILELIST.DELETE_FILE_BTN_LABEL},
			{ id : "txt_FL_PrintQuantity",		text : ""},
			{ id : "lbl_FL_PrintQuantity",		text : Msg.FILELIST.COMMON_PRINT_QUANTITY_LABEL},
			{ id : "lbl_FL_Modi_PrintSetting0",	text : Msg.FILELIST.PRINT_SETTING_BTN_LABEL_0},
			{ id : "lbl_FL_Modi_PrintSetting1",	text : Msg.FILELIST.PRINT_SETTING_BTN_LABEL_1},
			{ id : "lbl_FL_Modi_WmDisable0",	text : Msg.FILELIST.WM_DISABLE_BTN_LABEL_0},
			{ id : "lbl_FL_Modi_WmDisable1",	text : Msg.FILELIST.WM_DISABLE_BTN_LABEL_1},
			{ id : "lbl_FL_Modi_WmEnable0",		text : Msg.FILELIST.WM_ENABLE_BTN_LABEL_0},
			{ id : "lbl_FL_Modi_WmEnable1",		text : Msg.FILELIST.WM_ENABLE_BTN_LABEL_1},
			{ id : "txt_FL_NotifyMsg0",			text : Msg.FILELIST.LOADING_MSG_0},
			{ id : "txt_FL_NotifyMsg1",			text : Msg.FILELIST.LOADING_MSG_1},
			{ id : "txt_FL_NotifyMsg2",			text : Msg.FILELIST.LOADING_MSG_2},
			{ id : "txt_FL_NotifyMsg3",			text : Msg.FILELIST.LOADING_MSG_3}
		]
	};
	this.docListManager = new DocListManager({targetId:"lyr_FL_Display_Area"});
	this.docListManager.updateSelectedFileCount = FileListPage.updateDisplaySelectedFileCount;
	this.docListManager.updateCurrentPage = FileListPage.updateDisplayCurrentPage;
	this.docListManager.updateTextPrnSet = FileListPage.updateDisplayPrintQuantity;
	this.prnCntManager = new PrintCountManager();
	this.prnCntManager.updateDisplay = this.updateDisplayPrintQuantity;
	this.validator = new Validator();
	this.validator.init();
};

/**
 * 페이지 천이 직후 호출됨
 */
FileListPage._onPageChange = function(){
	//문서리스트가 존재하지않는경우(리스트화면 최초 표시시점)
	//문서리스트를 요청,최초이외의 경우의 갱신은 갱신버튼에 의한 경우밖에 없으므로
	var _loadFlg = false;
	if(!this._dataSet.docList || glbInfo.isJobExcuted){
		_loadFlg = true;
		//잡 실행에 Flag 원복
		glbInfo.isJobExcuted = false;
		//리스트 선택정보 초기화
		this.docListManager.currentPageIdx = 1;		//페이지 초기화
		this.docListManager.selectedItemIdx = -1;	//선택 초기화
		this.docListManager.setCheckedItems([]);	//체크 초기화

		this.displayFileSelectedNumLoading();
	}
	else {//if(this._dataSet.docList)
		this.docListManager.setDataSource(this._dataSet.docList);
		if(this.docListManager.selectedItemIdx > -1){
			var _doc = this.docListManager.dataSource[this.docListManager.selectedItemIdx];
			this.prnCntManager.setNum(_doc.printCnt);
			//인쇄매수 변경분 반영
			this.docListManager.updateQuantity(this.updateQuantity, false);
			//this.docListManager.updateInvalidFlag();
		}
	}
	this.updateDisplay();
	if(_loadFlg){
		this.refreshStoredDocument();
	}
};

/**
 * 화면 표시의 갱신 (공용/화면전환시 호출된다.)
 */
FileListPage.updateDisplay = function(){
	KISUtil.debug("function:", "updateDisplay");
	if(this._dataSet.docList){
		//this.docListManager.setDataSource(this._dataSet.docList);		//TODO:_onPageChange에서 중복할당중임 시간될때 refactoring할것
		this.docListManager.refresh();
		var _selectedDoc = this.docListManager.getSelectedDocInfo();
		if(_selectedDoc.success){
			this.prnCntManager.setNum(_selectedDoc.doc.printCnt);
		}
	}
	glbWmSelectFunc = true;
	if(glbInfo.userInfo.watermarkPolicy == "Y"){
		Common.changeVisibility("btn_FL_Modi_WmDisable",	"block");
		Common.changeVisibility("btn_FL_Modi_WmEnable",		"block");
		WidgetLib.setWidgetStatus("btn_FL_Modi_WmDisable", 	{enable:true});
		WidgetLib.setWidgetStatus("btn_FL_Modi_WmEnable", 	{enable:true});
	}else{
		Common.changeVisibility("btn_FL_Modi_WmDisable",	"none");
		Common.changeVisibility("btn_FL_Modi_WmEnable",		"none");
		if(gDummyFlag){
			Common.changeVisibility("btn_FL_Modi_WmDisable",	"block");
			Common.changeVisibility("btn_FL_Modi_WmEnable",		"block");
			WidgetLib.setWidgetStatus("btn_FL_Modi_WmDisable", 	{enable:true});
			WidgetLib.setWidgetStatus("btn_FL_Modi_WmEnable", 	{enable:true});
		}
	}
	if(SSMILib.dummy){
		FileListPage.getServerStoredDocument();
		return;
	}
};

FileListPage._getCurrentPolicy = function(){
	var _doc = this.docListManager.getSelectedDocInfo().doc,
		_forcedBlack = glbDataSet.userPolicyInfo.forcedBlack?1:0,
		_forcedNup = glbDataSet.userPolicyInfo.forced2Up?1:0,
		_forcedDuplex = glbDataSet.userPolicyInfo.forcedDuplex?1:0,
		_forbid = parseInt(glbDataSet.userPolicyInfo.functionCtrl);
	var _policy = this.validator.getBtnStatusByPolicy(_forbid, _forcedNup,_forcedDuplex, _forcedBlack, _doc);

	return _policy;
};

FileListPage._getListPolicy = function(idx){
	var _doc = this.docListManager.getListDocInfo(idx).doc,
		_forcedBlack = glbDataSet.userPolicyInfo.forcedBlack?1:0,
		_forcedNup = glbDataSet.userPolicyInfo.forced2Up?1:0,
		_forcedDuplex = glbDataSet.userPolicyInfo.forcedDuplex?1:0,
		_forbid = parseInt(glbDataSet.userPolicyInfo.functionCtrl);
	var _policy = this.validator.getBtnStatusByPolicy(_forbid, _forcedNup,_forcedDuplex, _forcedBlack, _doc);

	return _policy;
};

/**
 * 개별 페이지의 Event처리
 * @param {string} event : Event종류
 * @param {string} id : Event 발생원
 */
FileListPage.EventHandler = function(event, id)
{
	KISUtil.debug("EventHandler","event:"+event+"/id:"+id);
	switch(event){
		case "GetStoredDocList":
			glbDataSet.docList = glbInfo.docList;
			FileListPage.getServerStoredDocument();
			break;
		case "GetPrnListPolicy"://SmartUI 2017.02 복수의 Print Server 대응 refs #4184
			if(glbInfo.serverCallCount == 0){//glbDataSet.usedFileCount값이 누적되지 않도록 통신시마다 리셋함
				glbDataSet.usedFileCount = 0;
			}
			glbInfo.serverCallCount++;
			if(arguments[1] == true){
				var _result = arguments[2];
				if(_result.status == "success"){
					var _resultData = _result.result;
					var _userInfo = _resultData.userInfo;
					glbDataSet.userPolicyInfo.forced2Up = (_userInfo.forced2Up=="Y");
					glbDataSet.userPolicyInfo.forcedBlack = (_userInfo.forcedBlack=="Y");
					glbDataSet.userPolicyInfo.defaultBlack = (_userInfo.defaultBlack=="Y");									//사양변경분 대응 2013/04/03
					glbDataSet.userPolicyInfo.forcedDuplex = (_userInfo.forcedDuplex=="Y");
					glbDataSet.userPolicyInfo.functionCtrl = parseInt(_userInfo.functionCtrl);
					glbDataSet.userPolicyInfo.printAgain = (_userInfo.printAgain=="Y");
					glbDataSet.userPolicyInfo.prnCount = glbInfo.usagePrnCnt.overCountPrint?0:parseInt(_userInfo.prnCount);	//사양변경분 대응 2013/02/22
					glbDataSet.userPolicyInfo.watermarkPolicy = (_userInfo.watermarkPolicy=="Y");
					if(flg_Dummy_Beep)
					{
						if(glbDataSet.userPolicyInfo.watermarkPolicy){
							glbDataSet.userPolicyInfo.watermarkPolicy = false;
						}else{
							glbDataSet.userPolicyInfo.watermarkPolicy = true;
						}
					}
					glbDataSet.userPolicyInfo.userId = _userInfo.userId;

					if(_resultData.prnList){
						var _tmp = convertToVMData(_resultData.prnList, _resultData.userInfo.serverIdx);
						var _lst = _tmp.lst;

						if(glbDataSet.docList && glbDataSet.docList.length > 0){//2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193
							for(var i=0; i<_lst.length; i++){
								glbDataSet.docList.push(_lst[i]);
							}
						}else{
							glbDataSet.docList = _lst;
						}

						glbDataSet.usedFileCount += _tmp.usedFileCount;
					}
				}else{
					glbInfo.serverErrCount++;
					LogLib.info("[CS] GetUsagePrnCnt Error : " + _result.status);
				}
			}else{
				glbInfo.serverErrCount++;
				KISUtil.debug("Common.onLoadEvent/GetPrnListPolicy", "fail");
			}

			if (glbInfo.serverCallCount == glbInfo.SERVER_NUM) {
                if ((glbInfo.serverCallCount == glbInfo.serverErrCount) && (glbInfo.usagePrnCnt.prnCountPrivate <= 0) && (glbInfo.usagePrnCnt.prnCount <= 0)) {
                    WarnPopup._message = { title: Msg.WarnPopup.title, type: "logout", targetPage: true, message: Msg.errorMessage.ERRCODE000 };
                    PageManager.changePage(WarnPopup, PageManager.type.NORMAL);
                } else {
                    glbDataSet.docList.sort(sortingLogic);
                    this.docListManager.initDisplay();

                    this.store();
                    this.docListManager.currentPageIdx = 1; //페이지 초기화
                    this.docListManager.setDataSource(glbDataSet.docList);

                    //선택출력 리스트 개선 요청 건 - 취득한 모든 문서가 미프린트의 경우에는 선택 상태로 하지 않음
                    //미프린트 문서와 기프린트 문서가 섞여 있을 경우, 미프린트 문서를 선택 상태로 표시함
                    //2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
                    if (glbConfig.DATA.LIST_AUTO_SELECT == 1) { //SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
                        //this.docListManager.setCheckedItems(this.getSelectedListByLength(glbDataSet.docList.length - _tmp.usedFileCount - glbInfo.usedPrivatePrintCount));
                        this.docListManager.setCheckedItems(this.getSelectedListByUseYnFlag());
                        if(glbDataSet.docList.length == 1){
                        	this.docListManager.selectedItemIdx = 0;
                        }
                    }else{
                    	this.prnCntManager.setEnableFlag(false);
                    }
                    this.docListManager.refresh();
                    document.getElementById("lyr_FL_Display_Area").className = "";
                }
                glbInfo.serverCallCount = 0;
                glbInfo.serverErrCount = 0;
            }else{
              glbDataSet.docList.sort(sortingLogic);
              this.docListManager.initDisplay();

              this.store();
              this.docListManager.currentPageIdx = 1; //페이지 초기화
              this.docListManager.setDataSource(glbDataSet.docList);

              //선택출력 리스트 개선 요청 건 - 취득한 모든 문서가 미프린트의 경우에는 선택 상태로 하지 않음
              //미프린트 문서와 기프린트 문서가 섞여 있을 경우, 미프린트 문서를 선택 상태로 표시함
              //2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
              if (glbConfig.DATA.LIST_AUTO_SELECT == 1) { //SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
                  //this.docListManager.setCheckedItems(this.getSelectedListByLength(glbDataSet.docList.length - _tmp.usedFileCount - glbInfo.usedPrivatePrintCount));
                  	this.docListManager.setCheckedItems(this.getSelectedListByUseYnFlag());
                  	if(glbDataSet.docList.length == 1){
                        	this.docListManager.selectedItemIdx = 0;
                    }
              }else{
                  	this.prnCntManager.setEnableFlag(false);
              }
              this.docListManager.refresh();
              document.getElementById("lyr_FL_Display_Area").className = "";
            }
            break;
		case "DeleteSelected":
			//리스트 및 데이터 소스에서 선택항목을 제거
			//표시를 갱신
			break;
		case "onbuttonup":
			MessageManager.clearMessageArea();
			switch(id)
			{
				case "btn_FL_PrintAdd":
					if(this.docListManager.selectedItemIdx > -1)
					{
						var _selectedInfo=this.docListManager.getSelectedDocInfo();
						if(_selectedInfo.success){
							if(WidgetLib.getWidgetStatus("btn_FL_Print").enable){
								WidgetLib.setWidgetStatus("btn_FL_PrintRemove", {enable:true});
							}
							var prtCnt = this.prnCntManager.currentNum + 1;
							if(prtCnt > this.prnCntManager.config.max){
								this.prnCntManager.currentNum = this.prnCntManager.config.max;
								this.prnCntManager.setNum(this.prnCntManager.currentNum);
								BrowserExt.Beep(1);
								return;
							}else{
								this.prnCntManager.setNum(prtCnt);
							}
						}
						else{
							KISUtil.debug("docListManager.getSelectedDocInfo()", _selectedInfo.success);
						}
						this.updateDisplayPrintQuantityCnt(this.docListManager.selectedItemIdx, prtCnt);
						this.docListManager.updateQuantity(this.updateQuantity, true);
					}
					break;
				case "btn_FL_PrintRemove":
					if(this.docListManager.selectedItemIdx > -1)
					{
						var _selectedInfo=this.docListManager.getSelectedDocInfo();
						if(_selectedInfo.success){
							if(!WidgetLib.getWidgetStatus("btn_FL_PrintAdd").enable){
								WidgetLib.setWidgetStatus("btn_FL_PrintAdd", {enable:true});
							}
							var prtCnt = this.prnCntManager.currentNum - 1;
							if(prtCnt == 1){
								WidgetLib.setWidgetStatus("btn_FL_PrintRemove", {enable:false});
							}
							this.prnCntManager.setNum(prtCnt);
						}
						else{
							KISUtil.debug("docListManager.getSelectedDocInfo()", _selectedInfo.success);
						}
						this.updateDisplayPrintQuantityCnt(this.docListManager.selectedItemIdx, prtCnt);
						this.docListManager.updateQuantity(this.updateQuantity, true);
					}
					break;
				case "btn_FL_PrintAll":
					//인쇄매수 변경분 반영
					this.docListManager.updateQuantity(this.updateQuantity, true);
					var _lst = this.docListManager.getCheckedItems();
					if(_lst.length != this.docListManager.getAllCount()){
						BrowserExt.Beep(0);
						//2016.07.06 KIS Chone 남동건설 전체 프린트(전체 프린트 버튼 눌렀을 경우, 전체 선택-> 프린트 처리) 기능 수정 건 Start
						this.docListManager.selectAllItems();
						_lst = this.docListManager.getCheckedItems();
					}

					for(var i = 0;i < _lst.length;i++){
						var _selectedDoc = this.docListManager.getListDocInfo(i);
						if(_selectedDoc.success){
							if(!_selectedDoc.doc.prnType && !_selectedDoc.doc.boxId){
								this.prnCntManager.setNum(_selectedDoc.doc.printCnt);
								var _policy = this._getListPolicy(i);
								if(_policy.success&&_policy.status.msg!=""){
									MessageManager.displayMessage(MessageManager.MessageType.CONFLICT, "", Msg.errorMessage[_policy.status.msg]+Msg.errorMessage["PRINT_CHECK"]);
									this.docListManager.unSelectItems(i);
								}
							}
						}
					}
					this.docListManager.updateQuantity(this.updateQuantity, true);
					var result_lst = this.docListManager.getCheckedItems();
					this.updateDisplay();
					if(this.docListManager.getSelectedCount() == this.docListManager.getAllCount()){
						if (result_lst.length > 0){
                        	Common.doJobStart(result_lst);
                    	}else{
                        	BrowserExt.Beep(1);
                    	}
					}
					break;
				case "btn_FL_Print":
					//인쇄매수 변경분 반영
					this.docListManager.updateQuantity(this.updateQuantity, true);
					//인쇄 가능여부 판단
					var _lst = this.docListManager.getCheckedItems();
					if(_lst.length>0){
						//Run Job
						BrowserExt.Beep(0);
						Common.doJobStart(_lst);
					}
					else{
						BrowserExt.Beep(1);

					}
					break;
				case "btn_FL_Refresh":
					BrowserExt.Beep(0);
					document.getElementById("lyr_FL_Display_Area").className = "loading";
					this.refreshStoredDocument();
					this.docListManager.init();
					break;
				case "btn_FL_pageUp":
					BrowserExt.Beep(0);
					//인쇄매수 변경분 반영
					this.docListManager.updateQuantity(this.updateQuantity, false);
					this.docListManager.goPrevPage();
					break;
				case "btn_FL_pageDown":
					BrowserExt.Beep(0);
					//인쇄매수 변경분 반영
					this.docListManager.updateQuantity(this.updateQuantity, false);
					this.docListManager.goNextPage();
					break;
				case "btn_FL_SelectAll":
					BrowserExt.Beep(0);
					//인쇄매수 변경분 반영
					this.docListManager.updateQuantity(this.updateQuantity, true);
					this.docListManager.selectAllItems();
					WidgetLib.setWidgetStatus("btn_FL_Modi_WmDisable", {enable:true});
					WidgetLib.setWidgetStatus("btn_FL_Modi_WmEnable", {enable:true});
					break;
				case "btn_FL_DeleteFile":
					BrowserExt.Beep(0);
					Common.doDeleteStart();//2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193

					/*var spList = new SSMILib.SelectedPrnInfo4Delete();
					spList.userId = glbInfo.userInfo.userId;
					spList.wsIp = glbConfig.wsIp;
					spList.listSelected = this.docListManager.getSelectedUUIDs();
					SSMILib.DeleteSelectedPrnInfo(spList);*/

					this.docListManager.deleteItems();
					this.docListManager.refresh();
					break;
				case "btn_FL_Modi_PrintSetting":
					BrowserExt.Beep(0);
					//선택항목이 있는경우
					if(this.docListManager.getSelectedCount() == 1)
					{
						//인쇄매수 변경분 반영
						this.docListManager.updateQuantity(this.updateQuantity, true);

						var _selectedInfo=this.docListManager.getSelectedDocInfo();
						if(_selectedInfo.success){
							//풀다운용 인덱스 추가
							this._dataSet.selectedDocInfo = _selectedInfo.doc;
						}
						else{
							KISUtil.debug("docListManager.getSelectedDocInfo()", _selectedInfo.success);
						}
						this.store();
						PageManager.changePage(PrintSettingPopup, PageManager.type.NORMAL);
					} else if(this.docListManager.getSelectedCount() > 1){
                        PageManager.changePage(PrintSettingMultiPopup, PageManager.type.NORMAL);
					}
					break;
				//! Watermark 관련 E1 개별대응
				case "btn_FL_Modi_WmDisable":
					glbWmSelectFunc = false;
					if(this.docListManager.getAllCount() > 0){
						var _lst = this.docListManager.getCheckedList();
						for(var i = 0;i < _lst.length;i++){
							var _selectedDoc = this.docListManager.getListDocInfo(_lst[i]);
							if(_selectedDoc.success){
								if(!_selectedDoc.doc.prnType && !_selectedDoc.doc.boxId){
									_selectedDoc.doc.watermark = false;
								}
							}
						}
						this.updateDisplay();
					}else{
						BrowserExt.Beep(1);
					}
					break;
				case "btn_FL_Modi_WmEnable":
					glbWmSelectFunc = true;
					if(this.docListManager.getAllCount() > 0){
						var _lst = this.docListManager.getCheckedList();
						for(var i = 0;i < _lst.length;i++){
							var _selectedDoc = this.docListManager.getListDocInfo(_lst[i]);
							if(_selectedDoc.success){
								if(!_selectedDoc.doc.prnType && !_selectedDoc.doc.boxId){
									_selectedDoc.doc.watermark = true;
								}
							}
						}
						this.updateDisplay();
					}else{
						BrowserExt.Beep(1);
					}
					break;
				case "btnDocItem0":
				case "btnDocItem1":
				case "btnDocItem2":
				case "btnDocItem3":
				case "btnDocItem4":
					BrowserExt.Beep(0);
					//인쇄매수 변경분 반영
					this.docListManager.updateQuantity(this.updateQuantity, true);
					//getIndex
					var idx = parseInt(id.substring(id.length, id.length - 1));
					this.docListManager.selectItem(idx);
					var _selectedDoc = this.docListManager.getSelectedDocInfo();
					if(_selectedDoc.success){
						if(!_selectedDoc.doc.prnType && !_selectedDoc.doc.boxId){
							this.prnCntManager.setNum(_selectedDoc.doc.printCnt);
							//this.prnCntManager.setEnableFlag(!_selectedDoc.doc.prnType);
							var _policy = this._getCurrentPolicy();
							if(_policy.success&&_policy.status.msg!=""){
								MessageManager.displayMessage(MessageManager.MessageType.CONFLICT, "", Msg.errorMessage[_policy.status.msg]);
								this.prnCntManager.setEnableFlag(_policy.status.printStatus);
							}else{
								if(this.docListManager.getSelectedCount() > 0){
									this.prnCntManager.setEnableFlag(false);
								}else{
									this.prnCntManager.setEnableFlag(true);
								}
							}
						}
					}else{
						this.prnCntManager.setEnableFlag(false);
					}
					break;
				case "btn_num_key0":
				case "btn_num_key1":
				case "btn_num_key2":
				case "btn_num_key3":
				case "btn_num_key4":
				case "btn_num_key5":
				case "btn_num_key6":
				case "btn_num_key7":
				case "btn_num_key8":
				case "btn_num_key9":
					var _num = fn(id);
					var _result = this.prnCntManager.insertNum(_num);
					if(this.docListManager.selectedItemIdx != -1){
						this.updateDisplayPrintQuantityCnt(this.docListManager.selectedItemIdx, this.prnCntManager.currentNum);
					}
					BrowserExt.Beep(_result ? 0 : 1);
					break;
				case "btn_comeback_key":
					var _result = this.prnCntManager.removeNum();
					if(this.docListManager.selectedItemIdx != -1){
						this.updateDisplayPrintQuantityCnt(this.docListManager.selectedItemIdx, this.prnCntManager.currentNum);
					}
					BrowserExt.Beep(_result ? 0 : 1);
					break;
				case "btn_start_key":
					//인쇄매수 변경분 반영
					this.docListManager.updateQuantity(this.updateQuantity, true);
					//인쇄 가능여부 판단
					var _lst = this.docListManager.getCheckedItems();
					if(_lst.length>0){
						//Run Job
						BrowserExt.Beep(0);
						Common.doJobStart(_lst);
					}
					else{
						BrowserExt.Beep(1);

					}
					break;
				case "btn_menu_key":
					//リセットキー
					BrowserExt.Beep(0);
					//window.location.reload(true);
					// Mantis No: 0000018
					BrowserExt.SetScreenChange("allservice");
					break;
				case "btn_auth_key":
					if(glbInfo.userInfo){
						SSMILib.LogoutDev();
					}
					break;
				default:
					BrowserExt.Beep(0);
					break;
			}
			break;
		case "onhardkeydown":
			MessageManager.clearMessageArea();
			switch(id)
			{
				case BrowserExt.keyCode.FX_VK_0:
				case BrowserExt.keyCode.FX_VK_1:
				case BrowserExt.keyCode.FX_VK_2:
				case BrowserExt.keyCode.FX_VK_3:
				case BrowserExt.keyCode.FX_VK_4:
				case BrowserExt.keyCode.FX_VK_5:
				case BrowserExt.keyCode.FX_VK_6:
				case BrowserExt.keyCode.FX_VK_7:
				case BrowserExt.keyCode.FX_VK_8:
				case BrowserExt.keyCode.FX_VK_9:
					var _num = id-BrowserExt.keyCode.FX_VK_0;
					if(this.docListManager.getSelectedCount() === 1){
						var _result = this.prnCntManager.insertNum(_num);
						if(this.docListManager.selectedItemIdx != -1){
							this.updateDisplayPrintQuantityCnt(this.docListManager.selectedItemIdx, this.prnCntManager.currentNum);
						}
						BrowserExt.Beep(_result ? 0 : 1);
					}else{
						BrowserExt.Beep(1);
					}

					break;
				//case BrowserExt.keyCode.FX_VK_MULTIPLY://*
				//case BrowserExt.keyCode.FX_VK_NUMBER://#
				case BrowserExt.keyCode.FX_VK_BACK_SPACE:
					var _result = this.prnCntManager.removeNum();
					if(this.docListManager.selectedItemIdx != -1){
						this.updateDisplayPrintQuantityCnt(this.docListManager.selectedItemIdx, this.prnCntManager.currentNum);
					}
					BrowserExt.Beep(_result ? 0 : 1);
					break;
				case BrowserExt.keyCode.FX_VK_START:
					if(WebServiceLib.getActiveRequestCount() != 0){
						BrowserExt.Beep(1);
						KISUtil.debug("[job return]","getActiveRequestCount()=" + WebServiceLib.getActiveRequestCount());
						return;
					}
					//인쇄매수 변경분 반영
					this.docListManager.updateQuantity(this.updateQuantity, true);
					//인쇄 가능여부 판단
					var _lst = this.docListManager.getCheckedItems();
					if(_lst.length>0){
						//프린트버튼의 상태가 disable일때는 인쇄하지 않도록 처리
						if(!WidgetLib.getWidgetStatus("btn_FL_Print").enable){//FileListPage.prnCntManager.getEnableFlag()
							BrowserExt.Beep(1);
						}
						else{
							//Run Job
							BrowserExt.Beep(0);
							Common.doJobStart(_lst);
						}
					}
					else{
						BrowserExt.Beep(1);
					}
					break;
				case BrowserExt.keyCode.FX_VK_CLEAR:
					//リセットキー
					BrowserExt.Beep(0);
					//window.location.reload(true);
					// Mantis No: 0000018
					BrowserExt.SetScreenChange("allservice");
					break;
				case BrowserExt.keyCode.FX_VK_PAUSE:
					break;
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		default:
			break;
	}
};

FileListPage.getSelectedListByLength = function(cnt){
	var _selectedList = [];
	for(var i = 0; i < cnt; i++){
		_selectedList[i] = i;
	}
	return _selectedList;
};

FileListPage.getSelectedListByUseYnFlag = function()//2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193
{
	var _selectedList = [];
	var idx = 0;
	for(var i = 0; i < glbDataSet.docList.length; i++){
		if(glbDataSet.docList[i].useYn == false){
			_selectedList[idx++] = i;
		}
	}
	return _selectedList;
};

/**
 * 화면하단? 리스트내? 인쇄매수 표시갱신 및 입력 Flag변경
 */
FileListPage.updateQuantity = function(_target, _flg){
	_target.printCnt = FileListPage.prnCntManager.currentNum;
	//페이지 전환 이외의 조작의경우
	//페이지 전환이후에도 이어지는 입력이 가능하도록 Flag를 초기화 하지 않음
	if(_flg){
		FileListPage.prnCntManager.insertFlg = false;
	}
};
/**
 * 파일리스트페이지용 HTML구성
 */
FileListPage._createHtml = function()
{
	createFileListPageHtml();
};

/**
 * 선택된 파일 개수 표시갱신
 */
FileListPage.updateDisplaySelectedFileCount = function(){
	var seleted = this.getSelectedCount();
	var allCount = "/" + this.getAllCount();
	Common.setText("txt_FL_SelectedFile", seleted);
	Common.setText("txt_FL_AllCountFile", allCount);
}

/**
 * 현재 페이지 표시갱신
 */
FileListPage.updateDisplayCurrentPage=function(){
	if(this.getTotalPages()>0){
		var totalPage = "/" + this.getTotalPages();
		Common.setText("txt_FL_CurrentPage", this.currentPageIdx);
		Common.setText("txt_FL_TotalPage", totalPage)
	}
	else{
		Common.setText("txt_FL_CurrentPage","");
		Common.setText("txt_FL_TotalPage", "")
	}
}
/**
 * 인쇄매수 표시갱신
 */
FileListPage.updateDisplayPrintQuantity = function(num){
	Common.setText("txt_FL_PrintQuantity",num);
}

FileListPage.updateDisplayPrintQuantityCnt = function(idx ,num){
	Common.setText("lblDocItemQat"+idx, num + Msg.UNIT.PRN_SET);
}

/**
 * 표시 갱신 버튼, 표시문서 종류별 풀다운 동작 처리
 */
FileListPage.refreshStoredDocument = function()//2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193
{
	// FD Mode 일 경우 EWB에서 일부 변수의 초기화 안되는 현상이 발생하여 추가함.
	this.docListManager.clearDataSouce();//기존 데이터 삭제
	this.docListManager.dataSource = [];
	this.docListManager.currentPageIdx = 1;
	this.docListManager.maxPageIdx = 1;
	this.docListManager.selectedItemIdx = -1;
	this.docListManager.checkedList = [];
	this.docListManager.totalSpendPageCount = 0;
	if(glbDataSet.docList){
		glbDataSet.docList = [];
	}
	if(glbDbmEnable){
		glbDbm.getDocList();
	}else{
		FileListPage.getServerStoredDocument();
	}
};

//2017.01 FXKIS Chone 개인프린트 리스트를 즉시출력, 선택출력 기능에 포함 refs #4193
FileListPage.getServerStoredDocument = function()
{
	//SmartUI 2017.02 복수의 Print Server 대응 refs #4184
	for(var i = 0;glbConfig.DATA.SERVER_URL.length > i;i++){
		if(glbConfig.DATA.SERVER_URL[i] != "Re-enter"){
			var plpObj = new SSMILib.PrnListPolicy();
			plpObj.userId = glbInfo.userInfo.RelatedUserID;
			plpObj.deviceIp = glbInfo.ipAddress;
			plpObj.wsIp = glbConfig.wsIp[i];
			SSMILib.GetPrnListPolicy(plpObj, DOC_PRINT_TIMEOUT, glbConfig.DATA.SERVER_URL[i]);
		}
	}
};

/**
 * 문서 리스트 화면의 총 페이지수 취득
 * @return 총 페이지수
 */
FileListPage.getFileListTotalPage = function(){
	//console.log("getFileListTotalPage");
	return Math.ceil(glbDevInfo.docList.length/MAX_FILE_BTN_NUM);
};

/**
 * 문서 선택 버튼의 표시 내용의 Clear
 * @param num : Button ID
 */
FileListPage.clearFileButton=function(id)
{
	//console.log("displayPrintAllButton");
	Common.setText(id + "_name", "");
	Common.setText(id + "_date", "");
	Common.setText(id + "_time", "");
	Common.setText(id + "_page", "");
	Common.setText(id + "_quantity", "");
	Common.setText(id + "_color", "");
	Common.setText(id + "_plex", "");
	Common.setText(id + "_nup", "");
	Common.setText(id + "_finisher", "");
};
/**
 * 정보 취득중 화면시에 선택 문서수의 표시 처리
 */
FileListPage.displayFileSelectedNumLoading=function()
{
	//console.log("displayFileSelectedNumLoading");
	//[선택수：0] → [선택수：]로 변경대응
	//var msg = Msg.FILELIST.SELECTED_FILE_NUMBER_MSG + "";
	Common.setText("txt_FL_SelectedFile", "0");
};
