/**
 * Title Area의 HTML Tag생성
 */
function createTitleAreaHtml()
{
	var body =document.body;

	var titleArea = document.createElement("div");
	titleArea.setAttribute("id", "title_area");

	var titleAreaChild = document.createElement("img");
	titleAreaChild.setAttribute("id", "img_Title");
	titleArea.appendChild(titleAreaChild);

	titleAreaChild = document.createElement("img");
	titleAreaChild.setAttribute("id", "icn_UserIcon");
	titleArea.appendChild(titleAreaChild);

	titleAreaChild = document.createElement("div");
	titleAreaChild.setAttribute("id", "txt_UserName");
	titleArea.appendChild(titleAreaChild);

	body.appendChild(titleArea);
}

/**
 * File List 화면의 HTML Tag생성
 */
function createFileListPageHtml()
{
	var body =document.body;

	var fileListPag = document.createElement("div");
	fileListPag.setAttribute("id", "page_FileList");
	//fileListPag.setAttribute("style", "z-index : -1");
	fileListPag.setAttribute("class", "page");
	var _img = document.createElement("img");
	_img.setAttribute("id", "img_FL_bg");
	fileListPag.appendChild(_img);
	body.appendChild(fileListPag);

	//Message표시 영역
	var flMsgArea = document.createElement("div");
	flMsgArea.setAttribute("id", "lyr_FL_Msg_Area");
	var flMsgAreaChild = document.createElement("div");
	flMsgAreaChild.setAttribute("id", "txt_FL_Msg0");
	flMsgArea.appendChild(flMsgAreaChild);
	flMsgAreaChild = document.createElement("div");
	flMsgAreaChild.setAttribute("id", "txt_FL_Msg1");
	flMsgArea.appendChild(flMsgAreaChild);
	fileListPag.appendChild(flMsgArea);

	flPrintAll = document.createElement("div");
	flPrintAll.setAttribute("id", "btn_FL_PrintAll");
	var _img = document.createElement("img");					//버튼 이미지
	_img.setAttribute("id", "img_FL_PrintAll");
	_img.setAttribute("class", "img");
	flPrintAll.appendChild(_img);
	var _lbl = document.createElement("div");					//버튼라벨
	_lbl.setAttribute("id", "lbl_FL_PrintAll");
	_lbl.setAttribute("class", "lbl");
	flPrintAll.appendChild(_lbl);
	fileListPag.appendChild(flPrintAll);

	var flSelectdWrp = document.createElement("div");
	flSelectdWrp.setAttribute("id", "lyr_FL_SelectedFile");
	
	var flSelectdLbl = document.createElement("div");
	flSelectdLbl.setAttribute("id", "lbl_FL_SelectedFile");
	flSelectdWrp.appendChild(flSelectdLbl);

	var flSelectdTxt = document.createElement("div");
	flSelectdTxt.setAttribute("id", "txt_FL_SelectedFile");
	flSelectdWrp.appendChild(flSelectdTxt);

	var flAllCountTxt = document.createElement("div");
	flAllCountTxt.setAttribute("id", "txt_FL_AllCountFile");
	flSelectdWrp.appendChild(flAllCountTxt);

	fileListPag.appendChild(flSelectdWrp);

	var flBtnRefresh = document.createElement("div");
	flBtnRefresh.setAttribute("id", "btn_FL_Refresh");
	flBtnRefresh.setAttribute("class", "btn");
	var flBtnRefreshChild = document.createElement("img");
	flBtnRefreshChild.setAttribute("id", "img_FL_Refresh");
	flBtnRefresh.appendChild(flBtnRefreshChild);
	flBtnRefreshChild = document.createElement("div");
	// flBtnRefreshChild.setAttribute("id", "lbl_FL_Refresh");
	// flBtnRefreshChild.setAttribute("class", "lbl");
	flBtnRefresh.appendChild(flBtnRefreshChild);
	fileListPag.appendChild(flBtnRefresh);

	var flDisplayArea = document.createElement("div");
	flDisplayArea.setAttribute("id", "lyr_FL_Display_Area");
	flDisplayArea.setAttribute("class", "loading");
	fileListPag.appendChild(flDisplayArea);
	
	var _img = document.createElement("img");
	_img.setAttribute("id", "img_FL_NotifyImg");
	_img.setAttribute("class", "txt_FL_NotifyMsg");
	flDisplayArea.appendChild(_img);

	//Loading Message
	for(var i=0; i<5; i++){
		var flNotifyMsg = document.createElement("div");
		flNotifyMsg.setAttribute("id", "txt_FL_NotifyMsg" + i);
		flNotifyMsg.setAttribute("class", "txt_FL_NotifyMsg");
		flDisplayArea.appendChild(flNotifyMsg);
	}

	var flPage =  document.createElement("img");
	flPage.setAttribute("id", "btn_FL_pageUp");
	fileListPag.appendChild(flPage);
	flPage =  document.createElement("div");
	flPage.setAttribute("id", "txt_FL_CurrentPage");
	fileListPag.appendChild(flPage);
	flPage =  document.createElement("div");
	flPage.setAttribute("id", "txt_FL_TotalPage");
	fileListPag.appendChild(flPage);
	flPage =  document.createElement("img");
	flPage.setAttribute("id", "btn_FL_pageDown");
	fileListPag.appendChild(flPage);

	var flSelecAll = document.createElement("div");
	flSelecAll.setAttribute("id", "btn_FL_SelectAll");
	flSelecAll.setAttribute("class", "btn");
	var flSelecAllChild = document.createElement("img");
	flSelecAllChild.setAttribute("id", "img_FL_SelectAll");
	flSelecAll.appendChild(flSelecAllChild);
	flSelecAllChild = document.createElement("img");
	flSelecAllChild.setAttribute("id", "img_FL_SelectAllIcon");
	flSelecAll.appendChild(flSelecAllChild);
	flSelecAllChild = document.createElement("div");
	flSelecAllChild.setAttribute("id", "lbl_FL_SelectAll0");
	flSelecAllChild.setAttribute("class", "lbl");
	flSelecAll.appendChild(flSelecAllChild);
	flSelecAllChild = document.createElement("div");
	flSelecAllChild.setAttribute("id", "lbl_FL_SelectAll1");
	flSelecAllChild.setAttribute("class", "lbl");
	flSelecAll.appendChild(flSelecAllChild);
	fileListPag.appendChild(flSelecAll);

	var flDelete = document.createElement("div");
	flDelete.setAttribute("id", "btn_FL_DeleteFile");
	flDelete.setAttribute("class", "btn");
	var flDeleteChild = document.createElement("img");
	flDeleteChild.setAttribute("id", "img_FL_DeleteFile");
	flDelete.appendChild(flDeleteChild);
	flDeleteChild = document.createElement("img");
	flDeleteChild.setAttribute("id", "img_FL_DeleteIcon");
	flDelete.appendChild(flDeleteChild);
	flDeleteChild = document.createElement("div");
	flDeleteChild.setAttribute("id", "lbl_FL_DeleteFile");
	flDeleteChild.setAttribute("class", "lbl");
	flDelete.appendChild(flDeleteChild);
	fileListPag.appendChild(flDelete);

	var flPrintAdd = document.createElement("div");
	flPrintAdd.setAttribute("id", "btn_FL_PrintAdd");
	flPrintAdd.setAttribute("class", "btn");
	var flPrintAddChild = document.createElement("img");
	flPrintAddChild.setAttribute("id", "img_FL_PrintAdd");
	flPrintAdd.appendChild(flPrintAddChild);
	fileListPag.appendChild(flPrintAdd);

	var flPrintRemove = document.createElement("div");
	flPrintRemove.setAttribute("id", "btn_FL_PrintRemove");
	flPrintRemove.setAttribute("class", "btn");
	var flPrintRemoveChild = document.createElement("img");
	flPrintRemoveChild.setAttribute("id", "img_FL_PrintRemove");
	flPrintRemove.appendChild(flPrintRemoveChild);
	fileListPag.appendChild(flPrintRemove);

	var flPrintQuantityWrapper = document.createElement("div");
	flPrintQuantityWrapper.setAttribute("id", "lyr_FL_PrintQuantity");
	flPrintQuantity = document.createElement("div");
	flPrintQuantity.setAttribute("id", "txt_FL_PrintQuantity");
	flPrintQuantityWrapper.appendChild(flPrintQuantity);
	flPrintQuantity = document.createElement("div");
	flPrintQuantity.setAttribute("id", "lbl_FL_PrintQuantity");
	flPrintQuantityWrapper.appendChild(flPrintQuantity);
	fileListPag.appendChild(flPrintQuantityWrapper);
	
	var flPrintSetting = document.createElement("div");
	flPrintSetting.setAttribute("id", "btn_FL_Modi_PrintSetting");
	flPrintSetting.setAttribute("class", "btn");
	var flPrintSettingChild = document.createElement("img");
	flPrintSettingChild.setAttribute("id", "img_FL_Modi_PrintSetting");
	flPrintSetting.appendChild(flPrintSettingChild);
	flPrintSettingChild = document.createElement("img");
	flPrintSettingChild.setAttribute("id", "img_FL_Modi_PrintSettingIcon");
	flPrintSetting.appendChild(flPrintSettingChild);
	flPrintSettingChild = document.createElement("div");
	flPrintSettingChild.setAttribute("id", "lbl_FL_Modi_PrintSetting0");
	flPrintSettingChild.setAttribute("class", "lbl");
	flPrintSetting.appendChild(flPrintSettingChild);
	flPrintSettingChild = document.createElement("div");
	flPrintSettingChild.setAttribute("id", "lbl_FL_Modi_PrintSetting1");
	flPrintSettingChild.setAttribute("class", "lbl");
	flPrintSetting.appendChild(flPrintSettingChild);
	fileListPag.appendChild(flPrintSetting);

	// Watermark Disable버튼
	var flWmDisable = document.createElement("div");
	flWmDisable.setAttribute("id", "btn_FL_Modi_WmDisable");
	flWmDisable.setAttribute("class", "btn");
	var flWmDisableChild = document.createElement("img");
	flWmDisableChild.setAttribute("id", "img_FL_Modi_WmDisable");
	flWmDisable.appendChild(flWmDisableChild);
	flWmDisableChild = document.createElement("div");
	flWmDisableChild.setAttribute("id", "lbl_FL_Modi_WmDisable0");
	flWmDisableChild.setAttribute("class", "lbl");
	flWmDisable.appendChild(flWmDisableChild);
	flWmDisableChild = document.createElement("div");
	flWmDisableChild.setAttribute("id", "lbl_FL_Modi_WmDisable1");
	flWmDisableChild.setAttribute("class", "lbl");
	flWmDisable.appendChild(flWmDisableChild);
	fileListPag.appendChild(flWmDisable);
	// Watermark Enable버튼
	var flWmEnable = document.createElement("div");
	flWmEnable.setAttribute("id", "btn_FL_Modi_WmEnable");
	flWmEnable.setAttribute("class", "btn");
	var flWmEnableChild = document.createElement("img");
	flWmEnableChild.setAttribute("id", "img_FL_Modi_WmEnable");
	flWmEnable.appendChild(flWmEnableChild);
	flWmEnableChild = document.createElement("div");
	flWmEnableChild.setAttribute("id", "lbl_FL_Modi_WmEnable0");
	flWmEnableChild.setAttribute("class", "lbl");
	flWmEnable.appendChild(flWmEnableChild);
	flWmEnableChild = document.createElement("div");
	flWmEnableChild.setAttribute("id", "lbl_FL_Modi_WmEnable1");
	flWmEnableChild.setAttribute("class", "lbl");
	flWmEnable.appendChild(flWmEnableChild);
	fileListPag.appendChild(flWmEnable);

	var flPrint = document.createElement("div");
	flPrint.setAttribute("id", "btn_FL_Print");
	var _img = document.createElement("img");					//버튼 이미지
	_img.setAttribute("id", "img_FL_Print");
	_img.setAttribute("class", "img");
	flPrint.appendChild(_img);
	_img = document.createElement("img");
	_img.setAttribute("id", "img_FL_PrintIcon");
	flPrint.appendChild(_img);
	var _lbl = document.createElement("div");					//버튼라벨
	_lbl.setAttribute("id", "lbl_FL_Print");
	_lbl.setAttribute("class", "lbl");
	flPrint.appendChild(_lbl);
	fileListPag.appendChild(flPrint);
}
/**
 * 黄 에러 팝업의 HTML Tag생성
 */
function createAlertPopupHtml()
{
	var body =document.body;

	var alertPopup = document.createElement("div");
	alertPopup.setAttribute("id", "pag_Alert_Popup");
	alertPopup.setAttribute("class", "page");

	body.appendChild(alertPopup);

	var alertPopupChild = document.createElement("img");
	alertPopupChild.setAttribute("id", "img_AP_Background");
	alertPopup.appendChild(alertPopupChild);

	alertPopupChild = document.createElement("div");
	alertPopupChild.setAttribute("id", "txt_AP_Title");
	alertPopup.appendChild(alertPopupChild);

	alertPopupChild = document.createElement("div");
	alertPopupChild.setAttribute("id", "btn_AP_Close");
	var child = document.createElement("img");
	child.setAttribute("id", "img_AP_Close");
	alertPopupChild.appendChild(child);
	child = document.createElement("div");
	child.setAttribute("id", "lbl_AP_Close");
	alertPopupChild.appendChild(child);
	alertPopup.appendChild(alertPopupChild);

	for(var i=0; i<8; i++){
		alertPopupChild = document.createElement("div");
		alertPopupChild.setAttribute("id", "txt_AP_Msg" + i);
		alertPopup.appendChild(alertPopupChild);
	}

	alertPopupChild = document.createElement("div");
	alertPopupChild.setAttribute("id", "txt_AP_ContentsId");
	alertPopup.appendChild(alertPopupChild);
}

/**
 * 赤 에러 팝업의 HTML Tag생성
 */
function createCriticalPopupHtml()
{
	var criticalPopup = document.createElement("div");
	criticalPopup.setAttribute("id", "pag_Critical_Error_Popup");
	criticalPopup.setAttribute("class", "page");

	body.appendChild(criticalPopup);

	var criticalPopupChild = document.createElement("img");
	criticalPopupChild.setAttribute("id", "img_CEP_Bagkground");
	criticalPopup.appendChild(criticalPopupChild);

	criticalPopupChild = document.createElement("div");
	criticalPopupChild.setAttribute("id", "txt_CEP_Title");
	criticalPopup.appendChild(criticalPopupChild);

	for(var i=0; i<12; i++){
		criticalPopupChild = document.createElement("div");
		criticalPopupChild.setAttribute("id", "txt_CEP_Msg" + i);
		criticalPopup.appendChild(criticalPopupChild);
	}

	criticalPopupChild = document.createElement("div");
	criticalPopupChild.setAttribute("id", "txt_CEP_ContentsId");
	criticalPopup.appendChild(criticalPopupChild);

	criticalPopupChild = document.createElement("div");
	criticalPopupChild.setAttribute("id", "btn_CEP_Close");
	var child = document.createElement("img");
	child.setAttribute("id", "img_CEP_Close");
	criticalPopupChild.appendChild(child);
	child = document.createElement("div");
	child.setAttribute("id", "lbl_CEP_Close");
	criticalPopupChild.appendChild(child);
	criticalPopup.appendChild(criticalPopupChild);
}

/**
 * File 설정 화면의 HTML Tag생성
 */
function createFileSettingPageHtml()
{
	var body =document.body;

	var pagMPSetting = document.createElement("div");
	pagMPSetting.setAttribute("id", "pag_Modi_Print_Setting");
	pagMPSetting.setAttribute("class", "page");

	body.appendChild(pagMPSetting);

	var pagMPSettingChild = document.createElement("img");
	pagMPSettingChild.setAttribute("id", "img_MPS_Background");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("img");
	pagMPSettingChild.setAttribute("id", "icn_MPS_Title");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "txt_MPS_Title");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "btn_MPS_Cancel");
	var child = document.createElement("img");
	child.setAttribute("id", "img_MPS_Cancel");
	pagMPSettingChild.appendChild(child);
	child = document.createElement("div");
	child.setAttribute("id", "lbl_MPS_Cancel");
	pagMPSettingChild.appendChild(child);
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "lbl_MPS_JobName");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "txt_MPS_JobName0");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "txt_MPS_JobName1");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "lbl_MPS_Job_ReceivedTime");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "txt_MPS_Job_ReceivedTime");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "lbl_MPS_ColorMode");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "pul_MPS_ColorMode");
	child = document.createElement("img");
	child.setAttribute("id", "img_MPS_ColorMode");
	pagMPSettingChild.appendChild(child);
	child = document.createElement("div");
	child.setAttribute("id", "txt_MPS_ColorMode");
	pagMPSettingChild.appendChild(child);
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("img");
	pagMPSettingChild.setAttribute("id", "icn_MPS_ColorMode_Un");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "txt_MPS_ColorMode_Un");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "lbl_MPS_Total_Pages");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "txt_MPS_Total_Pages");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "lbl_MPS_Plex");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "pul_MPS_Plex");
	child = document.createElement("img");
	child.setAttribute("id", "img_MPS_Plex");
	pagMPSettingChild.appendChild(child);
	child = document.createElement("div");
	child.setAttribute("id", "txt_MPS_Plex");
	pagMPSettingChild.appendChild(child);
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("img");
	pagMPSettingChild.setAttribute("id", "icn_MPS_Plex_Un");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "txt_MPS_Plex_Un");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "lbl_MPS_PrintQuantity");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("img");
	pagMPSettingChild.setAttribute("id", "img_MPS_PrintQuantity");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "txt_MPS_PrintQuantity");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "lbl_MPS_PrintQuantity_Unit");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "lbl_MPS_Nup");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("img");
	pagMPSettingChild.setAttribute("id", "icn_MPS_Nup");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "txt_MPS_Nup");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "lbl_MPS_Staple");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "txt_MPS_Staple");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "lbl_MPS_Punch");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "txt_MPS_Punch");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("img");
	pagMPSettingChild.setAttribute("id", "img_MPS_Info_Display_Area");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("img");
	pagMPSettingChild.setAttribute("id", "icn_MPS_InfoType");
	pagMPSetting.appendChild(pagMPSettingChild);

	for(var i=0; i<3; i++){
		pagMPSettingChild = document.createElement("div");
		pagMPSettingChild.setAttribute("id", "txt_MPS_Msg" + i);
		pagMPSetting.appendChild(pagMPSettingChild);

	}

	pagMPSettingChild = document.createElement("img");
	pagMPSettingChild.setAttribute("id", "btn_MPS_pageUp");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("img");
	pagMPSettingChild.setAttribute("id", "btn_MPS_pageDown");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("img");
	pagMPSettingChild.setAttribute("id", "btn_MPS_Print");
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "pul_MPS_ColorMode_Popup");
	for(var i=0; i<2; i++){
		child = document.createElement("div");
		child.setAttribute("id", "pul_menu_colorMode_" + i);
		var subChild = document.createElement("img");
		subChild.setAttribute("id", "img_pull_menu_colorMode_" + i);
		child.appendChild(subChild);
		subChild = document.createElement("div");
		subChild.setAttribute("id", "txt_pull_menu_colorMode_" + i);
		child.appendChild(subChild);
		pagMPSettingChild.appendChild(child);
	}
	pagMPSetting.appendChild(pagMPSettingChild);

	pagMPSettingChild = document.createElement("div");
	pagMPSettingChild.setAttribute("id", "pul_MPS_Plex_Popup");
	for(var i=0; i<3; i++){
		child = document.createElement("div");
		child.setAttribute("id", "pul_menu_plex_" + i);
		var subChild = document.createElement("img");
		subChild.setAttribute("id", "img_pul_menu_plex_" + i);
		child.appendChild(subChild);
		subChild = document.createElement("div");
		subChild.setAttribute("id", "txt_pul_menu_plex_" + i);
		child.appendChild(subChild);
		pagMPSettingChild.appendChild(child);
	}
	pagMPSetting.appendChild(pagMPSettingChild);

}
/**
 * 프린트 지시중 Popup/프린트 지시완료 Popup의 HTML Tag생성
 */
function createJobExcecutionPageHtml()
{
	var body =document.body;

	var pagJobExe = document.createElement("div");
	pagJobExe.setAttribute("id", "pag_JobExecution_Popup");
	pagJobExe.setAttribute("class", "page");

	body.appendChild(pagJobExe);

	var pagJobExeChild = document.createElement("img");
	pagJobExeChild.setAttribute("id", "img_JE_Background");
	pagJobExe.appendChild(pagJobExeChild);

	pagJobExeChild = document.createElement("div");
	pagJobExeChild.setAttribute("id", "txt_JE_Title");
	pagJobExe.appendChild(pagJobExeChild);

	for(var i=0; i<2; i++){
		pagJobExeChild = document.createElement("div");
		pagJobExeChild.setAttribute("id", "txt_JE_Info_Msg" + i);
		pagJobExe.appendChild(pagJobExeChild);
	}

	pagJobExeChild = document.createElement("img");
	pagJobExeChild.setAttribute("id", "img_JE_Indicator");
	pagJobExe.appendChild(pagJobExeChild);

	for(var i=0; i<5; i++){
		pagJobExeChild = document.createElement("div");
		pagJobExeChild.setAttribute("id", "txt_JE_Alert_Msg" + i);
		pagJobExe.appendChild(pagJobExeChild);
	}

	pagJobExeChild = document.createElement("div");
	pagJobExeChild.setAttribute("id", "btn_JE_Close");
	var child = document.createElement("img");
	child.setAttribute("id", "img_JE_Close");
	pagJobExeChild.appendChild(child);
	child = document.createElement("div");
	child.setAttribute("id", "lbl_JE_Close");
	pagJobExeChild.appendChild(child);
	pagJobExe.appendChild(pagJobExeChild);
}
/**
 * /삭제 확인 화면의 HTML Tag생성
 */
function createFileDelPageHtml()
{
	var body =document.body;

	var pagFileDel = document.createElement("div");
	pagFileDel.setAttribute("id", "pag_File_Delete_Popup");
	pagFileDel.setAttribute("class", "page");

	body.appendChild(pagFileDel);

	var pagFileDelChild = document.createElement("img");
	pagFileDelChild.setAttribute("id", "img_FDP_Background");
	pagFileDel.appendChild(pagFileDelChild);

	pagFileDelChild = document.createElement("div");
	pagFileDelChild.setAttribute("id", "txt_FDP_Title");
	pagFileDel.appendChild(pagFileDelChild);

	for(var i=0; i<8; i++){
		pagFileDelChild = document.createElement("div");
		pagFileDelChild.setAttribute("id", "txt_FDP_Msg" + i);
		pagFileDel.appendChild(pagFileDelChild);
	}

	pagFileDelChild = document.createElement("div");
	pagFileDelChild.setAttribute("id", "btn_FDP_Yes");
	var child = document.createElement("img");
	child.setAttribute("id", "img_FDP_Yes");
	pagFileDelChild.appendChild(child);
	for(var i=0; i<2; i++){
		child = document.createElement("div");
		child.setAttribute("id", "lbl_FDP_Yes" + i);
		pagFileDelChild.appendChild(child);
	}
	pagFileDel.appendChild(pagFileDelChild);

	pagFileDelChild = document.createElement("div");
	pagFileDelChild.setAttribute("id", "btn_FDP_No");
	var child = document.createElement("img");
	child.setAttribute("id", "img_FDP_No");
	pagFileDelChild.appendChild(child);
	for(var i=0; i<2; i++){
		child = document.createElement("div");
		child.setAttribute("id", "lbl_FDP_No" + i);
		pagFileDelChild.appendChild(child);
	}
	pagFileDel.appendChild(pagFileDelChild);
}
/**
 * /삭제중 화면의 HTML Tag생성
 */
function createFileDelIngPageHtml()
{
	var body =document.body;

	var pagFileDelIng = document.createElement("div");
	pagFileDelIng.setAttribute("id", "pag_File_Delete_Ing_Popup");
	pagFileDelIng.setAttribute("class", "page");

	body.appendChild(pagFileDelIng);

	var pagFileDelIngChild = document.createElement("img");
	pagFileDelIngChild.setAttribute("id", "img_FDI_Background");
	pagFileDelIng.appendChild(pagFileDelIngChild);

	pagFileDelIngChild = document.createElement("div");
	pagFileDelIngChild.setAttribute("id", "txt_FDI_Title");
	pagFileDelIng.appendChild(pagFileDelIngChild);

	pagFileDelIngChild = document.createElement("div");
	pagFileDelIngChild.setAttribute("id", "txt_FDI_Info_MSG");
	pagFileDelIng.appendChild(pagFileDelIngChild);

	pagFileDelIngChild = document.createElement("img");
	pagFileDelIngChild.setAttribute("id", "img_FDI_Indicator");
	pagFileDelIng.appendChild(pagFileDelIngChild);
}
/**
 * /설정변경화면의 HTML Tag생성
 */

function createKoMainPageHtml()
{
	var body =document.body;

	var pagKoSetting = document.createElement("div");
	pagKoSetting.setAttribute("id", "pag_KO_Main_Popup");
	pagKoSetting.setAttribute("class", "page");

	body.appendChild(pagKoSetting);

	var pagKoSettingChild = document.createElement("img");
	pagKoSettingChild.setAttribute("id", "img_KO_Background");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("div");
	pagKoSettingChild.setAttribute("id", "lbl_KMP_title");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("input");
	pagKoSettingChild.setAttribute("type", "button");
	pagKoSettingChild.setAttribute("id", "btn_KMP_close");
	pagKoSettingChild.setAttribute("value",  glbTexts["KO_CLOSE_BTN"]);
	pagKoSettingChild.setAttribute("onClick", "onKoMainPage('onbuttonup', 'btn_KMP_close')");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("input");
	pagKoSettingChild.setAttribute("type", "button");
	pagKoSettingChild.setAttribute("id", "btn_KMP_setting");
	pagKoSettingChild.setAttribute("value",  glbTexts["KO_CHANGE_SETTING_TITLE"]);
	pagKoSettingChild.setAttribute("onClick", "onKoMainPage('onbuttonup', 'btn_KMP_setting')");
	pagKoSetting.appendChild(pagKoSettingChild)

	pagKoSettingChild = document.createElement("input");
	pagKoSettingChild.setAttribute("type", "button");
	pagKoSettingChild.setAttribute("id", "btn_KMP_regist_device");
	pagKoSettingChild.setAttribute("value",  glbTexts["KO_REGIST_DEVICES"]);
	pagKoSettingChild.setAttribute("onClick", "onKoMainPage('onbuttonup', 'btn_KMP_regist_device')");
	pagKoSetting.appendChild(pagKoSettingChild)
}

function createKoSettingPopupHtml()
{
	var body =document.body;

	var pagKoSetting = document.createElement("div");
	pagKoSetting.setAttribute("id", "pag_KO_Setting_Popup");
	pagKoSetting.setAttribute("class", "page");

	body.appendChild(pagKoSetting);

	var pagKoSettingChild = document.createElement("img");
	pagKoSettingChild.setAttribute("id", "img_KO_Setting_Background");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("div");
	pagKoSettingChild.setAttribute("id", "lbl_KSP_title");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("input");
	pagKoSettingChild.setAttribute("type", "button");
	pagKoSettingChild.setAttribute("id", "btn_KSP_cancel");
	pagKoSettingChild.setAttribute("value", glbTexts["KO_CHANGE_SETTING_CANCEL_BTN_LABEL"]);
	pagKoSettingChild.setAttribute("onClick", "onKoSettingPopup('onbuttonup', 'btn_KSP_cancel')");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("input");
	pagKoSettingChild.setAttribute("type", "button");
	pagKoSettingChild.setAttribute("id", "btn_KSP_confirm");
	pagKoSettingChild.setAttribute("value", glbTexts["KO_CHANGE_SETTING_CONFIRM_BTN_LABEL"]);
	pagKoSettingChild.setAttribute("onClick", "onKoSettingPopup('onbuttonup', 'btn_KSP_confirm')");
	pagKoSetting.appendChild(pagKoSettingChild)

	pagKoSettingChild = document.createElement("div");
	pagKoSettingChild.setAttribute("id", "lbl_KSP_Access_Timeout");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("div");
	pagKoSettingChild.setAttribute("id", "btn_KSP_Access_Timeout");
	var child = document.createElement("img");
	child.setAttribute("id", "img_KSP_Access_Timeout");
	pagKoSettingChild.appendChild(child);
	child = document.createElement("div");
	child.setAttribute("id", "txt_KSP_Access_Timeout");
	pagKoSettingChild.appendChild(child);
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("div");
	pagKoSettingChild.setAttribute("id", "lbl_KSP_Access_Timeout_Range");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("div");
	pagKoSettingChild.setAttribute("id", "lbl_KSP_Show_File_List");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("select");
	pagKoSettingChild.setAttribute("id", "pul_KSP_Show_File_List");
	pagKoSettingChild.setAttribute("onClick", "onKoSettingPopup('onbuttonup', 'pul_KSP_Show_File_List')");
	var child = document.createElement("option");
	child.setAttribute("id", "pul_KSP_Show_File_List_Option0");
	child.setAttribute("value", "0");
	child.appendChild(document.createTextNode(glbTexts["KO_CHANGE_SETTING_FILE_SHOW_0"]));
	pagKoSettingChild.appendChild(child);
	child = document.createElement("option");
	child.setAttribute("id", "pul_KSP_Show_File_List_Option1");
	child.setAttribute("value", "1");
	child.appendChild(document.createTextNode(glbTexts["KO_CHANGE_SETTING_FILE_SHOW_1"]));
	pagKoSettingChild.appendChild(child);
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("div");
	pagKoSettingChild.setAttribute("id", "lbl_KSP_AFTER_File_Del");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("select");
	pagKoSettingChild.setAttribute("id", "pul_KSP_After_File_Del");
	pagKoSettingChild.setAttribute("onClick", "onKoSettingPopup('onbuttonup', 'pul_KSP_After_File_Del')");
	var child = document.createElement("option");
	child.setAttribute("value", "0");
	child.setAttribute("id", "pul_KSP_After_File_Del_Option0");
	child.appendChild(document.createTextNode(glbTexts["KO_CHANGE_SETTING_FILE_DEL_0"]));
	pagKoSettingChild.appendChild(child);
	child = document.createElement("option");
	child.setAttribute("id", "pul_KSP_After_File_Del_Option1");
	child.setAttribute("value", "1");
	child.appendChild(document.createTextNode(glbTexts["KO_CHANGE_SETTING_FILE_DEL_1"]));
	pagKoSettingChild.appendChild(child);
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("div");
	pagKoSettingChild.setAttribute("id", "lbl_KSP_Print_Order");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("select");
	pagKoSettingChild.setAttribute("id", "pul_KSP_Print_Order");
	pagKoSettingChild.setAttribute("onClick", "onKoSettingPopup('onbuttonup', 'pul_KSP_Print_Order')");
	var child = document.createElement("option");
	child.setAttribute("value", "0");
	child.setAttribute("id", "pul_KSP_Print_Order_Option0");
	child.appendChild(document.createTextNode(glbTexts["KO_SETTING_ORDER_MENU_0"]));
	pagKoSettingChild.appendChild(child);
	child = document.createElement("option");
	child.setAttribute("id", "pul_KSP_Print_Order_Option1");
	child.setAttribute("value", "1");
	child.appendChild(document.createTextNode(glbTexts["KO_SETTING_ORDER_MENU_1"]));
	pagKoSettingChild.appendChild(child);
	pagKoSetting.appendChild(pagKoSettingChild);
}

function createDeviceResigtPopupHtml()
{
	var body =document.body;

	var pagKoSetting = document.createElement("div");
	pagKoSetting.setAttribute("id", "pag_KO_Devices_Regist_Popup");
	pagKoSetting.setAttribute("class", "page");

	body.appendChild(pagKoSetting);

	var pagKoSettingChild = document.createElement("img");
	pagKoSettingChild.setAttribute("id", "img_KO_Device_Regist_Background");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("div");
	pagKoSettingChild.setAttribute("id", "lbl_DRP_title");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("input");
	pagKoSettingChild.setAttribute("type", "button");
	pagKoSettingChild.setAttribute("id", "btn_KSP_cancel");
	pagKoSettingChild.setAttribute("value", glbTexts["KO_CHANGE_SETTING_CANCEL_BTN_LABEL"]);
	pagKoSettingChild.setAttribute("onClick", "onKoRegistDevices('onbuttonup', 'btn_KSP_cancel')");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("input");
	pagKoSettingChild.setAttribute("type", "button");
	pagKoSettingChild.setAttribute("id", "btn_KSP_confirm");
	pagKoSettingChild.setAttribute("value", glbTexts["KO_CHANGE_SETTING_CONFIRM_BTN_LABEL"]);
	pagKoSettingChild.setAttribute("onClick", "onKoRegistDevices('onbuttonup', 'btn_KSP_confirm')");
	pagKoSetting.appendChild(pagKoSettingChild)

	pagKoSettingChild = document.createElement("div");
	pagKoSettingChild.setAttribute("id", "lbl_KSP_IP_Address");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("div");
	pagKoSettingChild.setAttribute("id", "lbl_KSP_SSL");
	pagKoSetting.appendChild(pagKoSettingChild);

	pagKoSettingChild = document.createElement("div");
	pagKoSettingChild.setAttribute("id", "lbl_KSP_Port");
	pagKoSetting.appendChild(pagKoSettingChild);

	for(var i=0; i<5; i++){
		pagKoSettingChild = document.createElement("div");
		pagKoSettingChild.setAttribute("id", "lbl_KSP_Device" + i);
		pagKoSetting.appendChild(pagKoSettingChild);
		pagKoSettingChild = document.createElement("input");
		pagKoSettingChild.setAttribute("type", "text");
		pagKoSettingChild.setAttribute("id", "txt_KSP_Device_IP" + i);
		pagKoSettingChild.setAttribute("onClick", "onKoRegistDevices('onbuttonup', 'txt_KSP_Device_IP" + i + "')");

		if(i!=0){
			pagKoSettingChild.setAttribute("maxlength", "256");
		}
		pagKoSettingChild.setAttribute("onFocus", "this.blur();");
		pagKoSetting.appendChild(pagKoSettingChild);

		pagKoSettingChild = document.createElement("select");
		pagKoSettingChild.setAttribute("id", "pul_KSP_SSL" + i);
		pagKoSettingChild.setAttribute("onClick", "onKoRegistDevices('onbuttonup', 'pul_KSP_SSL" + i + "')");
		var child = document.createElement("option");
		child.setAttribute("id", "pul_KSP_SSL_Option0");
		child.setAttribute("value", "0");
		child.appendChild(document.createTextNode(glbTexts["KO_CHANGE_SETTING_SSL_0"]));
		pagKoSettingChild.appendChild(child);
		child = document.createElement("option");
		child.setAttribute("id", "pul_KSP_SSL_Option1");
		child.setAttribute("value", "1");
		child.appendChild(document.createTextNode(glbTexts["KO_CHANGE_SETTING_SSL_1"]));
		pagKoSettingChild.appendChild(child);
		pagKoSetting.appendChild(pagKoSettingChild);

		pagKoSettingChild = document.createElement("div");
		pagKoSettingChild.setAttribute("id", "btn_KSP_Port" + i);
		var child = document.createElement("img");
		child.setAttribute("id", "img_KSP_Port" + i);
		pagKoSettingChild.appendChild(child);
		child = document.createElement("div");
		child.setAttribute("id", "txt_KSP_Port" + i);
		pagKoSettingChild.appendChild(child);
		pagKoSetting.appendChild(pagKoSettingChild);
	}
}