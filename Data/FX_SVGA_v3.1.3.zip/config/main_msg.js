var MAIN_MSG = {
	LOGIN_MSG: "로그인 후 사용하세요.",
	LOGIN_MSG2: "로그인이 안되면 관리자에게 문의바랍니다."
};
