/**
 * 개별 페이지의 표시 및 동작용
 * （환경 설정 팝업)
 */
var PreferenceSettingEtcPopup = new TemplatePage();

PreferenceSettingEtcPopup.ID = "pop_preferenceSettingEtc";
PreferenceSettingEtcPopup.key = "PRE";

/**
 * 개별 페이지의  Data정의
 */
PreferenceSettingEtcPopup._initModel=function()
{
	this._data = {
		buttonList:[
			{id:"btn_PRE_cancel",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PRE_cancel",	offImg:Img["BTN_150_34_OFF"],	pressImg:Img["BTN_150_34_PRESS"]}	},
			{id:"btn_PRE_confirm",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PRE_confirm",	offImg:Img["BTN_150_34_OFF"],	pressImg:Img["BTN_150_34_PRESS"]}	},
			{id:"btn_PRE_main",		type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PRE_main",		offImg:Img["BTN_150_34_OFF"],	pressImg:Img["BTN_150_34_PRESS"]}	}
		],
		imageList:[
			{id:"img_PRE_bg",	src:Img["IMG_PR_BG"]}
		],
		textList:[
			{id:"lbl_PRE_title",				text:Msg.PreferenceSettingPopup.TITLE},						//환경설정
			{id:"lbl_PRE_cancel",				text:Msg.PreferenceSettingPopup.CANCEL_BTN_LABEL},			//취소
			{id:"lbl_PRE_confirm",				text:Msg.PreferenceSettingPopup.CONFIRM_BTN_LABEL},			//설정
			{id:"lbl_PRE_main",					text:Msg.PreferenceSettingPopup.ETC_MAIN_LABEL},			//메인화면으로 이동

			{id:"lbl_PRE_lstDisplayLimit",		text:Msg.PreferenceSettingPopup.LST_DISPLIMIT_LABEL},		//리스트 표시 제한:
			{id:"lbl_PRE_resptimeDisplayLimit",	text:Msg.PreferenceSettingPopup.RESPTIME_LIMIT_LABEL},		//수신시간 표시 제한:
			{id:"lbl_PRE_connectionTimeLimit",	text:Msg.PreferenceSettingPopup.CONNECTTIME_LIMIT_LABEL},	//연결 제한 시간:
			{id:"lbl_PRE_lstBarDisplay",		text:Msg.PreferenceSettingPopup.LSTBAR_DISP_LABEL},			//리스트 바로 표시:
			{id:"lbl_PRE_defaultBtnSetting",	text:Msg.PreferenceSettingPopup.DFT_BTNSETTING_LABEL},		//초기 버튼 설정 값 지정:
			{id:"lbl_PRE_displayColorUsage",	text:Msg.PreferenceSettingPopup.COLORUSAGE_DISP_LABEL},		//Color사용량 보이기:
			{id:"lbl_PRE_deleteAfterPrintMode",	text:Msg.PreferenceSettingPopup.AFT_DELMODE_LABEL},			//프린트한 후 삭제의 초기 설정:
			{id:"lbl_PRE_lstListAutoSelect",	text:Msg.PreferenceSettingPopup.LIST_AUTO_SELECT_LABEL},	//리스트 자동 선택: //SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
			{id:"lbl_PRE_lstListSortSelect",	text:Msg.PreferenceSettingPopup.LIST_SORT_SELECT_LABEL},	//리스트 정렬 선택:

			/********************************************** pulldown item *******************************/
			{id:"pul_PRE_lstDisplayLimit0",		text:glbInfo.prefrenceSetting.JOB_LIST_COUNT[0].text},
			{id:"pul_PRE_lstDisplayLimit1",		text:glbInfo.prefrenceSetting.JOB_LIST_COUNT[1].text},
			{id:"pul_PRE_resptimeDisplayLimit0",text:glbInfo.prefrenceSetting.TIME_TYPE[0].text},
			{id:"pul_PRE_resptimeDisplayLimit1",text:glbInfo.prefrenceSetting.TIME_TYPE[1].text},
			{id:"pul_PRE_lstBarDisplay0",		text:glbInfo.prefrenceSetting.SKIP[0].text},
			{id:"pul_PRE_lstBarDisplay1",		text:glbInfo.prefrenceSetting.SKIP[1].text},
			{id:"pul_PRE_defaultBtnSetting0",	text:glbInfo.prefrenceSetting.BUTTON_DEFAULT[0].text},
			{id:"pul_PRE_defaultBtnSetting1",	text:glbInfo.prefrenceSetting.BUTTON_DEFAULT[1].text},
			{id:"pul_PRE_defaultBtnSetting2",	text:glbInfo.prefrenceSetting.BUTTON_DEFAULT[2].text},
			{id:"pul_PRE_defaultBtnSetting3",	text:glbInfo.prefrenceSetting.BUTTON_DEFAULT[3].text},		//2017.10 [v1.5] SmartUI 출력방식 옵션 추가 refs #4497
			{id:"pul_PRE_defaultBtnSetting4",	text:glbInfo.prefrenceSetting.BUTTON_DEFAULT[4].text},		//2017.10 [v1.5] SmartUI 출력방식 옵션 추가 refs #4497
			{id:"pul_PRE_displayColorUsage0",	text:glbInfo.prefrenceSetting.COLOR_DISPLAY[0].text},
			{id:"pul_PRE_displayColorUsage1",	text:glbInfo.prefrenceSetting.COLOR_DISPLAY[1].text},
			{id:"pul_PRE_deleteAfterPrintMode0",text:glbInfo.prefrenceSetting.DELETE[0].text},
			{id:"pul_PRE_deleteAfterPrintMode1",text:glbInfo.prefrenceSetting.DELETE[1].text},
			{id:"pul_PRE_lstListAutoSelect0",	text:glbInfo.prefrenceSetting.LIST_AUTO_SELECT[0].text},	//SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
			{id:"pul_PRE_lstListAutoSelect1",	text:glbInfo.prefrenceSetting.LIST_AUTO_SELECT[1].text}, 	//SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
			{id:"pul_PRE_lstListSortSelect0",	text:glbInfo.prefrenceSetting.LIST_SORT_ASC[0].text},
			{id:"pul_PRE_lstListSortSelect1",	text:glbInfo.prefrenceSetting.LIST_SORT_ASC[1].text}
		]
	};
};

/**
 * 개별 페이지 고유의 항목을 구성
 */
PreferenceSettingEtcPopup._initOthers = function()
{
	var tbxConTimeLimit = document.getElementById("tbx_PRE_connectionTimeLimit");
	tbxConTimeLimit.onchange = function(){
		//var _min=5,_max=999,_default=10;
		var _min = CON_TIMEOUT.Min,
			_max = CON_TIMEOUT.Max,
			_default = CON_TIMEOUT.Default;

		var pattern  = /^[0-9]+$/;
		var tmp = parseInt(this.value);
		if(pattern.test(this.value)&!isNaN(tmp)){
			if(tmp < _min){
				this.value = _min;
			}else if(tmp > _max){
				this.value = _max;
			}
		}else{
			this.value=_default;
		}
	};
	// 연결 제한 시간 입력 하한-상한 표시
	var _lbl = document.getElementById("lbl_PRE_connectionTimeLimit_Guide");
	_lbl.innerHTML = "(" + CON_TIMEOUT.Min + "&nbsp;-&nbsp;" + CON_TIMEOUT.Max + ")";
};

PreferenceSettingEtcPopup._onPageChange = function (e, args){
	this.updateDisplay();
};

PreferenceSettingEtcPopup.onChangeEventHandler = function(e, args){};

/**
 * 화면 표시의 갱신 (공통/화면전환시에 호출된다.)
 */
PreferenceSettingEtcPopup.updateDisplay = function()
{
	KISUtil.debug("function:","updateDisplay");
	var lst = [
		{id:"pul_PRE_lstDisplayLimit0",		value:glbInfo.prefrenceSetting.JOB_LIST_COUNT[0].value},
		{id:"pul_PRE_lstDisplayLimit1",		value:glbInfo.prefrenceSetting.JOB_LIST_COUNT[1].value},
		{id:"pul_PRE_resptimeDisplayLimit0",value:glbInfo.prefrenceSetting.TIME_TYPE[0].value},
		{id:"pul_PRE_resptimeDisplayLimit1",value:glbInfo.prefrenceSetting.TIME_TYPE[1].value},
		{id:"pul_PRE_lstBarDisplay0",		value:glbInfo.prefrenceSetting.SKIP[0].value},
		{id:"pul_PRE_lstBarDisplay1",		value:glbInfo.prefrenceSetting.SKIP[1].value},
		{id:"pul_PRE_defaultBtnSetting0",	value:glbInfo.prefrenceSetting.BUTTON_DEFAULT[0].value},
		{id:"pul_PRE_defaultBtnSetting1",	value:glbInfo.prefrenceSetting.BUTTON_DEFAULT[1].value},
		{id:"pul_PRE_defaultBtnSetting2",	value:glbInfo.prefrenceSetting.BUTTON_DEFAULT[2].value},
		{id:"pul_PRE_defaultBtnSetting3",	value:glbInfo.prefrenceSetting.BUTTON_DEFAULT[3].value},//2017.10 [v1.5] SmartUI 출력방식 옵션 추가 refs #4497
		{id:"pul_PRE_defaultBtnSetting4",	value:glbInfo.prefrenceSetting.BUTTON_DEFAULT[4].value},//2017.10 [v1.5] SmartUI 출력방식 옵션 추가 refs #4497
		{id:"pul_PRE_displayColorUsage0",	value:glbInfo.prefrenceSetting.COLOR_DISPLAY[0].value},
		{id:"pul_PRE_displayColorUsage1",	value:glbInfo.prefrenceSetting.COLOR_DISPLAY[1].value},
		{id:"pul_PRE_deleteAfterPrintMode0",value:glbInfo.prefrenceSetting.DELETE[0].value},
		{id:"pul_PRE_deleteAfterPrintMode1",value:glbInfo.prefrenceSetting.DELETE[1].value},
		{id:"pul_PRE_lstListAutoSelect0", 	value:glbInfo.prefrenceSetting.LIST_AUTO_SELECT[0].value},//SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
		{id:"pul_PRE_lstListAutoSelect1", 	value:glbInfo.prefrenceSetting.LIST_AUTO_SELECT[1].value}, //SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
		{id:"pul_PRE_lstListSortSelect0",	value:glbInfo.prefrenceSetting.LIST_SORT_ASC[0].value},
		{id:"pul_PRE_lstListSortSelect1",	value:glbInfo.prefrenceSetting.LIST_SORT_ASC[1].value}
	];

	var item;
	for(var i=0, iMax=lst.length; i<iMax; i++){
		item=lst[i];
		document.getElementById(item.id).value=item.value;
	}
	if(glbConfig.DATA.TIMEOUT&&glbConfig.DATA.TIMEOUT.toString().length>0) Common.setText("tbx_PRE_connectionTimeLimit",glbConfig.DATA.TIMEOUT);

	Common.setIndex("pul_PRE_lstDisplayLimit",		Common.getIndex(glbInfo.prefrenceSetting.JOB_LIST_COUNT,glbConfig.DATA.JOB_LIST_COUNT));
	Common.setIndex("pul_PRE_resptimeDisplayLimit",	Common.getIndex(glbInfo.prefrenceSetting.TIME_TYPE,glbConfig.DATA.TIME_TYPE));
	Common.setIndex("pul_PRE_lstBarDisplay",		Common.getIndex(glbInfo.prefrenceSetting.SKIP,glbConfig.DATA.SKIP));
	Common.setIndex("pul_PRE_defaultBtnSetting",	Common.getIndex(glbInfo.prefrenceSetting.BUTTON_DEFAULT,glbConfig.DATA.BUTTON_DEFAULT));
	Common.setIndex("pul_PRE_displayColorUsage",	Common.getIndex(glbInfo.prefrenceSetting.COLOR_DISPLAY,glbConfig.DATA.COLOR_DISPLAY));
	Common.setIndex("pul_PRE_deleteAfterPrintMode",	Common.getIndex(glbInfo.prefrenceSetting.DELETE,glbConfig.DATA.DELETE));
	Common.setIndex("pul_PRE_lstListAutoSelect", 	Common.getIndex(glbInfo.prefrenceSetting.LIST_AUTO_SELECT, glbConfig.DATA.LIST_AUTO_SELECT));//SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
	Common.setIndex("pul_PRE_lstListSortSelect",	Common.getIndex(glbInfo.prefrenceSetting.LIST_SORT_ASC,glbConfig.DATA.LIST_SORT_ASC));
};

/**
 * 개별 페이지의 Event처리
 * @param {string} event : Event의 종류
 * @param {string} id : Event발생원
 */
PreferenceSettingEtcPopup.EventHandler = function(event, id)
{
	KISUtil.debug("EventHandler","event:"+event+"/id:"+id);
	switch(event){
		case "onbuttonup":
			MessageManager.clearMessageArea();
			BrowserExt.Beep(0);
			switch(id){
				case "btn_PRE_cancel":
					//PageManager.changePage(PageManager.getPrevPage(),PageManager.type.CANCEL);
					BrowserExt.SetScreenChange("allservice");
					break;
				case "btn_PRE_confirm":
					//widget으로 등록하지 않았으므로
					//컨펌 직전에 데이터를 반영해야함
					var setting = this.getSettingEtc();
					//console.log(setting);
					glbConfig.DATA = Extend(glbConfig.DATA, setting);
					//save setting
					var _contents = "var DATA = " + JSON.stringify(setting);
					KISUtil.debug(_contents);
					save_content_to_file(_contents, PREFERENCE_DATA_LOC);
					eval(_contents);//2017.10 [v1.5] SmartUI 출력방식 옵션 추가 refs #4497 - 비관련 코드이나 eval 변수가 잘못 지정되어 있으므로(_dataContents) 수정함
					//PageManager.changePage(PageManager.getPrevPage(),PageManager.type.CONFIRM);
					//PageManager.changePage(MenuPage,PageManager.type.CONFIRM);
					BrowserExt.SetScreenChange("allservice");
					break;
				case "btn_PRE_main":
					this.pageSave();
					PageManager.changePage(PreferenceSettingPopup, PageManager.type.NORMAL);
					break;
				default:
					//clearMessageAreaTimer();
					break;
			}
			break;
		case "onhardkeydown":
			MessageManager.clearMessageArea();
			switch(id){
				//case BrowserExt.keyCode.FX_VK_START:
				//case BrowserExt.keyCode.FX_VK_CLEAR:
				case BrowserExt.keyCode.FX_VK_PAUSE:
					break;
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		default:
			break;
	}
};

PreferenceSettingEtcPopup.getSettingEtc = function()
{
	var setting = {};
	var obj = document.getElementById("pul_PRE_lstDisplayLimit");
	setting.JOB_LIST_COUNT = parseInt(obj.options[obj.selectedIndex].value);

	obj = document.getElementById("pul_PRE_resptimeDisplayLimit");
	setting.TIME_TYPE = parseInt(obj.options[obj.selectedIndex].value);

	setting.TIMEOUT = parseInt(document.getElementById("tbx_PRE_connectionTimeLimit").value);

	obj = document.getElementById("pul_PRE_lstBarDisplay");
	setting.SKIP = parseInt(obj.options[obj.selectedIndex].value);

	obj = document.getElementById("pul_PRE_defaultBtnSetting");
	setting.BUTTON_DEFAULT = obj.options[obj.selectedIndex].value;

	obj = document.getElementById("pul_PRE_displayColorUsage");
	setting.COLOR_DISPLAY = parseBool(obj.options[obj.selectedIndex].value);

	obj = document.getElementById("pul_PRE_deleteAfterPrintMode");
	setting.DELETE = obj.selectedIndex;

	obj = document.getElementById("pul_PRE_lstListAutoSelect");
	setting.LIST_AUTO_SELECT = obj.selectedIndex;

	setting.UPDATE_DELAY_TIME = glbConfig.DATA.UPDATE_DELAY_TIME;

	setting.LIST_SORT_ASC = glbConfig.DATA.LIST_SORT_ASC;
	obj = document.getElementById("pul_PRE_lstListSortSelect");
	setting.LIST_SORT_ASC = checkBool(obj.options[obj.selectedIndex].value); // 좀더안전한 형태로 변경

	setting.NAME_DISPLAY_SELECT = glbConfig.DATA.NAME_DISPLAY_SELECT;

	setting.TITLE_NAME = glbInfo.prefrenceSetting.TITLE_NAME;
	setting.SERVER_URL = glbConfig.DATA.SERVER_URL;
	for(var i=0;glbInfo.prefrenceSetting.SERVER_URL.length > i;i++){
		setting.SERVER_URL[i] = glbInfo.prefrenceSetting.SERVER_URL[i];
	}
	setting.MULTI_SERVER_TYPE = glbInfo.prefrenceSetting.MULTI_SERVER_TYPE.SET;

	return setting;
};

PreferenceSettingEtcPopup.pageSave = function()
{
	var obj = document.getElementById("pul_PRE_lstDisplayLimit");
	glbInfo.prefrenceSetting.JOB_LIST_COUNT.SET = parseInt(obj.options[obj.selectedIndex].value);

	obj = document.getElementById("pul_PRE_resptimeDisplayLimit");
	glbInfo.prefrenceSetting.TIME_TYPE.SET = parseInt(obj.options[obj.selectedIndex].value);

	glbInfo.prefrenceSetting.TIMEOUT = parseInt(document.getElementById("tbx_PRE_connectionTimeLimit").value);

	obj = document.getElementById("pul_PRE_lstBarDisplay");
	glbInfo.prefrenceSetting.SKIP.SET = parseInt(obj.options[obj.selectedIndex].value);

	obj = document.getElementById("pul_PRE_defaultBtnSetting");
	glbInfo.prefrenceSetting.BUTTON_DEFAULT.SET = obj.options[obj.selectedIndex].value;

	obj = document.getElementById("pul_PRE_displayColorUsage");
	glbInfo.prefrenceSetting.COLOR_DISPLAY.SET = parseBool(obj.options[obj.selectedIndex].value);

	obj = document.getElementById("pul_PRE_deleteAfterPrintMode");
	glbInfo.prefrenceSetting.DELETE.SET = obj.selectedIndex;

	obj = document.getElementById("pul_PRE_lstListSortSelect");
	glbInfo.prefrenceSetting.LIST_SORT_ASC.SET = parseBool(obj.options[obj.selectedIndex].value);

	obj = document.getElementById("pul_PRE_lstListAutoSelect");
	glbInfo.prefrenceSetting.LIST_AUTO_SELECT.SET = obj.selectedIndex;;

	glbInfo.prefrenceSetting.UPDATE_DELAY_TIME = glbConfig.DATA.UPDATE_DELAY_TIME;
	glbInfo.prefrenceSetting.NAME_DISPLAY_SELECT = glbConfig.DATA.NAME_DISPLAY_SELECT;
};
/**
 * 풀다운 닫기 처리용 메소드
 * templatePage.js로부터 이동
 */
PreferenceSettingEtcPopup.onPageClick = function()
{
	switch(WidgetLib._popupId)
	{
		case "pul_PRE_color_popup":
		case "pul_PRE_plex_popup":
		case "pul_PRE_nup_popup":
			WidgetLib.closePopupWidget(WidgetLib._popupId);
			MessageManager.clearMessageArea();
			break;
		default:
			break;
	}
};
