﻿/**
 * 개별 페이지의 표시 및 동작용
 * （IC Card등록용 팝업）
 */
var FileListPage = new TemplatePage();

FileListPage.ID = "page_FileList";
FileListPage.key = "FL";

/**
 * 개별 페이지의 Data정의
 */
FileListPage._initModel = function() {
    this._data = {
        buttonList: [
            { id: "btn_FL_SelectAll", type: WidgetLib.ButtonType.NORMAL, status: { enable: false }, attr: { targetImgId: "img_FL_SelectAll", offImg: Img["SELECT_ALL_BTN_OFF"], pressImg: Img["SELECT_ALL_BTN_PRESS"], onImg: Img["SELECT_ALL_BTN_ON"], disableImg: Img["SELECT_ALL_BTN_DIS"] } },
            { id: "btn_FL_PrintAll", type: WidgetLib.ButtonType.NORMAL, status: { enable: false }, attr: { targetImgId: "img_FL_PrintAll", offImg: Img["PRINT_ALL_BTN_OFF"], pressImg: Img["PRINT_ALL_BTN_PRESS"], disableImg: Img["PRINT_ALL_BTN_DIS"] } },
            { id: "btn_FL_Refresh", type: WidgetLib.ButtonType.NORMAL, status: { enable: false }, attr: { targetImgId: "img_FL_Refresh", offImg: Img["DISPLAY_CHANGE_BTN_OFF"], pressImg: Img["DISPLAY_CHANGE_BTN_PRESS"], disableImg: Img["DISPLAY_CHANGE_BTN_DIS"] } },
            { id: "btn_FL_pageUp", type: WidgetLib.ButtonType.NORMAL, status: { enable: false }, attr: { offImg: Img["FILE_LIST_UP_BTN_OFF"], pressImg: Img["FILE_LIST_UP_BTN_PRESS"], disableImg: Img["FILE_LIST_UP_BTN_DIS"] } },
            { id: "btn_FL_pageDown", type: WidgetLib.ButtonType.NORMAL, status: { enable: false }, attr: { offImg: Img["FILE_LIST_DOWN_BTN_OFF"], pressImg: Img["FILE_LIST_DOWN_BTN_PRESS"], disableImg: Img["FILE_LIST_DOWN_BTN_DIS"] } },
            { id: "btn_FL_DeleteFile", type: WidgetLib.ButtonType.NORMAL, status: { enable: false }, attr: { targetImgId: "img_FL_DeleteFile", offImg: Img["DELETE_FILE_BTN_OFF"], pressImg: Img["DELETE_FILE_BTN_PRESS"], disableImg: Img["DELETE_FILE_BTN_DIS"] } },
            { id: "btn_FL_Modi_PrintSetting", type: WidgetLib.ButtonType.NORMAL, status: { enable: false }, attr: { targetImgId: "img_FL_Modi_PrintSetting", offImg: Img["FILE_LIST_COMMAND_BTN_OFF"], pressImg: Img["FILE_LIST_COMMAND_BTN_PRESS"], disableImg: Img["FILE_LIST_COMMAND_BTN_DIS"] } },
            { id: "btn_FL_Print", type: WidgetLib.ButtonType.NORMAL, status: { enable: false }, attr: { targetImgId: "img_FL_Print", offImg: Img["PRINT_BTN_OFF"], pressImg: Img["PRINT_BTN_PRESS"], disableImg: Img["PRINT_BTN_DIS"] } },
            { id: "btn_AP_Close", type: WidgetLib.ButtonType.NORMAL, status: { enable: false }, attr: { targetImgId: "img_AP_Close", offImg: Img["POPUP_YELLOW_CLOSE_BTN_OFF"], pressImg: Img["POPUP_YELLOW_CLOSE_BTN_PRESS"] } }
        ],
        imageList: [
            { id: "img_FL_PrintQuantity", src: Img["TEXT_INPUT_BOX_ENABLE"] }
        ],
        textList: [
            { id: "lbl_FL_Refresh", text: Msg.FILELIST.DISPLAY_CHANGE_BTN_LABEL },
            { id: "lbl_FL_PrintAll", text: Msg.FILELIST.PRINT_ALL },
            { id: "lbl_FL_Print", text: Msg.FILELIST.PRINT },
            { id: "lbl_FL_SelectedFile", text: Msg.FILELIST.SELECTED_FILE_NUMBER_MSG },
            { id: "lbl_FL_SelectAll0", text: Msg.FILELIST.SELECT_ALL_BTN_LABEL_0 },
            { id: "lbl_FL_SelectAll1", text: Msg.FILELIST.SELECT_ALL_BTN_LABEL_1 },
            { id: "lbl_FL_DeleteFile", text: Msg.FILELIST.DELETE_FILE_BTN_LABEL },
            { id: "txt_FL_PrintQuantity", text: "" },
            { id: "lbl_FL_PrintQuantity", text: Msg.FILELIST.COMMON_PRINT_QUANTITY_LABEL },
            { id: "lbl_FL_Modi_PrintSetting0", text: Msg.FILELIST.PRINT_SETTING_BTN_LABEL_0 },
            { id: "lbl_FL_Modi_PrintSetting1", text: Msg.FILELIST.PRINT_SETTING_BTN_LABEL_1 },
            { id: "txt_FL_NotifyMsg0", text: Msg.FILELIST.LOADING_MSG_0 },
            { id: "txt_FL_NotifyMsg1", text: Msg.FILELIST.LOADING_MSG_1 },
            { id: "txt_FL_NotifyMsg2", text: Msg.FILELIST.LOADING_MSG_2 },
            { id: "txt_FL_NotifyMsg3", text: Msg.FILELIST.LOADING_MSG_3 }
        ]
    };
    this.docListManager = new DocListManager({ targetId: "lyr_FL_Display_Area" });
    this.docListManager.updateSelectedFileCount = FileListPage.updateDisplaySelectedFileCount;
    this.docListManager.updateCurrentPage = FileListPage.updateDisplayCurrentPage;
    this.docListManager.updateTextPrnSet = FileListPage.updateDisplayPrintQuantity;
    this.prnCntManager = new PrintCountManager();
    this.prnCntManager.updateDisplay = this.updateDisplayPrintQuantity;
    this.validator = new Validator();
    this.validator.init();
};

/**
 * 페이지 천이 직후 호출됨
 */
FileListPage._onPageChange = function() {
    //문서리스트가 존재하지않는경우(리스트화면 최초 표시시점)
    //문서리스트를 요청,최초이외의 경우의 갱신은 갱신버튼에 의한 경우밖에 없으므로
    var _loadFlg = false;

    if (!this._dataSet.docList || glbInfo.isJobExcuted) {
        _loadFlg = true;
        //잡 실행에 Flag 원복
        glbInfo.isJobExcuted = false;
        //리스트 선택정보 초기화
        this.docListManager.currentPageIdx = 1; //페이지 초기화
        this.docListManager.selectedItemIdx = -1; //선택 초기화
        this.docListManager.setCheckedItems([]); //체크 초기화

        this.displayFileSelectedNumLoading();
    } else {
        this.docListManager.setDataSource(this._dataSet.docList);
        if (this.docListManager.selectedItemIdx > -1) {
            var _doc = this.docListManager.dataSource[this.docListManager.selectedItemIdx];
            this.prnCntManager.setNum(_doc.printCnt);
            //인쇄매수 변경분 반영
            this.docListManager.updateQuantity(this.updateQuantity, false);
            //this.docListManager.updateInvalidFlag();
        }
    }

    this.updateDisplay();

    if (_loadFlg) {
        this.refreshStoredDocument();
    }
};

/**
 * 화면 표시의 갱신 (공용/화면전환시 호출된다.)
 */
FileListPage.updateDisplay = function() {
    KISUtil.debug("function:", "updateDisplay");
    if (this._dataSet.docList) {
        //this.docListManager.setDataSource(this._dataSet.docList);		//TODO:_onPageChange에서 중복할당중임 시간될때 refactoring할것
        this.docListManager.refresh();
        var _selectedDoc = this.docListManager.getSelectedDocInfo();
        if (_selectedDoc.success) {
            this.prnCntManager.setNum(_selectedDoc.doc.printCnt);
        }
    }
};

FileListPage._getCurrentPolicy = function() {
    var _doc = this.docListManager.getSelectedDocInfo().doc,
        _forcedBlack = glbDataSet.userPolicyInfo.forcedBlack ? 1 : 0,
        _forcedNup = glbDataSet.userPolicyInfo.forced2Up ? 1 : 0,
        _forcedDuplex = glbDataSet.userPolicyInfo.forcedDuplex ? 1 : 0,
        _forbid = parseInt(glbDataSet.userPolicyInfo.functionCtrl);
    var _policy = this.validator.getBtnStatusByPolicy(_forbid, _forcedNup, _forcedDuplex, _forcedBlack, _doc);

    return _policy;
};

/**
 * 개별 페이지의 Event처리
 * @param {string} event : Event종류
 * @param {string} id : Event 발생원
 */
FileListPage.EventHandler = function(event, id) {
    switch (event) {
        case "GetStoredDocList": //2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
            glbDataSet.docList = glbInfo.docList;
            FileListPage.getServerStoredDocument();
            break;
        case "GetPrnListPolicy": //2017.11 [v1.5] SmartUI 복수의 Print Server 대응 refs #4502
            if (glbInfo.serverCallCount == 0) { //glbDataSet.usedFileCount값이 누적되지 않도록 통신시마다 리셋함
                glbDataSet.usedFileCount = 0;
            }
            glbInfo.serverCallCount++;
            if (arguments[1] == true) {
                var _result = arguments[2];
                if (_result.status == "success") {
                    var _resultData = _result.result;

                    if (typeof glbDataSet.userPolicyInfo.forced2Up == 'undefined') { //첫번째 응답의 정보를 저장
                        var _userInfo = _resultData.userInfo;
                        glbDataSet.userPolicyInfo.forced2Up = (_userInfo.forced2Up == "Y");
                        glbDataSet.userPolicyInfo.forcedBlack = (_userInfo.forcedBlack == "Y");
                        glbDataSet.userPolicyInfo.defaultBlack = (_userInfo.defaultBlack == "Y"); //사양변경분 대응 2013/04/03
                        glbDataSet.userPolicyInfo.forcedDuplex = (_userInfo.forcedDuplex == "Y");
                        glbDataSet.userPolicyInfo.functionCtrl = parseInt(_userInfo.functionCtrl);
                        glbDataSet.userPolicyInfo.printAgain = (_userInfo.printAgain == "Y");
                        glbDataSet.userPolicyInfo.prnCount = glbInfo.usagePrnCnt.overCountPrint ? 0 : parseInt(_userInfo.prnCount); //사양변경분 대응 2013/02/22
                        glbDataSet.userPolicyInfo.userId = _userInfo.userId;
                    }

                    if (_resultData.prnList) {
                        var _tmp = convertToVMData(_resultData.prnList, _resultData.userInfo.serverIdx);
                        var _lst = _tmp.lst;

                        if (glbDataSet.docList && glbDataSet.docList.length > 0) { //2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
                            for (var i = 0; i < _lst.length; i++) {
                                // 동일한 UUID와 serverIdx가 이미 있는 경우에는 Job을 등록하지 않는다.
                                if (regJobCheck(_lst[i].UUID, _lst[i].serverIdx)) {
                                    glbDataSet.docList.push(_lst[i]);
                                }
                            }
                        } else {
                            glbDataSet.docList = _lst;
                        }

                        glbDataSet.usedFileCount += _tmp.usedFileCount;
                    }
                } else {
                    glbInfo.serverErrCount++;
                    LogLib.info("[CS] GetUsagePrnCnt Error : " + _result.status);
                }
            } else {
                glbInfo.serverErrCount++;
                KISUtil.debug("Common.onLoadEvent/GetPrnListPolicy", "fail");
            }

            if (glbInfo.serverCallCount == glbInfo.SERVER_NUM) {
                if ((glbInfo.serverCallCount == glbInfo.serverErrCount) && (glbInfo.usagePrnCnt.prnCountPrivate <= 0) && (glbInfo.usagePrnCnt.prnCount <= 0)) {
                    WarnPopup._message = { title: Msg.WarnPopup.title, type: "logout", targetPage: true, message: Msg.errorMessage.ERRCODE000 };
                    PageManager.changePage(WarnPopup, PageManager.type.NORMAL);
                } else {
                    glbDataSet.docList.sort(sortingLogic);
                    this.docListManager.initDisplay();

                    this.store();
                    this.docListManager.currentPageIdx = 1; //페이지 초기화
                    this.docListManager.setDataSource(glbDataSet.docList);

                    //선택출력 리스트 개선 요청 건 - 취득한 모든 문서가 미프린트의 경우에는 선택 상태로 하지 않음
                    //미프린트 문서와 기프린트 문서가 섞여 있을 경우, 미프린트 문서를 선택 상태로 표시함
                    //2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
                    if ((glbDataSet.usedFileCount > 0 || glbInfo.usedPrivatePrintCount > 0) && glbConfig.DATA.LIST_AUTO_SELECT == 1) { //SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
                        //this.docListManager.setCheckedItems(this.getSelectedListByLength(glbDataSet.docList.length - _tmp.usedFileCount - glbInfo.usedPrivatePrintCount));
                        this.docListManager.setCheckedItems(this.getSelectedListByUseYnFlag());
                    }
                    this.docListManager.refresh();
                    document.getElementById("lyr_FL_Display_Area").className = "";
                }
                glbInfo.serverCallCount = 0;
                glbInfo.serverErrCount = 0;
            }else{
              glbDataSet.docList.sort(sortingLogic);
              this.docListManager.initDisplay();

              this.store();
              this.docListManager.currentPageIdx = 1; //페이지 초기화
              this.docListManager.setDataSource(glbDataSet.docList);

              //선택출력 리스트 개선 요청 건 - 취득한 모든 문서가 미프린트의 경우에는 선택 상태로 하지 않음
              //미프린트 문서와 기프린트 문서가 섞여 있을 경우, 미프린트 문서를 선택 상태로 표시함
              //2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
              if ((glbDataSet.usedFileCount > 0 || glbInfo.usedPrivatePrintCount > 0) && glbConfig.DATA.LIST_AUTO_SELECT == 1) { //SmartUI 2016.05.23 선택출력 리스트 개선 요청 건(남동발전SmartUI개선)
                  //this.docListManager.setCheckedItems(this.getSelectedListByLength(glbDataSet.docList.length - _tmp.usedFileCount - glbInfo.usedPrivatePrintCount));
                  this.docListManager.setCheckedItems(this.getSelectedListByUseYnFlag());
              }
              this.docListManager.refresh();
              document.getElementById("lyr_FL_Display_Area").className = "";
            }
            break;
        case "DeleteSelected":
            //리스트 및 데이터 소스에서 선택항목을 제거
            //표시를 갱신
            MessageManager.displayMessage(MessageManager.MessageType.CONFLICT, "", "정상 삭제");
            break;
        case "onbuttonup":
            MessageManager.clearMessageArea();
            switch (id) {
                case "btn_FL_PrintAll":
                    //인쇄매수 변경분 반영
                    this.docListManager.updateQuantity(this.updateQuantity, true);
                    if (glbInfo.usagePrnCnt.prnCount > 0) {
                        BrowserExt.Beep(0);
                        //2017.10 KIS [v1.5] 선택출력 리스트 화면의 “전체 프린트” 버튼 기능 수정 refs #4494
                        var _lst = this.docListManager.getCheckedItems();
                        if (_lst.length != this.docListManager.getAllCount()) { //전체 선택이 안 되어 있는 경우 전체 선택 처리
                            this.docListManager.selectAllItems();
                        }
                        //_lst = this.docListManager.getCheckedItems();
                        _lst = this.docListManager.getPolicyCheckedItems(); // 출력 불가 문서의 경우 리스트에서 제외
                        if (_lst.length > 0){
                          Common.doJobStart(_lst);
                        }else{
                          switch(glbInfo.usagePrnCnt.functionCtrl){
                            case 0: // 기능제한 없음
                            case 2: // 컬러/흑백 사용가능
                              break;
                            case 3: // 컬러만 사용가능
                              MessageManager.displayMessage(MessageManager.MessageType.CONFLICT, "", Msg.errorMessage["FORBID_BW"]);
                              break;
                            case 1: // 흑백만 사용가능
                            case 4:
                              MessageManager.displayMessage(MessageManager.MessageType.CONFLICT, "", Msg.errorMessage["FORBID_COLOR"]);
                              break;
                            case 5: // 컬러/흑백 사용불가
                              MessageManager.displayMessage(MessageManager.MessageType.CONFLICT, "", Msg.errorMessage["FORBID_PERMISSION"]);
                              break;
                            case 6: // 사용량 제한
                              MessageManager.displayMessage(MessageManager.MessageType.CONFLICT, "", Msg.errorMessage["USAGE_LIMIT_OVER"]);
                              break;
                            default:
                              break;
                          }
                          this.prnCntManager.setEnableFlag(false);
                        }
                    } else {
                        BrowserExt.Beep(1);
                    }
                    break;
                case "btn_FL_Print":
                    //인쇄매수 변경분 반영
                    this.docListManager.updateQuantity(this.updateQuantity, true);
                    //인쇄 가능여부 판단
                    var _lst = this.docListManager.getCheckedItems();
                    if (_lst.length > 0) {
                        //Run Job
                        BrowserExt.Beep(0);
                        Common.doJobStart(_lst);
                    } else {
                        BrowserExt.Beep(1);

                    }
                    break;
                case "btn_FL_Refresh":
                    BrowserExt.Beep(0);
                    document.getElementById("lyr_FL_Display_Area").className = "loading";
                    this.refreshStoredDocument();
                    this.docListManager.init();
                    break;
                case "btn_FL_pageUp":
                    BrowserExt.Beep(0);
                    //인쇄매수 변경분 반영
                    this.docListManager.updateQuantity(this.updateQuantity, false);
                    this.docListManager.goPrevPage();
                    break;
                case "btn_FL_pageDown":
                    BrowserExt.Beep(0);
                    //인쇄매수 변경분 반영
                    this.docListManager.updateQuantity(this.updateQuantity, false);
                    this.docListManager.goNextPage();
                    break;
                case "btn_FL_SelectAll":
                    BrowserExt.Beep(0);
                    //인쇄매수 변경분 반영
                    this.docListManager.updateQuantity(this.updateQuantity, true);
                    this.docListManager.selectAllItems();
                    break;
                case "btn_FL_DeleteFile":
                    BrowserExt.Beep(0);
                    Common.doDeleteStart(); //2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498

                    /*var spList = new SSMILib.SelectedPrnInfo4Delete();
                    spList.userId = glbInfo.userInfo.userId;
                    spList.wsIp = glbConfig.wsIp;
                    spList.listSelected = this.docListManager.getSelectedUUIDs();
                    SSMILib.DeleteSelectedPrnInfo(spList);*/

                    this.docListManager.deleteItems();
                    this.docListManager.refresh();
                    break;
                case "btn_FL_Modi_PrintSetting":
                    BrowserExt.Beep(0);
                    //선택항목이 있는경우
                    if (this.docListManager.selectedItemIdx > -1) {
                        //인쇄매수 변경분 반영
                        this.docListManager.updateQuantity(this.updateQuantity, true);

                        var _selectedInfo = this.docListManager.getSelectedDocInfo();
                        if (_selectedInfo.success) {
                            //풀다운용 인덱스 추가
                            this._dataSet.selectedDocInfo = _selectedInfo.doc;
                        } else {
                            KISUtil.debug("docListManager.getSelectedDocInfo()", _selectedInfo.success);
                        }
                        this.store();
                        // 일괄 변경 기능 추가 대응
                        //PageManager.changePage(PrintSettingPopup, PageManager.type.NORMAL);
                        PageManager.changePage(((this.docListManager.getSelectedCount() > 1) ? PrintSettingMultiPopup : PrintSettingPopup), PageManager.type.NORMAL);
                    } else {
                        if (this.docListManager.getSelectedCount() > 1) {
                            PageManager.changePage(PrintSettingMultiPopup, PageManager.type.NORMAL);
                        }
                    }
                    break;
                case "btnDocItem0":
                case "btnDocItem1":
                case "btnDocItem2":
                case "btnDocItem3":
                    BrowserExt.Beep(0);
                    //인쇄매수 변경분 반영
                    this.docListManager.updateQuantity(this.updateQuantity, true);
                    //getIndex
                    var idx = parseInt(id.substring(id.length, id.length - 1));
                    this.docListManager.selectItem(idx);
                    var _selectedDoc = this.docListManager.getSelectedDocInfo();
                    if (_selectedDoc.success) {
                        if (!_selectedDoc.doc.prnType && !_selectedDoc.doc.boxId) { //2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
                            this.prnCntManager.setNum(_selectedDoc.doc.printCnt);
                            //this.prnCntManager.setEnableFlag(!_selectedDoc.doc.prnType);
                            var _policy = this._getCurrentPolicy();
                            if (_policy.success && _policy.status.msg != "") {
                                MessageManager.displayMessage(MessageManager.MessageType.CONFLICT, "", Msg.errorMessage[_policy.status.msg]);
                                this.prnCntManager.setEnableFlag(_policy.status.printStatus);
                            } else {
                                this.prnCntManager.setEnableFlag(false);
                            }
                        }
                    }
                    break;
                case "btn_num_key0":
                    case "btn_num_key1":
                    case "btn_num_key2":
                    case "btn_num_key3":
                    case "btn_num_key4":
                    case "btn_num_key5":
                    case "btn_num_key6":
                    case "btn_num_key7":
                    case "btn_num_key8":
                    case "btn_num_key9":
                        var _num = fn(id);
                        var _result = this.prnCntManager.insertNum(_num);
                        BrowserExt.Beep(_result ? 0 : 1);
                        break;
                    case "btn_comeback_key":
                        var _result = this.prnCntManager.removeNum();
                        BrowserExt.Beep(_result ? 0 : 1);
                        break;
                    case "btn_start_key":
                        //인쇄매수 변경분 반영
                        this.docListManager.updateQuantity(this.updateQuantity, true);
                        //인쇄 가능여부 판단
                        var _lst = this.docListManager.getCheckedItems();
                        if(_lst.length>0){
                            //Run Job
                            BrowserExt.Beep(0);
                            Common.doJobStart(_lst);					
                        }
                        else{
                            BrowserExt.Beep(1);
                            
                        }
                        break;
                    case "btn_menu_key":
                        //リセットキー
                        BrowserExt.Beep(0);
                        //window.location.reload(true);
                        // Mantis No: 0000018
                        BrowserExt.SetScreenChange("allservice");
                        break;
                    case "btn_auth_key":
                        if(glbInfo.userInfo){
                            SSMILib.LogoutDev();
                        }else{
                            var result = EwbClass.sendKeyCode(137); // 인증화면 호출
                            if(!result){
                                WarnPopup._message = {title:Msg.WarnPopup.title, type:"logout", targetPage:true, message:Msg.errorMessage.ERRCODE013};
                                PageManager.changePage(WarnPopup,PageManager.type.NORMAL);
                            }
                        }
                        break;
                default:
                    BrowserExt.Beep(0);
                    break;
            }
            break;
        case "onhardkeydown":
            MessageManager.clearMessageArea();
            switch (id) {
                case BrowserExt.keyCode.FX_VK_0:
                case BrowserExt.keyCode.FX_VK_1:
                case BrowserExt.keyCode.FX_VK_2:
                case BrowserExt.keyCode.FX_VK_3:
                case BrowserExt.keyCode.FX_VK_4:
                case BrowserExt.keyCode.FX_VK_5:
                case BrowserExt.keyCode.FX_VK_6:
                case BrowserExt.keyCode.FX_VK_7:
                case BrowserExt.keyCode.FX_VK_8:
                case BrowserExt.keyCode.FX_VK_9:
                    var _num = id - BrowserExt.keyCode.FX_VK_0;
                    var _result = this.prnCntManager.insertNum(_num);
                    BrowserExt.Beep(_result ? 0 : 1);
                    break;
                    //case BrowserExt.keyCode.FX_VK_MULTIPLY://*
                    //case BrowserExt.keyCode.FX_VK_NUMBER://#
                case BrowserExt.keyCode.FX_VK_BACK_SPACE:
                    var _result = this.prnCntManager.removeNum();
                    BrowserExt.Beep(_result ? 0 : 1);
                    break;
                case BrowserExt.keyCode.FX_VK_START:
                    if (WebServiceLib.getActiveRequestCount() != 0) {
                        BrowserExt.Beep(1);
                        KISUtil.debug("[job return]", "getActiveRequestCount()=" + WebServiceLib.getActiveRequestCount());
                        return;
                    }
                    //인쇄매수 변경분 반영
                    this.docListManager.updateQuantity(this.updateQuantity, true);
                    //인쇄 가능여부 판단
                    var _lst = this.docListManager.getCheckedItems();
                    if (_lst.length > 0) {
                        //프린트버튼의 상태가 disable일때는 인쇄하지 않도록 처리
                        if (!WidgetLib.getWidgetStatus("btn_FL_Print").enable) { //FileListPage.prnCntManager.getEnableFlag()
                            BrowserExt.Beep(1);
                        } else {
                            //Run Job
                            BrowserExt.Beep(0);
                            Common.doJobStart(_lst);
                        }
                    } else {
                        BrowserExt.Beep(1);
                    }
                    break;
                case BrowserExt.keyCode.FX_VK_CLEAR:
                    //リセットキー
                    BrowserExt.Beep(0);
                    //window.location.reload(true);
                    // Mantis No: 0000018
                    BrowserExt.SetScreenChange("allservice");
                    break;
                case BrowserExt.keyCode.FX_VK_PAUSE:
                    break;
                default:
                    BrowserExt.Beep(1);
                    break;
            }
            break;
        default:
            break;
    }
};

FileListPage.getSelectedListByLength = function(cnt) {
    var _selectedList = [];
    for (var i = 0; i < cnt; i++) {
        _selectedList[i] = i;
    }

    return _selectedList;
};

FileListPage.getSelectedListByUseYnFlag = function() //2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
    {
        var _selectedList = [];
        var idx = 0;
        for (var i = 0; i < glbDataSet.docList.length; i++) {
            if (glbDataSet.docList[i].useYn == false) {
                _selectedList[idx++] = i;
            }
        }

        return _selectedList;
    };

/**
 * 화면하단? 리스트내? 인쇄매수 표시갱신 및 입력 Flag변경
 */
FileListPage.updateQuantity = function(_target, _flg) {
    _target.printCnt = FileListPage.prnCntManager.currentNum;
    //페이지 전환 이외의 조작의경우
    //페이지 전환이후에도 이어지는 입력이 가능하도록 Flag를 초기화 하지 않음
    if (_flg) {
        FileListPage.prnCntManager.insertFlg = false;
    }
};

/**
 * 파일리스트페이지용 HTML구성
 */
FileListPage._createHtml = function() {
    createFileListPageHtml();
};

/**
 * 선택된 파일 개수 표시갱신
 */
FileListPage.updateDisplaySelectedFileCount = function() {
    var _str = this.getSelectedCount() + "/" + this.getAllCount();
    Common.setText("txt_FL_SelectedFile", _str);
};

/**
 * 현재 페이지 표시갱신
 */
FileListPage.updateDisplayCurrentPage = function() {
    if (this.getTotalPages() > 0) {
        var _str = (this.currentPageIdx) + "/" + this.getTotalPages();
        Common.setText("txt_FL_CurrentPage", _str);
    } else {
        Common.setText("txt_FL_CurrentPage", "");
    }
};

/**
 * 인쇄매수 표시갱신
 */
FileListPage.updateDisplayPrintQuantity = function(num) {
    Common.setText("txt_FL_PrintQuantity", num);
};

/**
 * 표시 갱신 버튼, 표시문서 종류별 풀다운 동작 처리
 */
FileListPage.refreshStoredDocument = function() //2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
    {
        this.docListManager.clearDataSouce(); //기존 데이터 삭제
        if (glbDbmEnable) {
            glbDbm.getDocList();
        } else {
            FileListPage.getServerStoredDocument();
        }
    };

//2017.11 KIS [v1.5] 개인프린트를 즉시출력, 선택출력에 포함 refs #4498
FileListPage.getServerStoredDocument = function() {
    //2017.11 KIS [v1.5] SmartUI 복수의 Print Server 대응 refs #4502
    for (var i = 0; i < glbInfo.SERVER_NUM; i++) {
        var plpObj = new SSMILib.PrnListPolicy();
        plpObj.userId = glbInfo.userInfo.RelatedUserID;
        plpObj.deviceIp = glbInfo.ipAddress;
        plpObj.wsIp = glbConfig.wsIp[i];
        SSMILib.GetPrnListPolicy(plpObj, DOC_PRINT_TIMEOUT, glbConfig.DATA.SERVER_URL[i]);
    }
};

/**
 * 문서 리스트 화면의 총 페이지수 취득
 * @return 총 페이지수
 */
FileListPage.getFileListTotalPage = function() {
    return Math.ceil(glbDevInfo.docList.length / MAX_FILE_BTN_NUM);
};

/**
 * 문서 선택 버튼의 표시 내용의 Clear
 * @param num : Button ID
 */
FileListPage.clearFileButton = function(id) {
    Common.setText(id + "_name", "");
    Common.setText(id + "_date", "");
    Common.setText(id + "_time", "");
    Common.setText(id + "_page", "");
    Common.setText(id + "_quantity", "");
    Common.setText(id + "_color", "");
    Common.setText(id + "_plex", "");
    Common.setText(id + "_nup", "");
    Common.setText(id + "_finisher", "");
};

/**
 * 정보 취득중 화면시에 선택 문서수의 표시 처리
 */
FileListPage.displayFileSelectedNumLoading = function() {
    Common.setText("txt_FL_SelectedFile", "0");
};
