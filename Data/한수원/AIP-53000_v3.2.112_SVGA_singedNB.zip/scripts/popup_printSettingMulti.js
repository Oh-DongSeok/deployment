﻿/**
 * 개별 페이지의 표시 및 동작 확인용 （프린트 설정 팝업 - 다수 문서 선택시)
 */
var PrintSettingMultiPopup = new TemplatePage();

PrintSettingMultiPopup.ID = "pop_printSettingMulti";
PrintSettingMultiPopup.key = "PSM";

PrintSettingMultiPopup._initModel = function()
{
	this.pullDownList = ["color", "plex"];
	this._data =
	{
		pulldownList:{
			common:{
				pullDown:{offImg:Img["PUL_PS_BASE_OFF"], pressImg:Img["PUL_PS_BASE_PRESS"], onImg:Img["PUL_PS_BASE_ON"], disableImg:Img["PUL_PS_BASE_DIS"]},
				popup:{top:Img["PUL_PS_POPUP_BG_TOP"], bg:Img["PUL_PS_POPUP_BG_MID"], bottom:Img["PUL_PS_POPUP_BG_BOT"]},
				btn:{offImg:Img["BTN_PS_BASE_OFF"], pressImg:Img["BTN_PS_BASE_PRESS"], onImg:Img["BTN_PS_BASE_ON"], disableImg:Img["BTN_PS_BASE_DIS"]}
			},
			list:[
				{pageKey:"PSM", key:"color", value:[
					{//기본값//2017.11.17 KIS [삼정회계법인] 선택 출력의 프린트 설정 일괄 변경 기능 추가 - 변경 refs #4429
						icon:{off:Img["ICN_CHECK_MULTI"], dis:Img["ICN_CHECK_MULTI"]},
						text:Msg.PrintSettingMultiPopup.DEFAULT_VALUE,
						value:JFLib.DEFAULT
					},
					{//COLOR
						icon:{off:Img["ICN_PS_CM_COLOR_OFF"], dis:Img["ICN_PS_CM_COLOR_DIS"]},
						text:Msg.PrintSettingPopup.COLORMODE_COLOR,
						value:	JFLib.CM.COLOR
					},
					{//GRAYSCALE
						icon:{off:Img["ICN_PS_CM_GRAY_OFF"], dis:Img["ICN_PS_CM_GRAY_DIS"]},
						text:Msg.PrintSettingPopup.COLORMODE_BW,
						value:	JFLib.CM.GRAY
					}
				]},
				{pageKey:"PSM", key:"plex", value:[
					{//기본값
						icon:{off:Img["ICN_CHECK_MULTI"], dis:Img["ICN_CHECK_MULTI"]},
						text:Msg.PrintSettingMultiPopup.DEFAULT_VALUE,
						value:JFLib.DEFAULT
					},
					{//단면
						icon:{off:Img["ICN_PS_PLEX_SIMPLEX_OFF"], dis:Img["ICN_PS_PLEX_SIMPLEX_DIS"]},
						text:Msg.PrintSettingPopup.OUTPLEX_SIMPLEX,
						value:	JFLib.PLEX.SIMPLEX
					},
					{//양면 (좌우열기)
						icon:{off:Img["ICN_PS_PLEX_DUPLEX_OFF"], dis:Img["ICN_PS_PLEX_DUPLEX_DIS"]},
						text:Msg.PrintSettingPopup.OUTPLEX_DUPLEX,
						value:	JFLib.PLEX.DUPLEX
					},
					{//양면 (상하열기)
						icon:{off:Img["ICN_PS_PLEX_TUMBLE_OFF"], dis:Img["ICN_PS_PLEX_TUMBLE_DIS"]},
						text:Msg.PrintSettingPopup.OUTPLEX_TUMBLE,
						value:	JFLib.PLEX.TUMBLE
					}
				]}
			]
		},

		buttonList:[
			{id:"btn_PSM_confirm", type:WidgetLib.ButtonType.NORMAL, attr:{targetImgId:"img_PSM_confirm",	offImg:Img["BTN_CONFIRM_OFF"], pressImg:Img["BTN_CONFIRM_PRESS"], disableImg:Img["BTN_CONFIRM_DIS"]}},
			{id:"btn_PSM_cancel", type:WidgetLib.ButtonType.NORMAL, attr:{targetImgId:"img_PSM_cancel", offImg:Img["BTN_CANCEL_OFF"], pressImg:Img["BTN_CANCEL_PRESS"], disableImg:Img["BTN_CANCEL_DIS"]}},
			{id:"btn_PSM_infoUp", type:WidgetLib.ButtonType.NORMAL, attr:{offImg:Img["IMG_PS_INFOUP_OFF"], pressImg:Img["IMG_PS_INFOUP_PRESS"], disableImg:Img["IMG_PS_INFOUP_DIS"]}},
			{id:"btn_PSM_infoDown", type:WidgetLib.ButtonType.NORMAL, attr:{offImg:Img["IMG_PS_INFODOWN_OFF"], pressImg:Img["IMG_PS_INFODOWN_PRESS"], disableImg:Img["IMG_PS_INFODOWN_DIS"]}},
			{id:"btn_PSM_print", type:WidgetLib.ButtonType.NORMAL, attr:{targetImgId:"img_PSM_print", offImg:Img["IMG_PS_PRINT_OFF"], pressImg:Img["IMG_PS_PRINT_PRESS"], disableImg:Img["IMG_PS_PRINT_DIS"]}}
		],

		imageList:[
			{id:"img_PSM_bg", src:Img.IMG_PS_BG},
			{id:"icn_PSM_title", src:Img.ICN_PS_TITLE},
			{id:"icn_PSM_color", src:Img.ICN_PS_CM_COLOR_OFF},
			{id:"icn_PSM_plex", src:Img.ICN_PS_PLEX_SIMPLEX_OFF},
			{id:"bg_PSM_infoDisplay", src:Img.BG_PS_INFODISPLAY},
			{id:"icn_PSM_infoDisplay", src:Img.ICN_PS_INFODISPLAY},
			{id:"img_PSM_printQuantity", src:Img.TEXT_INPUT_BOX_ENABLE}
		],

		textList:[
			{id:"lbl_PSM_title", text:Msg.PrintSettingPopup.TITLE},
			{id:"lbl_PSM_confirm", text:Msg.PrintSettingPopup.CONFIRM_BTN_LABEL},
			{id:"lbl_PSM_cancel", text:Msg.PrintSettingPopup.CANCEL_BTN_LABEL},
			{id:"tit_PSM_printQuantity", text:Msg.PrintSettingPopup.PRINT_QUANTITY_LABEL},
			{id:"lbl_PSM_printQuantityUnit", text:Msg.UNIT.PRN_SET},
			{id:"lbl_PSM_print", text:Msg.PrintSettingPopup.PRINT},
			{id:"tit_PSM_color", text:Msg.PrintSettingPopup.COLORMODE_LABEL},
			{id:"tit_PSM_plex",	text:Msg.PrintSettingPopup.OUTPLEX_LABEL}
		]
	};

	this.prnCntManager = new PrintCountManager(); 
	this.prnCntManager.updateDisplay = this.updateDisplayPrintQuantity;	
	this.validator = new ValidatorMulti();
	this.validator.init();
};

/**
 * 개별 페이지 고유의 항목을 구성
 */
PrintSettingMultiPopup._initOthers = function()
{
	this._initPullDown(this.key);
};

PrintSettingMultiPopup._onPageChange = function()
{
	MessageManager.clearMessageArea();
	this.prnCntManager.setNum(Msg.PrintSettingMultiPopup.DEFAULT_VALUE);
	if(!this._dataSet.selectedDocInfo){
		this._dataSet.selectedDocInfo = {};
	}
	this._dataSet.selectedDocInfo.multicolorIdx = 0;//2017.11.17 KIS [삼정회계법인] 선택 출력의 프린트 설정 일괄 변경 기능 추가 - 변경 refs #4429
	this._dataSet.selectedDocInfo.multiplexIdx = 0;
	this.updateWidgetStatus();
	this.updateDisplay();
};

PrintSettingMultiPopup._getCurrentPolicy = function()
{
	var _docs = FileListPage.docListManager.getCheckedItems(),
		_forcedBlack = glbDataSet.userPolicyInfo.forcedBlack?1:0,
		_forcedNup = glbDataSet.userPolicyInfo.forced2Up?1:0,
		_forcedDuplex = glbDataSet.userPolicyInfo.forcedDuplex?1:0,
		_functionCtrl = parseInt(glbDataSet.userPolicyInfo.functionCtrl);
	var _policy = this.validator.getBtnStatusByPolicy(_functionCtrl, _forcedNup,_forcedDuplex, _forcedBlack, _docs);	
	return _policy;
};

/**
 * prnType에 따른 버튼 상태변경 + 
 * 강제 2up, 컬러금지, 양면강제 등의 복합기 제약조건에 따른 버튼의 상태변경 
 * -세부 아이콘과 라벨의 처리는 어떻게 해야할까?
 */
PrintSettingMultiPopup.updateWidgetStatus = function()
{
	var forceBlack = glbDataSet.userPolicyInfo.forcedBlack,
		forceDuplex = glbDataSet.userPolicyInfo.forcedDuplex;
	
	//컬러 모드 풀다운 강제흑백, 기본 흑백 처리
	WidgetLib.setWidgetStatus("pul_PSM_color", {enable:true});
	if(glbDataSet.userPolicyInfo.defaultBlack){//기본 흑백이 true
		//선택된 문서들이 다 흑백 문서일 때 컬러모드 풀다운 disable
		//선택된 문서 중에 컬러 문서가 있으면 컬러모드 풀다운 enable
		WidgetLib.setWidgetStatus("pul_PSM_color", {enable:FileListPage.docListManager.isExistColorDocInSelectedDocs()});
	}else{
		if(glbDataSet.userPolicyInfo.forcedBlack){
			WidgetLib.setWidgetStatus("pul_PSM_color", {enable:false});
		}
	}

	//양/단면 풀다운, 강제 양면 적용시 단면선택 불가로 설정
	WidgetLib.setWidgetStatus("pul_PSM_plex", {enable:true});
	if(glbDataSet.userPolicyInfo.forcedDuplex){
		WidgetLib.setWidgetStatus("btn_PSM_plex_menu_1", {enable:false});
	}

	WidgetLib.setWidgetStatus("btn_PSM_print",{enable:true});
	var _policy = this._getCurrentPolicy();
	if(_policy.success && _policy.status.msg != ""){
		//MessageManager.displayMessage(MessageManager.MessageType.CONFLICT, "", Msg.errorMessage[_policy.status.msg]);//2017.11.17 KIS [삼정회계법인] 선택 출력의 프린트 설정 일괄 변경 기능 추가 - 변경 refs #4429
		WidgetLib.setWidgetStatus("btn_PSM_print",{enable:_policy.status.printStatus});
	}

	this.prnCntManager.setStatus(true);
};

/**
 * 화면 표시의 갱신 (공통/화면전환시 호출된다.)
 */
PrintSettingMultiPopup.updateDisplay = function()
{
	Common.setImage("img_PSM_printQuantity", Img.TEXT_INPUT_BOX_ENABLE);
	Common.setText("lbl_PSM_guide", (Msg.PrintSettingMultiPopup.GUIDE).replace(/XX/, FileListPage.docListManager.getSelectedCount()));
	WidgetLib.setWidgetStatus("btn_PSM_infoUp", {enable:false}); 
	WidgetLib.setWidgetStatus("btn_PSM_infoDown", {enable:false});

	//2017.11.17 KIS [삼정회계법인] 선택 출력의 프린트 설정 일괄 변경 기능 추가 - 변경 refs #4429 Start
	for(var i = 0, il = this._data.pulldownList.list.length; i < il; i++){//풀다운 버튼 - [기본값]으로 설정
		var lst = this._data.pulldownList.list[i];
		Common.setImage("icn_PSM_" + lst.key, lst.value[0].icon.off);
		Common.setText("lbl_PSM_" + lst.key, lst.value[0].text);
		WidgetLib.setWidgetStatus("pul_PSM_" + lst.key, {on:false});
	}

	//ColorMode
	/*
	var lst = this._data.pulldownList.list[0];
	Common.setImage("icn_PSM_" + lst.key, lst.value[1].icon.off);
	Common.setText("lbl_PSM_" + lst.key, lst.value[1].text);
	WidgetLib.setWidgetStatus("pul_PSM_" + lst.key, {on:false});
	*/

	//OutPlex
	lst = this._data.pulldownList.list[1];
	Common.setImage("icn_PSM_" + lst.key, lst.value[0].icon.off);
	Common.setText("lbl_PSM_" + lst.key, lst.value[0].text);
	WidgetLib.setWidgetStatus("pul_PSM_" + lst.key, {on:false});
	//2017.11.17 KIS [삼정회계법인] 선택 출력의 프린트 설정 일괄 변경 기능 추가 - 변경 refs #4429 End
};

PrintSettingMultiPopup.updateDisplayPrintQuantity = function(num)
{
	Common.setText("lbl_PSM_printQuantity", num);
};

/**
 * 프린트 설정 변경 또는 프린트 지시시에 설정 변경 대상이 되는 문서(선택한 문서중에 private print 문서는 제외)를 취득함
 */
PrintSettingMultiPopup.getChangeableDocs = function()
{
	var result = [];
	var lst = FileListPage.docListManager.getCheckedItems();
	for(var i = 0; i < lst.length; i++) {
		if(typeof lst[i].boxId == 'undefined'){//undefined는 서버 격납 문서, private print 문서는 boxId 값이 유효함.
			result.push(lst[i]);
        }
    }
	return result;
};

PrintSettingMultiPopup.displayPullMenuPopup = function(pk, idx)
{
	var key = this.pullDownList[idx];
	var pullIdx = this._dataSet.selectedDocInfo['multi' + key + "Idx"];
	this.updatePullMenuPopup(pk, key, pullIdx, (glbInfo[key].length + 1));
	Common.changeVisibility("pul_"+ pk + "_" + key + "_popup", "block");
};

PrintSettingMultiPopup.updatePullMenuPopup = function(pk, key, idx, length)
{
	for(var i=0; i<length; i++){
		WidgetLib.setWidgetStatus(("btn_" + pk + "_" + key + "_menu_" + i), {on:(i == idx)});
	}
};

PrintSettingMultiPopup.updatePulldown = function(pk, type, _data)
{
	var key = this.pullDownList[type];
	if(_data == null){_data=this._dataSet;}
	var idx = _data['multi' + key + "Idx"];
	if(idx < 0){
		KISUtil.debug("invalid DataType/" + key, _data[key]);
	}else{
		var lst = this._data.pulldownList.list[type];
		Common.setImage("icn_" + pk + "_" + lst.key, lst.value[idx].icon.off);
		Common.setText("lbl_" + pk + "_" + lst.key, lst.value[idx].text);
		WidgetLib.setWidgetStatus("pul_" + pk + "_" + key, {on:false});
	}
};

/**
 * 선택된 문서들의 설정 항목값을 변경함(프린트 설정 변경 화면 내에서만 유효하게 변경됨, 전역으로 변경시 confirm(설정) 버튼 클릭 필요)
 */
PrintSettingMultiPopup.getSettingChangedDocs = function()
{
	var lst = this.getChangeableDocs();
	for(var i=0; i<lst.length; i++){
		if(this.prnCntManager.currentNum != Msg.PrintSettingMultiPopup.DEFAULT_VALUE){
			lst[i].printCnt = this.prnCntManager.currentNum;
		}

		//2017.11.17 KIS [삼정회계법인] 선택 출력의 프린트 설정 일괄 변경 기능 추가 - 변경 refs #4429 Start
		if(this._dataSet.selectedDocInfo.multicolorIdx > 0){
			var tmpIdx = this._dataSet.selectedDocInfo.multicolorIdx - 1;
			if((lst[i]['originColorIdx'] == 0 || tmpIdx == 1) && (lst[i]['colorIdx'] != tmpIdx)){//[컬러->흑백] 변경, [컬러->컬러, 흑백->흑백, 흑백->컬러]의 경우 변경하지 않음
				lst[i].colorIdx = tmpIdx;
			}
		}

		/*
		var tmpIdx = this._dataSet.selectedDocInfo.multicolorIdx;
		if((lst[i]['originColorIdx'] == 0 || tmpIdx == 1) && (lst[i]['colorIdx'] != tmpIdx)){//[컬러->흑백] 변경, [컬러->컬러, 흑백->흑백, 흑백->컬러]의 경우 변경하지 않음
			lst[i].colorIdx = tmpIdx;
		}
		*/
		//2017.11.17 KIS [삼정회계법인] 선택 출력의 프린트 설정 일괄 변경 기능 추가 - 변경 refs #4429 End

		if(this._dataSet.selectedDocInfo.multiplexIdx > 0){
			lst[i].plexIdx = this._dataSet.selectedDocInfo.multiplexIdx - 1;
		}
	}
	return lst;
};

/**
 * 설정 버튼 눌렀을 경우 변경 사항을 적용.
 */
PrintSettingMultiPopup.confirmChangeSetting = function(key)
{
	var originArr = this._dataSet.docList;
	var changeArr = this.getSettingChangedDocs();
	for(var i=0, iMax=changeArr.length; i<iMax; i++){
		for(var j=0, jMax=originArr.length; j<jMax; j++){
			if(changeArr[i].UUID == originArr[j].UUID){
				extendDeep(changeArr[i], originArr[j]);
				break;
			}
		}
	}
};

PrintSettingMultiPopup.displayChangeSettingMsg = function(key)
{
	var lst = FileListPage.docListManager.getCheckedItems();
	var len = lst.length;
	var unChangeCount = 0;
	var msg = null;

	//2017.11.17 KIS [삼정회계법인] 선택 출력의 프린트 설정 일괄 변경 기능 추가 - 변경 refs #4429
	if((key == 'plex' && this._dataSet.selectedDocInfo['multi' + key + 'Idx'] == 0) || (key == 'printCnt' && this.prnCntManager.currentNum == Msg.PrintSettingMultiPopup.DEFAULT_VALUE)){
		msg = PrintSettingMultiPopup.constructMessage(JFLib.DEFAULT, key, null);
	}else{
		for(var i = 0; i < lst.length; i++) {
			if(typeof lst[i].boxId == 'undefined'){
				if(key == 'printCnt'){
					if(lst[i][key] == this.prnCntManager.currentNum){
						unChangeCount++;
					}
				}else{
					//2017.11.17 KIS [삼정회계법인] 선택 출력의 프린트 설정 일괄 변경 기능 추가 - 변경 refs #4429
					var tmpIdx = (key == 'plex' ? ((this._dataSet.selectedDocInfo['multi' + key + 'Idx']) - 1) : (this._dataSet.selectedDocInfo['multi' + key + 'Idx']));
					if(key == 'color' && lst[i]['originColorIdx'] == 1 && tmpIdx == 0){//문서 원본이 흑백인데 컬러로 변경시에는 흑백으로 출력되므로 컬러 변경하지 않음.
						unChangeCount++;
					}else{	
						if(lst[i][key + 'Idx'] == tmpIdx){
							unChangeCount++;
						}
					}
				}
	        }else{
	        	unChangeCount++;
	        }
	    }

		msg = PrintSettingMultiPopup.constructMessage("", key, {len : len, unChangeCount : unChangeCount});
	}

	MessageManager.displayMessage(MessageManager.MessageType.USER_ACTION_REQUIRED, "", msg);
};

PrintSettingMultiPopup.constructMessage = function(type, key, obj)
{
	var msg = [];
/*
	if(type == JFLib.DEFAULT){
		var itemName = (key == 'printCnt') ? Msg.PrintSettingMultiPopup.PRINT_QUANTITY_LABEL : ((key == 'color') ? Msg.PrintSettingMultiPopup.COLORMODE_LABEL : Msg.PrintSettingMultiPopup.OUTPLEX_LABEL);
		msg.push((Msg.PrintSettingMultiPopup.CHANGE_DEFAULT).replace(/##/, itemName));
	}else{
		var len = obj.len, unChangeCount = obj.unChangeCount;
		var msgOrign = ((key == 'color' && this._dataSet.selectedDocInfo['multi' + key + 'Idx'] == 1) || key == 'printCnt') ? Msg.PrintSettingMultiPopup.CHANGE_CUIDE_2 : Msg.PrintSettingMultiPopup.CHANGE_CUIDE; 
		var tmp = (msgOrign).replace(/XX/, (len - unChangeCount));
		var value = (key == 'printCnt') ? (this.prnCntManager.currentNum + Msg.UNIT.PRN_SET) : this._data.pulldownList.list[((key == 'color') ? 0 : 1)].value[this._dataSet.selectedDocInfo['multi' + key + 'Idx']].text;
		tmp = tmp.replace(/YY/, value);
		var itemName = (key == 'printCnt') ? Msg.PrintSettingMultiPopup.PRINT_QUANTITY_LABEL : ((key == 'color') ? Msg.PrintSettingMultiPopup.COLORMODE_LABEL : Msg.PrintSettingMultiPopup.OUTPLEX_LABEL);
		tmp = tmp.replace(/##/, itemName);
		msg.push(tmp);
		if(unChangeCount > 0){
			tmp = (Msg.PrintSettingMultiPopup.UNCHANGE_CUIDE).replace(/XX/, unChangeCount);
			if(key == 'plex' && (this._dataSet.selectedDocInfo['multi' + key + 'Idx'] > 1)){//양면 프린트 - (양면좌우, 양면상하)의 경우 문자열이 세로폭을 초과하므로 조정함.
				tmp = msg.pop() + " " + tmp;
			}
			msg.push(tmp);
		}
	}
*/
	// KPMG 고객사의 요청에 따른 변경(변경이 안되는 건수에 대한 설명은 필요없음.)
	if(type == JFLib.DEFAULT){
		var itemName = (key == 'printCnt') ? Msg.PrintSettingMultiPopup.PRINT_QUANTITY_LABEL : ((key == 'color') ? Msg.PrintSettingMultiPopup.COLORMODE_LABEL : Msg.PrintSettingMultiPopup.OUTPLEX_LABEL);
		msg.push((Msg.PrintSettingMultiPopup.CHANGE_DEFAULT).replace(/##/, itemName));
	}else{
		var len = obj.len, unChangeCount = obj.unChangeCount;
		var msgOrign = ((key == 'color' && this._dataSet.selectedDocInfo['multi' + key + 'Idx'] == 1) || key == 'printCnt') ? Msg.PrintSettingMultiPopup.CHANGE_CUIDE_2 : Msg.PrintSettingMultiPopup.CHANGE_CUIDE; 
		var tmp = (msgOrign).replace(/XX/, (len));
		var value = (key == 'printCnt') ? (this.prnCntManager.currentNum + Msg.UNIT.PRN_SET) : this._data.pulldownList.list[((key == 'color') ? 0 : 1)].value[this._dataSet.selectedDocInfo['multi' + key + 'Idx']].text;
		tmp = tmp.replace(/YY/, value);
		var itemName = (key == 'printCnt') ? Msg.PrintSettingMultiPopup.PRINT_QUANTITY_LABEL : ((key == 'color') ? Msg.PrintSettingMultiPopup.COLORMODE_LABEL : Msg.PrintSettingMultiPopup.OUTPLEX_LABEL);
		tmp = tmp.replace(/##/, itemName);
		msg.push(tmp);
	}
	return msg;
};

/**
 * 개별 페이지의 Event처리
 * @param {string} event : Event의 종류
 * @param {string} id : Event의 발생원
 */
PrintSettingMultiPopup.EventHandler = function(event, id)
{
	switch(event){
		case "onbuttonup":
			switch(id){
				case "btn_PSM_confirm":
					BrowserExt.Beep(0);
					this.confirmChangeSetting();
					delete this._dataSet.selectedDocInfo;
					PageManager.changePage(FileListPage, PageManager.type.CONFIRM);
					break;
				case "btn_PSM_cancel":
					BrowserExt.Beep(0);
					delete this._dataSet.selectedDocInfo;
					PageManager.changePage(FileListPage, PageManager.type.CANCEL);
					break;
				case "btn_PSM_color_menu_0":
				case "btn_PSM_color_menu_1":
				case "btn_PSM_color_menu_2":
					BrowserExt.Beep(0);
					this._dataSet.selectedDocInfo.multicolorIdx = Common.getIdx(id);
					//인쇄 가능여부 판단
					var _policy = this._getCurrentPolicy();
					WidgetLib.setWidgetStatus("btn_PSM_print", {enable:_policy.status.printStatus});
					PrintSettingMultiPopup.displayChangeSettingMsg('color');
					break;
				case "btn_PSM_plex_menu_0":
				case "btn_PSM_plex_menu_1":
				case "btn_PSM_plex_menu_2":
				case "btn_PSM_plex_menu_3":
					BrowserExt.Beep(0);
					this._dataSet.selectedDocInfo.multiplexIdx = Common.getIdx(id);
					PrintSettingMultiPopup.displayChangeSettingMsg('plex');
					break;
				case "btn_PSM_print":
					if(WebServiceLib.getActiveRequestCount() != 0){
						BrowserExt.Beep(1);
						KISUtil.debug("[job return]", "getActiveRequestCount()=" + WebServiceLib.getActiveRequestCount());
						return;
					}

					var _policy = this._getCurrentPolicy();
					if(_policy.success && _policy.status.msg != "") MessageManager.displayMessage(MessageManager.MessageType.CONFLICT, "", Msg.errorMessage[_policy.status.msg]);
					WidgetLib.setWidgetStatus("btn_PSM_print",{enable:_policy.status.printStatus});

					if(_policy.status.printStatus){	//인쇄가능
						BrowserExt.Beep(0);
						var _lst = PrintSettingMultiPopup.getSettingChangedDocs();
						Common.doJobStart(_lst);
					}
					break;
				case "pul_PSM_color":
				case "pul_PSM_nup":
				case "pul_PSM_plex":
					break;
				case "btn_num_key0":
				case "btn_num_key1":
				case "btn_num_key2":
				case "btn_num_key3":
				case "btn_num_key4":
				case "btn_num_key5":
				case "btn_num_key6":
				case "btn_num_key7":
				case "btn_num_key8":
				case "btn_num_key9":
					var _num = fn(id);
					var _result = this.prnCntManager.insertNum(_num);
					BrowserExt.Beep(_result?0:1);
					break;
				case "btn_comeback_key":
					var _result = this.prnCntManager.removeNum();
					BrowserExt.Beep(_result ? 0 : 1);
					break;
				case "btn_start_key":
					this.updateQuantity(this._dataSet.selectedDocInfo);
					var _policy = this._getCurrentPolicy();
					if(!_policy.status.printStatus){
						BrowserExt.Beep(1);
					}
					else if(WebServiceLib.getActiveRequestCount() != 0){
						BrowserExt.Beep(1);
						KISUtil.debug("[job return]","getActiveRequestCount()=" + WebServiceLib.getActiveRequestCount());
					}
					else{
						BrowserExt.Beep(0);
						var _lst = [this._dataSet.selectedDocInfo];
						//Run Job
						Common.doJobStart(_lst);
					}
					break;
				case "btn_menu_key":
					//リセットキー
					BrowserExt.Beep(0);
					//window.location.reload(true);
					// Mantis No: 0000018
					BrowserExt.SetScreenChange("allservice");
					break;
				case "btn_auth_key":
					if(glbInfo.userInfo){
						SSMILib.LogoutDev();
					}else{
						var result = EwbClass.sendKeyCode(137); // 인증화면 호출
						if(!result){
							WarnPopup._message = {title:Msg.WarnPopup.title, type:"logout", targetPage:true, message:Msg.errorMessage.ERRCODE013};
							PageManager.changePage(WarnPopup,PageManager.type.NORMAL);
						}
					}
					break;
				default:
					BrowserExt.Beep(0);
					break;
			}
			break;
		case "onpopupopen":
			switch(id){
				case "pul_PSM_color_popup":
					this.displayPullMenuPopup(this.key, 0);
					BrowserExt.Beep(0);
					break;
				case "pul_PSM_plex_popup":
					this.displayPullMenuPopup(this.key, 1);
					BrowserExt.Beep(0);
					break;
				default:
					break;
			}
			break;
		case "onpopupclose":
			switch(id){
				case "pul_PSM_color_popup":
					this.updatePulldown("PSM", 0, this._dataSet.selectedDocInfo);
					break;
				case "pul_PSM_plex_popup":
					this.updatePulldown("PSM", 1, this._dataSet.selectedDocInfo);
					break;
				default:
					break;
			}
			break;
		case "onhardkeydown":
			switch(id){
				case BrowserExt.keyCode.FX_VK_0:
				case BrowserExt.keyCode.FX_VK_1:
				case BrowserExt.keyCode.FX_VK_2:
				case BrowserExt.keyCode.FX_VK_3:
				case BrowserExt.keyCode.FX_VK_4:
				case BrowserExt.keyCode.FX_VK_5:
				case BrowserExt.keyCode.FX_VK_6:
				case BrowserExt.keyCode.FX_VK_7:
				case BrowserExt.keyCode.FX_VK_8:
				case BrowserExt.keyCode.FX_VK_9:
					var _num = id-BrowserExt.keyCode.FX_VK_0;
					var _result = this.prnCntManager.insertNum(_num);
					BrowserExt.Beep(_result ? 0 : 1);
					PrintSettingMultiPopup.displayChangeSettingMsg('printCnt');
					break;
				case BrowserExt.keyCode.FX_VK_BACK_SPACE:
					this.prnCntManager.setNum(Msg.PrintSettingMultiPopup.DEFAULT_VALUE);
					PrintSettingMultiPopup.displayChangeSettingMsg('printCnt');
					BrowserExt.Beep(0);
					break;
				case BrowserExt.keyCode.FX_VK_START:
					this.EventHandler("onbuttonup", "btn_PSM_print");
					break;
				case BrowserExt.keyCode.FX_VK_CLEAR://リセットキー
					BrowserExt.Beep(0);
					BrowserExt.SetScreenChange("allservice");
					break;
				case BrowserExt.keyCode.FX_VK_PAUSE:
					break;
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		default:
			break;
	}
};

PrintSettingMultiPopup.updateQuantity = function(_target)
{
	_target.printCnt = this.prnCntManager.currentNum;
	this.prnCntManager.insertFlg = false;
};

/**
 * 풀다운 닫기 처리용 메소드
 * templatePage.js로부터 이동
 */
PrintSettingMultiPopup.onPageClick = function()
{
	switch(WidgetLib._popupId){
		case "pul_PSM_color_popup":
		case "pul_PSM_plex_popup":
			WidgetLib.closePopupWidget(WidgetLib._popupId);
			break;
		default:
			break;
	}
};