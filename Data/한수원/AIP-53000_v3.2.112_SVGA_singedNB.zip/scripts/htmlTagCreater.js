/**
 * File List 화면의 HTML Tag생성
 */
function createFileListPageHtml()
{
	var body =document.body;

	var fileListPag = document.createElement("div");
	fileListPag.setAttribute("id", "page_FileList");
	fileListPag.setAttribute("class", "page");

	body.appendChild(fileListPag);

	//Message표시 영역
	var flMsgArea = document.createElement("div");
	flMsgArea.setAttribute("id", "lyr_FL_Msg_Area");
	var flMsgAreaChild = document.createElement("div");
	flMsgAreaChild.setAttribute("id", "txt_FL_Msg0");
	flMsgArea.appendChild(flMsgAreaChild);
	flMsgAreaChild = document.createElement("div");
	flMsgAreaChild.setAttribute("id", "txt_FL_Msg1");
	flMsgArea.appendChild(flMsgAreaChild);
	
	flMsgAreaChild = document.createElement("div");
	flMsgAreaChild.setAttribute("id", "btn_FL_PrintAll");
	var _img = document.createElement("img");					//버튼 이미지
	_img.setAttribute("id", "img_FL_PrintAll");
	_img.setAttribute("class", "img");
	flMsgAreaChild.appendChild(_img);
	var _lbl = document.createElement("div");					//버튼라벨
	_lbl.setAttribute("id", "lbl_FL_PrintAll");
	_lbl.setAttribute("class", "lbl");
	flMsgAreaChild.appendChild(_lbl);
	flMsgArea.appendChild(flMsgAreaChild);
	fileListPag.appendChild(flMsgArea);

	var flSelectdLbl = document.createElement("div");
	flSelectdLbl.setAttribute("id", "lbl_FL_SelectedFile");
	fileListPag.appendChild(flSelectdLbl);

	var flSelectdTxt = document.createElement("div");
	flSelectdTxt.setAttribute("id", "txt_FL_SelectedFile");
	fileListPag.appendChild(flSelectdTxt);

	var flRmvLbl = document.createElement("div");
	flRmvLbl.setAttribute("id", "lbl_FL_RmvFileAfterPrint");
	fileListPag.appendChild(flRmvLbl);

	var flBtnRefresh = document.createElement("div");
	flBtnRefresh.setAttribute("id", "btn_FL_Refresh");
	flBtnRefresh.setAttribute("class", "btn");
	var flBtnRefreshChild = document.createElement("img");
	flBtnRefreshChild.setAttribute("id", "img_FL_Refresh");
	flBtnRefresh.appendChild(flBtnRefreshChild);
	flBtnRefreshChild = document.createElement("div");
	flBtnRefreshChild.setAttribute("id", "lbl_FL_Refresh");
	flBtnRefreshChild.setAttribute("class", "lbl");
	flBtnRefresh.appendChild(flBtnRefreshChild);
	fileListPag.appendChild(flBtnRefresh);

	var flDisplayArea = document.createElement("div");
	flDisplayArea.setAttribute("id", "lyr_FL_Display_Area");
	flDisplayArea.setAttribute("class", "loading");
	fileListPag.appendChild(flDisplayArea);

	//Loading Message
	for(var i=0; i<5; i++){
		var flNotifyMsg = document.createElement("div");
		flNotifyMsg.setAttribute("id", "txt_FL_NotifyMsg" + i);
		flNotifyMsg.setAttribute("class", "txt_FL_NotifyMsg");
		flDisplayArea.appendChild(flNotifyMsg);
	}

	var flPage =  document.createElement("img");
	flPage.setAttribute("id", "btn_FL_pageUp");
	fileListPag.appendChild(flPage);
	flPage =  document.createElement("div");
	flPage.setAttribute("id", "txt_FL_CurrentPage");
	fileListPag.appendChild(flPage);
	flPage =  document.createElement("img");
	flPage.setAttribute("id", "btn_FL_pageDown");
	fileListPag.appendChild(flPage);

	var flSelecAll = document.createElement("div");
	flSelecAll.setAttribute("id", "btn_FL_SelectAll");
	flSelecAll.setAttribute("class", "btn");
	var flSelecAllChild = document.createElement("img");
	flSelecAllChild.setAttribute("id", "img_FL_SelectAll");
	flSelecAll.appendChild(flSelecAllChild);
	flSelecAllChild = document.createElement("div");
	flSelecAllChild.setAttribute("id", "lbl_FL_SelectAll0");
	flSelecAllChild.setAttribute("class", "lbl");
	flSelecAll.appendChild(flSelecAllChild);
	flSelecAllChild = document.createElement("div");
	flSelecAllChild.setAttribute("id", "lbl_FL_SelectAll1");
	flSelecAllChild.setAttribute("class", "lbl");
	flSelecAll.appendChild(flSelecAllChild);
	fileListPag.appendChild(flSelecAll);

	var flDelete = document.createElement("div");
	flDelete.setAttribute("id", "btn_FL_DeleteFile");
	flDelete.setAttribute("class", "btn");
	flSelecAll.appendChild(flSelecAllChild);
	var flDeleteChild = document.createElement("img");
	flDeleteChild.setAttribute("id", "img_FL_DeleteFile");
	flDelete.appendChild(flDeleteChild);
	flDeleteChild = document.createElement("div");
	flDeleteChild.setAttribute("id", "lbl_FL_DeleteFile");
	flDeleteChild.setAttribute("class", "lbl");
	flDeleteChild.appendChild(flSelecAllChild);
	flDelete.appendChild(flDeleteChild);
	fileListPag.appendChild(flDelete);

	var flPrintQuantityWrapper = document.createElement("div");
	flPrintQuantityWrapper.setAttribute("id", "lyr_FL_PrintQuantity");
	var flPrintQuantity = document.createElement("img");
	flPrintQuantity.setAttribute("id", "img_FL_PrintQuantity");
	flPrintQuantityWrapper.appendChild(flPrintQuantity);
	flPrintQuantity = document.createElement("div");
	flPrintQuantity.setAttribute("id", "txt_FL_PrintQuantity");
	flPrintQuantityWrapper.appendChild(flPrintQuantity);
	flPrintQuantity = document.createElement("div");
	flPrintQuantity.setAttribute("id", "lbl_FL_PrintQuantity");
	flPrintQuantityWrapper.appendChild(flPrintQuantity);
	fileListPag.appendChild(flPrintQuantityWrapper);
	
	var flPrintSetting = document.createElement("div");
	flPrintSetting.setAttribute("id", "btn_FL_Modi_PrintSetting");
	flPrintSetting.setAttribute("class", "btn");
	var flPrintSettingChild = document.createElement("img");
	flPrintSettingChild.setAttribute("id", "img_FL_Modi_PrintSetting");
	flPrintSetting.appendChild(flPrintSettingChild);
	flPrintSettingChild = document.createElement("div");
	flPrintSettingChild.setAttribute("id", "lbl_FL_Modi_PrintSetting0");
	flPrintSettingChild.setAttribute("class", "lbl");
	flPrintSetting.appendChild(flPrintSettingChild);
	flPrintSettingChild = document.createElement("div");
	flPrintSettingChild.setAttribute("id", "lbl_FL_Modi_PrintSetting1");
	flPrintSettingChild.setAttribute("class", "lbl");
	flPrintSetting.appendChild(flPrintSettingChild);
	fileListPag.appendChild(flPrintSetting);

	var flPrint = document.createElement("div");
	flPrint.setAttribute("id", "btn_FL_Print");
	var _img = document.createElement("img");					//버튼 이미지
	_img.setAttribute("id", "img_FL_Print");
	_img.setAttribute("class", "img");
	flPrint.appendChild(_img);
	var _lbl = document.createElement("div");					//버튼라벨
	_lbl.setAttribute("id", "lbl_FL_Print");
	_lbl.setAttribute("class", "lbl");
	flPrint.appendChild(_lbl);
	fileListPag.appendChild(flPrint);
}