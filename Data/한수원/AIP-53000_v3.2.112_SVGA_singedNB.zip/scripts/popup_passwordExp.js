/**
 * 개별 페이지의 표시 및 동작용
 * （Password 기간만료 팝업)
 */
var PasswordExpPopup = new TemplatePage();

PasswordExpPopup.ID = "pop_passwordExp";

/**
 * 개별 페이지의 Data정의
 */
PasswordExpPopup._initModel = function()
{
	this._data =
	{
		buttonList:[
			{	//step01 확인버튼
				id:"btn_PE_step01_ok",
				type:WidgetLib.ButtonType.NORMAL,
				attr:{
					targetImgId:"img_PE_step01_ok",
					offImg: Img.BTN_CONFIRM_OFF,
					pressImg: Img.BTN_CONFIRM_PRESS
				}
			},
			{	//step01 취소버튼
				id:"btn_PE_step01_cancel",
				type:WidgetLib.ButtonType.NORMAL,
				attr:{
					targetImgId:"img_PE_step01_cancel",
					offImg: Img.BTN_CANCEL_OFF,
					pressImg: Img.BTN_CANCEL_PRESS
				}
			},
			{	//step02 확인버튼
				id:"btn_PE_step02_ok",
				type:WidgetLib.ButtonType.NORMAL,
				attr:{
					targetImgId:"img_PE_step02_ok",
					offImg: Img.BTN_CONFIRM_OFF,
					pressImg: Img.BTN_CONFIRM_PRESS
				}
			},
			{	//step02 취소버튼
				id:"btn_PE_step02_cancel",
				type:WidgetLib.ButtonType.NORMAL,
				attr:{
					targetImgId:"img_PE_step02_cancel",
					offImg: Img.BTN_CANCEL_OFF,
					pressImg: Img.BTN_CANCEL_PRESS
				}
			},
			{	//step03 확인버튼
				id:"btn_PE_step03_ok",
				type:WidgetLib.ButtonType.NORMAL,
				attr:{
					targetImgId:"img_PE_step03_ok",
					offImg: Img.BTN_CONFIRM_OFF,
					pressImg: Img.BTN_CONFIRM_PRESS
				}
			}
		],
		imageList:[
			{id:"img_PE_step01_bg",			src:Img.POPUP_BLUE_BACKGROUND_IMG},
			{id:"img_PE_step01_password", 	src:Img.IMG_PE_PASSWORD},
			{id:"img_PE_step02_bg",			src:Img.POPUP_BLUE_BACKGROUND_IMG},
			{id:"img_PE_step03_bg",			src:Img.POPUP_BLUE_BACKGROUND_IMG},
			{id:"img_PE_step03_password", 	src:Img.IMG_PE_PASSWORD},
		],
		textList:[
			{id:"lbl_PE_title",			text:Msg.PASSWORD_EXP.STEP1_TITLE},
			{id:"lbl_PE_step01_guide1",	text:""},
			//{id:"lbl_PE_step01_guide1",	text:""Msg.PASSWORD_EXP.STEP1_GUIDE1_1},
			{id:"lbl_PE_step01_guide2",	text:Msg.PASSWORD_EXP.STEP1_GUIDE2	},
			{id:"lbl_PE_step01_guide3",	text:Msg.PASSWORD_EXP.STEP1_GUIDE3	},
			{id:"lbl_PE_step01_ok",		text:Msg.PASSWORD_EXP.LBL_OK	},
			{id:"lbl_PE_step01_cancel",	text:Msg.PASSWORD_EXP.LBL_CANCEL	},
			{id:"lbl_PE_step02_guide1",	text:Msg.PASSWORD_EXP.STEP2_GUIDE1	},
			{id:"lbl_PE_step02_guide2",	text:Msg.PASSWORD_EXP.STEP2_GUIDE2	},
			{id:"lbl_PE_step02_pw_new",	text:Msg.PASSWORD_EXP.STEP2_PW_NEW},
			{id:"lbl_PE_step02_pw_chk",	text:Msg.PASSWORD_EXP.STEP2_PW_CHK},
			{id:"lbl_PE_step02_ok",		text:Msg.PASSWORD_EXP.LBL_OK	},
			{id:"lbl_PE_step02_cancel",	text:Msg.PASSWORD_EXP.LBL_CANCEL	},
			{id:"lbl_PE_step03_guide1",	text:Msg.PASSWORD_EXP.STEP3_GUIDE1	},
			{id:"lbl_PE_step03_guide2",	text:Msg.PASSWORD_EXP.STEP3_GUIDE2	},
			{id:"lbl_PE_step03_ok",		text:Msg.PASSWORD_EXP.LBL_OK	}
		]
	};
};

PasswordExpPopup._onPageChange=function(){
	this._dataSet.peStep = 0;
	// 기본표시: "사용자의 패스워드가 만료되었습니다."
	if(glbInfo.userInfo.dayPasswordExp > 0){	// 만료일이 0보다 큰경우
		// 표시: "사용자의 패스워드 만료까지 XX일 남았습니다."
		//Common.setText("lbl_PE_step01_guide1", (Msg.PASSWORD_EXP.STEP1_GUIDE1).replace(/XX/, glbInfo.userInfo.dayPasswordExp));
		Common.setText("lbl_PE_step01_guide1", "");
	}else{	// 0보다 같거나 값이 작은경우
		// 기본표시: "사용자의 패스워드가 만료되었습니다."
		if(glbInfo.userInfo.dayPasswordExp == -1){	// -1인 경우
			Common.setText("lbl_PE_step01_guide1", Msg.PASSWORD_EXP.STEP1_GUIDE1_2);	// "기본생성 패스워드를 사용중입니다."
			Common.setText("lbl_PE_step01_guide2", Msg.PASSWORD_EXP.STEP1_GUIDE2_1);	// "신규 패스워드로 변경해 주세요."
		}
	}

	//WidgetLib.setWidgetStatus("btn_PE_step02_ok",{enable:true});
	document.getElementById("lyr_PE_step01").className = "peWrapper focused";
	document.getElementById("lyr_PE_step01_guide").className = "peWrapper focused";
	this.updateDisplay();
};

/**
 * 화면 표시의 갱신 (공통/화면전환시에 호출된다.)
 */
PasswordExpPopup.updateDisplay=function(){
	KISUtil.debug("function:","PasswordExpPopup.updateDisplay");

};

/**
 * 개별 페이지의 Event처리
 * @param {string} event : Event의 종류
 * @param {string} id : Event의 발생원
 */
PasswordExpPopup.EventHandler = function(event, id)
{
	KISUtil.debug("EventHandler","event:"+event+"/id:"+id);
	switch(event){
		case "ChangePassword":
			// 같은 화면으로 돌아오므로 enable 해주어야 다시 사용이 가능함.
			WidgetLib.setWidgetStatus("btn_PE_step02_ok",{enable:true});
			var param = {title:Msg.WarnPopup.title, type:"logout", targetPage:true};
			param.message = Msg.errorMessage.ERRCODE000;
			if(flg_Dummy_Beep){
				arguments[1] = true;
			}
			if(arguments[1] == true){
				var response = arguments[2];
				if(flg_Dummy_Beep){
					var temp_result = {
						result : "success"
					}
					response = temp_result;
				}
				switch(response.result){
					case "DB_INSERT_FAIL":		// DB 장애
						param.message = Msg.errorMessage.ERRCODE029;
						break;
					case "BLANK_IDPW":
						param.message = Msg.errorMessage.ERRCODE030;
						break;
					case "USER_NOT_FOUND":
						param.message = Msg.errorMessage.ERRCODE028;
						break;
					case "NO_POLICY":			// 패스워드 이력정책 없음
						Common.setText("lbl_PE_step02_guide3", Msg.PASSWORD_EXP.FAIL_NO_POLICY);
						return;
					case "PASS_LENGTH_NOT128":	// 신규 패스워드 길이 오류
						Common.setText("lbl_PE_step02_guide3", Msg.PASSWORD_EXP.FAIL_PASS_LENGTH_NOT128);
						return;
					case "PASS_HAS_HISTORY":	// 사용이력 있는 패스워드
						Common.setText("lbl_PE_step02_guide3", Msg.PASSWORD_EXP.FAIL_PASS_HAS_HISTORY);
						return;
					case "PASS_SAME_CURRENT":	// 기존/신규 패스워드 동일
						Common.setText("lbl_PE_step02_guide3", Msg.PASSWORD_EXP.FAIL_PASS_SAME_CURRENT);
						return;
					case "ETC":
						param.message = Msg.errorMessage.ERRCODE029;
						break;
					case "success":
					default:
						//if success
						//goto next Step
						document.getElementById("lyr_PE_step02").className = "peWrapper";
						document.getElementById("lyr_PE_step03").className = "peWrapper focused";
						this._dataSet.peStep++;
						return;
				}
			}
			WarnPopup._message = param;
			PageManager.changePage(WarnPopup,PageManager.type.NORMAL);
			break;
		case "onbuttonup":
			MessageManager.clearMessageArea();
			BrowserExt.Beep(0);
			switch(id)
			{
				case "btn_PE_step01_ok":
					document.getElementById("lyr_PE_step01").className = "peWrapper";
					document.getElementById("lyr_PE_step02").className = "peWrapper focused";
					Common.setText("lbl_PE_step02_guide1", (Msg.PASSWORD_EXP.STEP2_GUIDE1).replace(/XXX/, glbInfo.userInfo.RelatedUserID));
					Common.setText("lbl_PE_step02_guide4", noticePasswordPolicy());
					this._dataSet.peStep++;
					break;
				case "btn_PE_step01_cancel":
					glbInfo.passwordExpChk = true;
					if((glbInfo.userInfo.availLoginExp == "N")&&(glbInfo.userInfo.dayPasswordExp < 1)){
						var param = {title:Msg.WarnPopup.title, type:"logout", targetPage:true};
						param.message = Msg.errorMessage.ERRCODE031;
						WarnPopup._message = param;
						PageManager.changePage(WarnPopup,PageManager.type.NORMAL);
					}else{
						PageManager.changePage(MenuPage, PageManager.type.NORMAL);
						currentPage = PageManager.getCurrentPage();
						currentPage.updateDefaultBtnStatus();
						currentPage.EventHandler(arguments[0], arguments[1], arguments[2]);
					}
					break;
				case "btn_PE_step02_ok":
					var _pw_new = document.getElementById('tbx_PE_step02_pw_new').value;
					var _pw_chk = document.getElementById('tbx_PE_step02_pw_chk').value;
					var chk_message = " ";
					if(_pw_new.length > 30){
						Common.setText("lbl_PE_step02_guide3", Msg.PASSWORD_EXP.STEP2_GUIDE3_1);
						return;
					}
					// Password 정책에 따른 확인
					switch(checkPasswordPolicy(_pw_new)){
						case "FAIL_SPACE":			// 공백이 있는 경우
							Common.setText("lbl_PE_step02_guide3", Msg.PASSWORD_EXP.FAIL_SPACE);
							return;
						case "FAIL_CAPITAL_CHAR":	// 대문자가 없는 경우
							Common.setText("lbl_PE_step02_guide3", (Msg.PASSWORD_EXP.FAIL_CAPITAL_CHAR).replace(/XX/, glbInfo.userInfo.passwordPolicy.neededCapitalCharCnt));
							return;
						case "FAIL_DIGIT":			// 숫자가 없는 경우
							Common.setText("lbl_PE_step02_guide3", (Msg.PASSWORD_EXP.FAIL_DIGIT).replace(/XX/, glbInfo.userInfo.passwordPolicy.neededDigitCnt));
							return;
						case "FAIL_SPECIAL_CHAR":	// 특수문자가 없는 경우
							Common.setText("lbl_PE_step02_guide3", (Msg.PASSWORD_EXP.FAIL_SPECIAL_CHAR).replace(/XX/, glbInfo.userInfo.passwordPolicy.neededSpecialCharCnt));
							return;
						case "FAIL_MIN_LENGTH":		// 최소 자리수 부족
							Common.setText("lbl_PE_step02_guide3", (Msg.PASSWORD_EXP.FAIL_MIN_LENGTH).replace(/XX/, glbInfo.userInfo.passwordPolicy.minPasswordCnt));
							return;
						case "FAIL_MAX_LENGTH":		// 최대 자리수 초과
							Common.setText("lbl_PE_step02_guide3", (Msg.PASSWORD_EXP.FAIL_MAX_LENGTH).replace(/XX/, glbInfo.userInfo.passwordPolicy.maxPasswordCnt));
							return;
						case "FAIL_INPUT_TEXT":		// 영문, 숫자, 특수문자 외의 문자열 포함하는 경우
							Common.setText("lbl_PE_step02_guide3", Msg.PASSWORD_EXP.FAIL_INPUT_TEXT);
							return;
						case "OK":
						default:
					}
					// 신규 패스워드 와 확인이 동일한지 판단
					if(_pw_new != _pw_chk){
						// 별도로 Warnning 화면으로 천이하지 않고 메시지 처리
						Common.setText("lbl_PE_step02_guide3", Msg.PASSWORD_EXP.STEP2_GUIDE3);
						return;
					}else{
						Common.setText("lbl_PE_step02_guide3", " ");
					}

					//send RegCard
					var changePasswordInfoObj = new SSMILib.ChangePasswordInfo();
					changePasswordInfoObj.userId = glbInfo.userInfo.RelatedUserID;
					//changePasswordInfoObj.userNewPw = hex_sha512(_pw_new).toString();
					// MD5
					changePasswordInfoObj.userNewPw = hex_md5(_pw_new);
					SSMILib.ChangePassword(changePasswordInfoObj, DOC_PRINT_TIMEOUT, glbConfig.DATA.SERVER_URL[0]);//SmartUI 2017.02 복수의 Print Server 대응 refs #4184

					//여러번 클릭에 따른 다중요청이 발생할 수 있음 회피 코드가 필요해보임
					WidgetLib.setWidgetStatus("btn_PE_step02_ok",{enable:false});
					break;
				case "btn_PE_step02_cancel":
					glbInfo.passwordExpChk = true;
					if((glbInfo.userInfo.availLoginExp == "N")&&(glbInfo.userInfo.dayPasswordExp < 1)){
						var param = {title:Msg.WarnPopup.title, type:"logout", targetPage:true};
						param.message = Msg.errorMessage.ERRCODE031;
						WarnPopup._message = param;
						PageManager.changePage(WarnPopup,PageManager.type.NORMAL);
					}else{
						PageManager.changePage(MenuPage, PageManager.type.NORMAL);
						currentPage = PageManager.getCurrentPage();
						currentPage.updateDefaultBtnStatus();
						currentPage.EventHandler(arguments[0], arguments[1], arguments[2]);
					}
					break;
				case "btn_PE_step03_ok":
					document.getElementById("lyr_PE_step03").className = "peWrapper";
					delete this._dataSet.peStep;
					SSMILib.LogoutDev();
					BrowserExt.SetScreenChange("allservice"); // 멈춤현상있음.
					break;
			}
			break;
		case "onhardkeydown":
			MessageManager.clearMessageArea();
			switch(id)
			{
				case BrowserExt.keyCode.FX_VK_CLEAR:
					//Reset Key
					BrowserExt.Beep(0);
					BrowserExt.SetScreenChange("allservice");
					break;
				case BrowserExt.keyCode.FX_VK_BACK_SPACE:
					BrowserExt.Beep(0);
					document.getElementById('tbx_PE_step02_pw_new').value = "";
					document.getElementById('tbx_PE_step02_pw_chk').value = "";
					break;
				case BrowserExt.keyCode.FX_VK_ENTER:
					// step을 확인할 수 없으므로 Enter key는 사용하지 않음.
					BrowserExt.Beep(1);
					break;
				case BrowserExt.keyCode.FX_VK_0:
				case BrowserExt.keyCode.FX_VK_1:
				case BrowserExt.keyCode.FX_VK_2:
				case BrowserExt.keyCode.FX_VK_3:
				case BrowserExt.keyCode.FX_VK_4:
				case BrowserExt.keyCode.FX_VK_5:
				case BrowserExt.keyCode.FX_VK_6:
				case BrowserExt.keyCode.FX_VK_7:
				case BrowserExt.keyCode.FX_VK_8:
				case BrowserExt.keyCode.FX_VK_9:
				case BrowserExt.keyCode.FX_VK_PAUSE:
					break;
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		default:
			break;
	}
};
