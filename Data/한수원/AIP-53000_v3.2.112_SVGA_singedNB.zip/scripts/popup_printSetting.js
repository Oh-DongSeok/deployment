﻿/**
 * 개별 페이지의 표시 및 동작 확인용
 * （프린트 설정 팝업)
 */
var PrintSettingPopup = new TemplatePage();

PrintSettingPopup.ID = "pop_printSetting";
PrintSettingPopup.key = "PS";

/**
 * 개별 페이지의 Data정의
 */
PrintSettingPopup._initModel = function()
{
	/**
	 * 풀다운 메뉴의 종류
	 */
	this.pullDownList = ["nup","color","plex"];
	this._data =
	{
		pulldownList:{
			common:{
				pullDown:{
					offImg:Img["PUL_PS_BASE_OFF"],
					pressImg:Img["PUL_PS_BASE_PRESS"],
					onImg:Img["PUL_PS_BASE_ON"],
					disableImg:Img["PUL_PS_BASE_DIS"]
				},
				popup:
				{
					top:Img["PUL_PS_POPUP_BG_TOP"],
					bg:Img["PUL_PS_POPUP_BG_MID"],
					bottom:Img["PUL_PS_POPUP_BG_BOT"]
				},
				btn:
				{
					offImg:Img["BTN_PS_BASE_OFF"],
					pressImg:Img["BTN_PS_BASE_PRESS"],
					onImg:Img["BTN_PS_BASE_ON"],
					disableImg:Img["BTN_PS_BASE_DIS"]
				}
			},
			list:[
				{pageKey:"PS", key:"nup",value:[
					{//1up
						icon:{off:Img["ICN_PS_NUP_1UP_OFF"], dis:Img["ICN_PS_NUP_1UP_DIS"]},
						text:Msg.PrintSettingPopup.NUP_1UP,
						value:	JFLib.NUPNUM.ONE
					},
					{//2up
						icon:{off:Img["ICN_PS_NUP_2UP_OFF"], dis:Img["ICN_PS_NUP_2UP_DIS"]},
						text:Msg.PrintSettingPopup.NUP_2UP,
						value:	JFLib.NUPNUM.TWO
					},					
					{//4up
						icon:{off:Img["ICN_PS_NUP_4UP_OFF"], dis:Img["ICN_PS_NUP_4UP_DIS"]},
						text:Msg.PrintSettingPopup.NUP_4UP,
						value:	JFLib.NUPNUM.FOUR
					},
					{//8up
						icon:{off:Img["ICN_PS_NUP_8UP_OFF"], dis:Img["ICN_PS_NUP_8UP_DIS"]},
						text:Msg.PrintSettingPopup.NUP_8UP,
						value:	JFLib.NUPNUM.EIGHT
					},
					{//16up
						icon:{off:Img["ICN_PS_NUP_16UP_OFF"], dis:Img["ICN_PS_NUP_16UP_DIS"]},
						text:Msg.PrintSettingPopup.NUP_16UP,
						value:	"16"//JFLib.NUPNUM.SEVENTEEN
					},
					{//32up
						icon:{off:Img["ICN_PS_NUP_32UP_OFF"], dis:Img["ICN_PS_NUP_32UP_DIS"]},
						text:Msg.PrintSettingPopup.NUP_32UP,
						value:	"32"//JFLib.NUPNUM.THIRTYTWO
					}
				]},
				{pageKey:"PS", key:"color", value:[
					{//COLOR
						icon:{off:Img["ICN_PS_CM_COLOR_OFF"], dis:Img["ICN_PS_CM_COLOR_DIS"]},
						text:Msg.PrintSettingPopup.COLORMODE_COLOR,
						value:	JFLib.CM.COLOR
					},
					{//GRAYSCALE
						icon:{off:Img["ICN_PS_CM_GRAY_OFF"], dis:Img["ICN_PS_CM_GRAY_DIS"]},
						text:Msg.PrintSettingPopup.COLORMODE_BW,
						value:	JFLib.CM.GRAY
					}
				]},
				{pageKey:"PS", key:"plex", value:[
					{//단면
						icon:{off:Img["ICN_PS_PLEX_SIMPLEX_OFF"], dis:Img["ICN_PS_PLEX_SIMPLEX_DIS"]},
						text:Msg.PrintSettingPopup.OUTPLEX_SIMPLEX,
						value:	JFLib.PLEX.SIMPLEX
					},
					{//양면 (좌우열기)
						icon:{off:Img["ICN_PS_PLEX_DUPLEX_OFF"], dis:Img["ICN_PS_PLEX_DUPLEX_DIS"]},
						text:Msg.PrintSettingPopup.OUTPLEX_DUPLEX,
						value:	JFLib.PLEX.DUPLEX
					},
					{//양면 (상하열기)
						icon:{off:Img["ICN_PS_PLEX_TUMBLE_OFF"], dis:Img["ICN_PS_PLEX_TUMBLE_DIS"]},
						text:Msg.PrintSettingPopup.OUTPLEX_TUMBLE,
						value:	JFLib.PLEX.TUMBLE
					}
				]}
			]
		},
		buttonList:[
			{id:"btn_PS_confirm",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PS_confirm",	offImg:Img["BTN_CONFIRM_OFF"],	pressImg:Img["BTN_CONFIRM_PRESS"],	disableImg:Img["BTN_CONFIRM_DIS"]	}	},
			{id:"btn_PS_cancel",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PS_cancel",	offImg:Img["BTN_CANCEL_OFF"],	pressImg:Img["BTN_CANCEL_PRESS"],	disableImg:Img["BTN_CANCEL_DIS"]	}	},
			/*{id:"pul_PS_color",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PS_color",	offImg:Img["PUL_PS_COLORMODE0_OFF"],	pressImg:Img["PUL_PS_COLORMODE0_PRESS"],	onImg:Img["PUL_PS_COLORMODE0_ON"]	}	},
			{id:"btn_PS_color0",	type:WidgetLib.ButtonType.RADIO,	attr:{	targetImgId:"img_PS_color0",	offImg:Img["IMG_PS_COLORMODE0_OFF"],	pressImg:Img["IMG_PS_COLORMODE0_PRESS"],	onImg:Img["IMG_PS_COLORMODE0_ON"], groupId:"btn_PS_color"	}	},
			{id:"btn_PS_color1",	type:WidgetLib.ButtonType.RADIO,	attr:{	targetImgId:"img_PS_color1",	offImg:Img["IMG_PS_COLORMODE1_OFF"],	pressImg:Img["IMG_PS_COLORMODE1_PRESS"],	onImg:Img["IMG_PS_COLORMODE1_ON"], groupId:"btn_PS_color"	}	},
			{id:"pul_PS_plex",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PS_plex",	offImg:Img["PUL_PS_OUTPLEX0_OFF"],	pressImg:Img["PUL_PS_OUTPLEX0_PRESS"],	onImg:Img["PUL_PS_OUTPLEX0_ON"]	}	},
			{id:"btn_PS_plex0",	type:WidgetLib.ButtonType.RADIO,	attr:{	targetImgId:"img_PS_plex0",	offImg:Img["IMG_PS_OUTPLEX0_OFF"],	pressImg:Img["IMG_PS_OUTPLEX0_PRESS"],	onImg:Img["IMG_PS_OUTPLEX0_ON"], groupId:"btn_PS_plex"	}	},
			{id:"btn_PS_plex1",	type:WidgetLib.ButtonType.RADIO,	attr:{	targetImgId:"img_PS_plex1",	offImg:Img["IMG_PS_OUTPLEX1_OFF"],	pressImg:Img["IMG_PS_OUTPLEX1_PRESS"],	onImg:Img["IMG_PS_OUTPLEX1_ON"], groupId:"btn_PS_plex"	}	},
			{id:"btn_PS_plex2",	type:WidgetLib.ButtonType.RADIO,	attr:{	targetImgId:"img_PS_plex2",	offImg:Img["IMG_PS_OUTPLEX2_OFF"],	pressImg:Img["IMG_PS_OUTPLEX2_PRESS"],	onImg:Img["IMG_PS_OUTPLEX2_ON"], groupId:"btn_PS_plex"	}	},
			{id:"pul_PS_nup",	type:WidgetLib.ButtonType.NORMAL,	attr:{	targetImgId:"img_PS_nup",	offImg:Img["PUL_PS_NUP0_OFF"],	pressImg:Img["PUL_PS_NUP0_PRESS"],	onImg:Img["PUL_PS_NUP0_ON"]	}	},
			{id:"btn_PS_nup0",	type:WidgetLib.ButtonType.RADIO,	attr:{	targetImgId:"img_PS_nup0",	offImg:Img["IMG_PS_NUP0_OFF"],	pressImg:Img["IMG_PS_NUP0_PRESS"],	onImg:Img["IMG_PS_NUP0_ON"], groupId:"btn_PS_nup"}	},
			{id:"btn_PS_nup1",	type:WidgetLib.ButtonType.RADIO,	attr:{	targetImgId:"img_PS_nup1",	offImg:Img["IMG_PS_NUP1_OFF"],	pressImg:Img["IMG_PS_NUP1_PRESS"],	onImg:Img["IMG_PS_NUP1_ON"], groupId:"btn_PS_nup"}	},
			{id:"btn_PS_nup2",	type:WidgetLib.ButtonType.RADIO,	attr:{	targetImgId:"img_PS_nup2",	offImg:Img["IMG_PS_NUP2_OFF"],	pressImg:Img["IMG_PS_NUP2_PRESS"],	onImg:Img["IMG_PS_NUP2_ON"], groupId:"btn_PS_nup"}	},
			{id:"btn_PS_nup3",	type:WidgetLib.ButtonType.RADIO,	attr:{	targetImgId:"img_PS_nup3",	offImg:Img["IMG_PS_NUP3_OFF"],	pressImg:Img["IMG_PS_NUP3_PRESS"], groupId:"btn_PS_nup"}	},
			*/
			{id:"btn_PS_infoUp", type:WidgetLib.ButtonType.NORMAL, attr:{ offImg:Img["IMG_PS_INFOUP_OFF"], pressImg:Img["IMG_PS_INFOUP_PRESS"], disableImg:Img["IMG_PS_INFOUP_DIS"]}},
			{id:"btn_PS_infoDown", type:WidgetLib.ButtonType.NORMAL, attr:{ offImg:Img["IMG_PS_INFODOWN_OFF"], pressImg:Img["IMG_PS_INFODOWN_PRESS"], disableImg:Img["IMG_PS_INFODOWN_DIS"]}},
			{id:"btn_PS_print", type:WidgetLib.ButtonType.NORMAL, attr:{ targetImgId:"img_PS_print",offImg:Img["IMG_PS_PRINT_OFF"], pressImg:Img["IMG_PS_PRINT_PRESS"],disableImg:Img["IMG_PS_PRINT_DIS"]}},
			{id:"cbx_PS_deleteAfterPrint", type:WidgetLib.ButtonType.TOGGLE, attr:{ offImg:Img["CBX_PS_AFTER_PRN_DELETE_OFF"], pressImg:Img["CBX_PS_AFTER_PRN_DELETE_PRESS"], onImg:Img["CBX_PS_AFTER_PRN_DELETE_ON"], disableImg:Img["CBX_PS_AFTER_PRN_DELETE_DIS"]}}
		],
		imageList:[
			{id:"img_PS_bg",	src:Img.IMG_PS_BG},
			{id:"icn_PS_title",	src:Img.ICN_PS_TITLE},
			{id:"icn_PS_color",	src:Img.ICN_PS_CM_COLOR_OFF},
			{id:"icn_PS_plex",	src:Img.ICN_PS_PLEX_SIMPLEX_OFF},
			{id:"icn_PS_nup",	src:Img.ICN_PS_NUP_1UP_OFF},
			{id:"bg_PS_infoDisplay",	src:Img.BG_PS_INFODISPLAY},
			{id:"icn_PS_infoDisplay",	src:Img.ICN_PS_INFODISPLAY},
			{id:"img_PS_printQuantity",	src:Img.TEXT_INPUT_BOX_ENABLE}
			
		],
		textList:[
			{id:"lbl_PS_title",		text:Msg.PrintSettingPopup.TITLE},					//프린트 설정 변경
			{id:"lbl_PS_confirm",	text:Msg.PrintSettingPopup.CONFIRM_BTN_LABEL},		//설정		//Msg.Common.lbl_confirm
			{id:"lbl_PS_cancel",	text:Msg.PrintSettingPopup.CANCEL_BTN_LABEL},		//취소		//Msg.Common.lbl_cancel
			{id:"tit_PS_jobName",	text:Msg.PrintSettingPopup.FILE_NAME_LABEL},		//문서명:
			{id:"tit_PS_jobRcvTime",	text:Msg.PrintSettingPopup.FILE_TIME_LABEL},    //수신일시:
			{id:"tit_PS_totalPage",	text:Msg.PrintSettingPopup.FILE_PAGE_LABEL},		//페이지수:
			{id:"tit_PS_printQuantity",	text:Msg.PrintSettingPopup.PRINT_QUANTITY_LABEL},    //프린트 부수:
			{id:"lbl_PS_printQuantityUnit",	text:Msg.UNIT.PRN_SET},    //프린트 부수:
			
			{id:"lbl_PS_print", text:Msg.PrintSettingPopup.PRINT},
			
			{id:"tit_PS_deleteAfterPrint",	text:Msg.PrintSettingPopup.DELETE_AFTER_PRINT},    //N-up:
			{id:"tit_PS_nup",	text:Msg.PrintSettingPopup.NUP_LABEL},    //N-up:
			{id:"tit_PS_color",	text:Msg.PrintSettingPopup.COLORMODE_LABEL},    //컬러모드:
			{id:"tit_PS_plex",	text:Msg.PrintSettingPopup.OUTPLEX_LABEL}    //양면 프린트:
		]
	};
	this.prnCntManager = new PrintCountManager(); 
	this.prnCntManager.updateDisplay = this.updateDisplayPrintQuantity;	
	this.validator = new Validator();
	this.validator.init();
};

/**
 * 개별 페이지 고유의 항목을 구성
 */
PrintSettingPopup._initOthers = function(){
	this._initPullDown(this.key);		//풀다운을 구성
	//유격생기는 이슈를 막기위해 추가
	var colorPulpopObj = WidgetLib.getWidgetNode("pul_PS_color_popup");
	var colorPulpopBody = colorPulpopObj.childNodes[2];
	//var colorPulpopObj = document.getElementById("lst_PS_color_popup");
	colorPulpopBody.style.width = "248px";
	colorPulpopBody.style.height = "92px";
};

PrintSettingPopup._onPageChange = function(){
	MessageManager.clearMessageArea();
	this.prnCntManager.setNum(this._dataSet.selectedDocInfo.printCnt);
	var _enableFlg = !this._dataSet.selectedDocInfo.prnType;
	this.updateWidgetStatus(_enableFlg);
	this.updateDisplay();
};

PrintSettingPopup._getCurrentPolicy = function(){
	var _doc = this._dataSet.selectedDocInfo,
		_forcedBlack = glbDataSet.userPolicyInfo.forcedBlack?1:0,
		_forcedNup = glbDataSet.userPolicyInfo.forced2Up?1:0,
		_forcedDuplex = glbDataSet.userPolicyInfo.forcedDuplex?1:0,
		_forbid = parseInt(glbDataSet.userPolicyInfo.functionCtrl);
	var _policy = this.validator.getBtnStatusByPolicy(_forbid, _forcedNup,_forcedDuplex, _forcedBlack, _doc);	
	return _policy;
};

/**
 * prnType에 따른 버튼 상태변경 + 
 * 강제 2up, 컬러금지, 양면강제 등의 복합기 제약조건에 따른 버튼의 상태변경 
 * -세부 아이콘과 라벨의 처리는 어떻게 해야할까?
 */
PrintSettingPopup.updateWidgetStatus = function(flag){
	//glbDataSet.userPolicyInfo.colorRestriction	
	var force2up = glbDataSet.userPolicyInfo.forced2Up,
		forceBlack = glbDataSet.userPolicyInfo.forcedBlack,
		forceDuplex = glbDataSet.userPolicyInfo.forcedDuplex;
		
	//MacOS 출력문서의 경우
	if(glbDataSet.selectedDocInfo.driverType == "MacOS"){
		WidgetLib.setWidgetStatus("btn_PS_nup_menu_3", {enable:true});	// 8up
		WidgetLib.setWidgetStatus("btn_PS_nup_menu_4", {enable:true});	// 16up
		WidgetLib.setWidgetStatus("btn_PS_nup_menu_5", {enable:false});	// 32up
	}
	//Mobile 출력문서의 경우
	if(glbDataSet.selectedDocInfo.driverType == "MOBILE"){
		WidgetLib.setWidgetStatus("btn_PS_nup_menu_3", {enable:false});	// 8up
		WidgetLib.setWidgetStatus("btn_PS_nup_menu_4", {enable:false});	// 16up
		WidgetLib.setWidgetStatus("btn_PS_nup_menu_5", {enable:false}); // 32up
	}
		
	//PS인경우 nup사용불가
	//강제2up 적용시 1up선택을 불가로 설정
	//WidgetLib.setWidgetStatus("pul_PS_nup", {enable:flag});					// AR대응 강제 Nup적용안됨의 건
	//if(flag) WidgetLib.setWidgetStatus("btn_PS_nup_menu_0", {enable:!force2up});
	if(flag) WidgetLib.setWidgetStatus("btn_PS_nup_menu_0", {enable:true});
	if(flag){
		//WidgetLib.setWidgetStatus("btn_PS_nup_menu_0", {enable:false});		// AR대응 강제 Nup적용안됨의 건
		if(glbDataSet.selectedDocInfo.originNupIdx > 0 && glbDataSet.selectedDocInfo.srcNupIdx != 0){		//2013/04/04 사양변경 대응
			WidgetLib.setWidgetStatus("pul_PS_nup", {enable:false});
		}
		else{
			WidgetLib.setWidgetStatus("pul_PS_nup", {enable:true});
		}
	}
	else {
		WidgetLib.setWidgetStatus("pul_PS_nup", {enable:flag});
		WidgetLib.setWidgetStatus("btn_PS_nup_menu_0", {enable:true});
	}
	
	//forceBlack
	if(flag){
		if(glbDataSet.userPolicyInfo.defaultBlack){
			if(glbDataSet.selectedDocInfo.originColorIdx==0){	// 컬러의 경우 Enable처리, AR대응 강제/기본 흑백 적용안됨의 건
				WidgetLib.setWidgetStatus("pul_PS_color", {enable:true});
			}else{												// 흑백의 경우 Disable처리, AR대응 강제/기본 흑백 적용안됨의 건
				WidgetLib.setWidgetStatus("pul_PS_color", {enable:false});
			}
		}
		else{
			//강제흑백 적용시 컬러선택을 불가로 설정
			if(!glbDataSet.userPolicyInfo.defaultBlack){
				WidgetLib.setWidgetStatus("pul_PS_color", {enable:flag&&!forceBlack&&(glbDataSet.selectedDocInfo.originColorIdx==0)});	//흑백의경우도 disable처리
			}else{
				if(glbDataSet.selectedDocInfo.originColorIdx==0){	// 컬러의 경우 Enable처리, AR대응 강제/기본 흑백 적용안됨의 건
					WidgetLib.setWidgetStatus("pul_PS_color", {enable:true});
				}else{												// 흑백의 경우 Disable처리, AR대응 강제/기본 흑백 적용안됨의 건
					WidgetLib.setWidgetStatus("pul_PS_color", {enable:false});
				}
			}
		}
	}

	//forceDuplex
	//양면 적용시 단면선택 불가로 설정
	WidgetLib.setWidgetStatus("pul_PS_plex", {enable:flag});
	if(flag){
		//양면
		if(glbDataSet.userPolicyInfo.forcedDuplex){
			//WidgetLib.setWidgetStatus("btn_PS_plex_menu_0", {enable:(glbDataSet.selectedDocInfo.originPlexIdx == 0 || !forceDuplex)});
			WidgetLib.setWidgetStatus("btn_PS_plex_menu_0", {enable:false});
		}
	}
	
	if(!flag){
		var attr = {};
	 	attr.disableImg = (this._dataSet.selectedDocInfo.deleteIdx==0)?Img.CBX_PS_AFTER_PRN_DELETE_ONDIS:Img.CBX_PS_AFTER_PRN_DELETE_DIS;
		WidgetLib.setWidgetAttr("cbx_PS_deleteAfterPrint", attr);
 	}
	WidgetLib.setWidgetStatus("cbx_PS_deleteAfterPrint",{enable:flag});

	Common.setImage("img_PS_printQuantity", flag?Img.TEXT_INPUT_BOX_ENABLE:Img.TEXT_INPUT_BOX_DIS);
	this.prnCntManager.setStatus(flag);

	var _policy = this._getCurrentPolicy();
	if(_policy.success && _policy.status.msg!=""){
		MessageManager.displayMessage(MessageManager.MessageType.CONFLICT, "", Msg.errorMessage[_policy.status.msg]);
		WidgetLib.setWidgetStatus("btn_PS_print",{enable:_policy.status.printStatus});
	} 
	/*WidgetLib.setWidgetStatus("btn_PS_print",{enable:!this._dataSet.selectedDocInfo.overFlow});
	MessageManager.displayMessage(MessageManager.MessageType.CONFLICT, "", Msg.errorMessage[_policy.status.msg]);
	//console.log(this._dataSet.selectedDocInfo.printInvalidType);
	item.availablePages*/
};

/**
 * 화면 표시의 갱신 (공통/화면전환시 호출된다.)
 */
PrintSettingPopup.updateDisplay = function(){
	KISUtil.debug("function:","updateDisplay");
	Common.setText("lbl_PS_jobName",this._dataSet.selectedDocInfo.docName);
	Common.setText("lbl_PS_jobRcvTime",this._dataSet.selectedDocInfo.printDate);
	Common.setText("lbl_PS_totalPage",this._dataSet.selectedDocInfo.pageCnt + Msg.PrintSettingPopup.PAGE_MSG);
	Common.setText("lbl_PS_printQuantity",this._dataSet.selectedDocInfo.printCnt);
	WidgetLib.setWidgetStatus("btn_PS_infoUp",{enable:false}); 
	WidgetLib.setWidgetStatus("btn_PS_infoDown",{enable:false}); 
	//0:nup
	//1:color
	//2:plex
	//풀다운 버튼의 갱신이 필요
	for(var i = 0, il = this._data.pulldownList.list.length; i < il; i++)
	{
		this.updatePulldown("PS", i,this._dataSet.selectedDocInfo);
	}
	WidgetLib.setWidgetStatus("cbx_PS_deleteAfterPrint",{on:this._dataSet.selectedDocInfo.deleteIdx==0});
};
/**
 * 
 */
PrintSettingPopup.updateDisplayPrintQuantity = function(num){
	Common.setText("lbl_PS_printQuantity",num);
};
/**
 * 
 */
PrintSettingPopup.updateByUUID = function(){
	//_dataSet,_data
	//, 
	var result = false;
	var _tmp;
	var _lst = this._dataSet.docList;//?glbDataSet.docList:this._dataSet.docList;
	for(var i = 0,iMax = _lst.length;i<iMax;i++){
		_tmp = _lst[i];
		if(_tmp.UUID == this._dataSet.selectedDocInfo.UUID){
			_tmp = extendDeep(this._dataSet.selectedDocInfo, _tmp);
			result = true;
			break;
		} 
	}
	return result;
};
/**
 * 개별 페이지의 Event처리
 * @param {string} event : Event의 종류
 * @param {string} id : Event의 발생원
 */
PrintSettingPopup.EventHandler = function(event, id)
{
	KISUtil.debug("EventHandler","event:"+event+"/id:"+id);
	switch(event){
		case "onbuttonup":
			//MessageManager.clearMessageArea();
			switch(id)
			{
				case "btn_PS_confirm":
					BrowserExt.Beep(0);
					this.updateQuantity(this._dataSet.selectedDocInfo);
					this.updateByUUID();
					//this.docListManager.updateSelectedDataSource(this._dataSet.selectedDocInfo);
					delete this._dataSet.selectedDocInfo;
					PageManager.changePage(FileListPage, PageManager.type.CONFIRM);
					break;
				case "btn_PS_cancel":
					BrowserExt.Beep(0);
					delete this._dataSet.selectedDocInfo;
					PageManager.changePage(FileListPage, PageManager.type.CANCEL);
					break;
				case "btn_PS_nup_menu_0":
				case "btn_PS_nup_menu_1":
				case "btn_PS_nup_menu_2":
				case "btn_PS_nup_menu_3":
				case "btn_PS_nup_menu_4":
				case "btn_PS_nup_menu_5":
					BrowserExt.Beep(0);
					//getIndex
					var idx = Common.getIdx(id);
					this._dataSet.selectedDocInfo.nupIdx=idx;
					break;
				case "btn_PS_color_menu_0":
				case "btn_PS_color_menu_1":
					BrowserExt.Beep(0);
					//getIndex
					var idx = Common.getIdx(id);
					this._dataSet.selectedDocInfo.colorIdx=idx;
					
					//인쇄 가능여부 판단
					var _policy = this._getCurrentPolicy();
					if(_policy.success && _policy.status.msg!="FORBID_COLOR"){
						MessageManager.displayMessage(MessageManager.MessageType.CONFLICT, "", Msg.errorMessage[_policy.status.msg]);
						WidgetLib.setWidgetStatus("btn_PS_print",{enable:_policy.status.printStatus});
					}else if(WidgetLib.getWidgetStatus("btn_PS_print").enable){
						MessageManager.displayMessage(MessageManager.MessageType.CONFLICT, "", Msg.errorMessage[_policy.status.msg]);
						WidgetLib.setWidgetStatus("btn_PS_print",{enable:_policy.status.printStatus});
					}
					break;
				case "btn_PS_plex_menu_0":
				case "btn_PS_plex_menu_1":
				case "btn_PS_plex_menu_2":
					BrowserExt.Beep(0);
					//getIndex
					var idx = Common.getIdx(id);
					this._dataSet.selectedDocInfo.plexIdx = idx;
					break;
				case "cbx_PS_deleteAfterPrint":
					BrowserExt.Beep(0);
					var status = WidgetLib.getWidgetStatus(id);
					this._dataSet.selectedDocInfo.deleteIdx = status.on ? 0 : 1;
					break;
				case "btn_PS_print":
					BrowserExt.Beep(0);
					this.updateQuantity(this._dataSet.selectedDocInfo);
					//인쇄 가능여부 판단
					var _policy = this._getCurrentPolicy();
					if(_policy.success && _policy.status.msg != "") MessageManager.displayMessage(MessageManager.MessageType.CONFLICT, "", Msg.errorMessage[_policy.status.msg]);
					WidgetLib.setWidgetStatus("btn_PS_print",{enable:_policy.status.printStatus});
					if(_policy.status.printStatus){	//현재문서가 인쇄가능인 경우
						var _lst = [this._dataSet.selectedDocInfo];
						//Run Job
						Common.doJobStart(_lst);
					}
					break;
				case "pul_PS_color":
					var _enableFlg = !this._dataSet.selectedDocInfo.prnType;
					this.updateWidgetStatus(_enableFlg);
				case "pul_PS_nup":
				case "pul_PS_plex":
					break;
				case "btn_num_key0":
				case "btn_num_key1":
				case "btn_num_key2":
				case "btn_num_key3":
				case "btn_num_key4":
				case "btn_num_key5":
				case "btn_num_key6":
				case "btn_num_key7":
				case "btn_num_key8":
				case "btn_num_key9":
					var _num = fn(id);
					var _result = this.prnCntManager.insertNum(_num);
					BrowserExt.Beep(_result?0:1);
					break;
				case "btn_comeback_key":
					var _result = this.prnCntManager.removeNum();
					BrowserExt.Beep(_result ? 0 : 1);
					break;
				case "btn_start_key":
					this.updateQuantity(this._dataSet.selectedDocInfo);
					var _policy = this._getCurrentPolicy();
					if(!_policy.status.printStatus){
						BrowserExt.Beep(1);
					}
					else if(WebServiceLib.getActiveRequestCount() != 0){
						BrowserExt.Beep(1);
						KISUtil.debug("[job return]","getActiveRequestCount()=" + WebServiceLib.getActiveRequestCount());
					}
					else{
						BrowserExt.Beep(0);
						var _lst = [this._dataSet.selectedDocInfo];
						//Run Job
						Common.doJobStart(_lst);
					}
					break;
				case "btn_menu_key":
					//リセットキー
					BrowserExt.Beep(0);
					//window.location.reload(true);
					// Mantis No: 0000018
					BrowserExt.SetScreenChange("allservice");
					break;
				case "btn_auth_key":
					if(glbInfo.userInfo){
						SSMILib.LogoutDev();
					}
					break;
				default:
					BrowserExt.Beep(0);
					//clearMessageAreaTimer();
					break;
			}
			break;
		case "onpopupopen":
			KISUtil.debug(event,id);
			switch(id)
			{
				case "pul_PS_nup_popup":
					this.displayPullMenuPopup(this.key, 0, this._dataSet.selectedDocInfo);
					BrowserExt.Beep(0);
					break;
				case "pul_PS_color_popup":
					this.displayPullMenuPopup(this.key, 1, this._dataSet.selectedDocInfo);	//color
					BrowserExt.Beep(0);
					break;
				case "pul_PS_plex_popup":
					this.displayPullMenuPopup(this.key, 2, this._dataSet.selectedDocInfo);
					BrowserExt.Beep(0);
					break;
				default:
					break;
			}
			break;
		case "onpopupclose":
			KISUtil.debug(event,id);
			switch(id)
			{
				case "pul_PS_nup_popup":
					this.updatePulldown("PS", 0, this._dataSet.selectedDocInfo);
					break;
				case "pul_PS_color_popup":
					this.updatePulldown("PS", 1, this._dataSet.selectedDocInfo);
					break;
				case "pul_PS_plex_popup":
					this.updatePulldown("PS", 2, this._dataSet.selectedDocInfo);
					break;
				default:
					break;
			}
			break;
		case "onhardkeydown":
			//MessageManager.clearMessageArea();
			switch(id)
			{
				case BrowserExt.keyCode.FX_VK_0:
				case BrowserExt.keyCode.FX_VK_1:
				case BrowserExt.keyCode.FX_VK_2:
				case BrowserExt.keyCode.FX_VK_3:
				case BrowserExt.keyCode.FX_VK_4:
				case BrowserExt.keyCode.FX_VK_5:
				case BrowserExt.keyCode.FX_VK_6:
				case BrowserExt.keyCode.FX_VK_7:
				case BrowserExt.keyCode.FX_VK_8:
				case BrowserExt.keyCode.FX_VK_9:
					var _num = id-BrowserExt.keyCode.FX_VK_0;
					var _result = this.prnCntManager.insertNum(_num);
					BrowserExt.Beep(_result?0:1);
					break;
				//case BrowserExt.keyCode.FX_VK_MULTIPLY://*
				//case BrowserExt.keyCode.FX_VK_NUMBER://#
				case BrowserExt.keyCode.FX_VK_BACK_SPACE:
					var _result = this.prnCntManager.removeNum();
					BrowserExt.Beep(_result?0:1);
					//PrintCountManager.clearNum();
					break;
				case BrowserExt.keyCode.FX_VK_START:
					this.updateQuantity(this._dataSet.selectedDocInfo);
					var _policy = this._getCurrentPolicy();
					if(!_policy.status.printStatus){
						BrowserExt.Beep(1);
					}
					else if(WebServiceLib.getActiveRequestCount() != 0){
						BrowserExt.Beep(1);
						KISUtil.debug("[job return]","getActiveRequestCount()=" + WebServiceLib.getActiveRequestCount());
					}
					else{
						BrowserExt.Beep(0);
						var _lst = [this._dataSet.selectedDocInfo];
						//Run Job
						Common.doJobStart(_lst);
					}
					break;
				case BrowserExt.keyCode.FX_VK_CLEAR:
					//リセットキー
					BrowserExt.Beep(0);
					//window.location.reload(true);
					// Mantis No: 0000018
					BrowserExt.SetScreenChange("allservice");
					break;
				case BrowserExt.keyCode.FX_VK_PAUSE:
					break;
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		default:
			break;
	}
};

PrintSettingPopup.updateQuantity = function(_target){
	_target.printCnt = this.prnCntManager.currentNum;
	this.prnCntManager.insertFlg = false;
};
/**
 * 풀다운 닫기 처리용 메소드
 * templatePage.js로부터 이동
 */
PrintSettingPopup.onPageClick = function(){
	switch(WidgetLib._popupId)
	{
		case "pul_PS_color_popup":
		case "pul_PS_plex_popup":
		case "pul_PS_nup_popup":
			WidgetLib.closePopupWidget(WidgetLib._popupId);
			//MessageManager.clearMessageArea();
			break;
		default:
			break;
	}
};