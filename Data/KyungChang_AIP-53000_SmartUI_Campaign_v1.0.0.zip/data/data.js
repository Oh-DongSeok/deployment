var DATA = {
	TITLE_NAME	: "Campaign app",
	
	DATA_TYPE	: "img",
	VIEW_TIME	: "5",
	VIEW_CHANGE	: "local",
	BTN_POSITION: "1",

	HTML_URL 	: "",
	IMG_URL		: ["", "", "", "", ""],
	SERVER_URL	: ""
};

/* EX)
   TITLE_NAME : "Campaign app", // 내부사용으로 변경 불필요
   DATA_TYPE  : "img", // "img" or "html" png 이미지 표시 모드
   VIEW_TIME  : "5",
   VIEW_CHANGE: "local", // "local" or "server" 설정값 내부/서버 설정용
   BTN_POSITION: "1", // "1" or "2" 시작버튼 좌우 설정

   HTML_URL 	: "web1", // 웹응용프로그램 호출
   IMG_URL 		: ["http://10.97.4.34/image/test01.png", "http://10.97.4.34/image/test02.png", "http://10.97.4.34/image/test03.png", "", ""], // 이미지주소 등록 최대 5개
   SERVER_URL	: "http://10.97.4.34/data/data.js" // 서버 설정시 설정 파일 주소
*/