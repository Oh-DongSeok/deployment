var Img = {
	/*
		File명은 모두 소문자로 작성합니다.
		(대소문자 구분에 따른 오류 방지.)
	*/
	MAIN_SETTING_BG				: "./image/setting.png",
	// OTID popup
	BG_OTID_POPUP				: "./image/IM_BK00_2.png",
	ICN_CF_CONFIRM_OFF			:"./image/BTN_SML_OFF.png",
	ICN_CF_CONFIRM_PRESS		:"./image/BTN_SML_PRESS.png",
	ICN_CF_CONFIRM_DIS			:"./image/BTN_SML_DIS.png",
	ICN_CF_CANCEL_OFF			:"./image/BTN_SML_OFF.png",
	ICN_CF_CANCEL_PRESS			:"./image/BTN_SML_PRESS.png",
	ICN_CF_CANCEL_DIS			:"./image/BTN_SML_DIS.png",
	// Number keypad
	BTN_SCK_NUM_PRESS			: "./image/btn_num_key_press.png",
	BTN_SCK_MUL_OFF				: "./image/btn_mul_key_off.png",
	BTN_SCK_SHARP_OFF			: "./image/btn_sharp_key_off.png",
	
};
