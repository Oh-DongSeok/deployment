/**
 * @fileoverview デバイスからTCP/IP情報を取得するためのクラス定義<br>
 * TCP/IP情報取得に関して以下のメソッドを提供する<br>
 * GetTcpIpInfo
 *
 * @author Copyright(C) 2021 FUJIFILM Business Innovation Corp. All rights reserved.<br>
 * @version 1.0.0
 * @lang ja
 */
/**
 * @fileoverview Defines classes for retrieving TCP/IP setting information from device. <br>
 * Provides the following methods for retrieving TCP/IP setting information.<br>
 * GetTcpIpInfo
 *
 * @author Copyright(C) 2021 FUJIFILM Business Innovation Corp. All rights reserved.<br>
 * @version 1.0.0
 * @lang en
 */

/**
 * TCP/IP設定の情報を取得する。<br>
 * 情報取得に成功すると、TCP/IP設定に関する情報をプロパティとしてもつオブジェクトが返される。<br>
 * プロパティ詳細については「01-02 SESAMi Service Management Interface Specification_Object.xls SSMI-0102」を参照
 * @addon
 * @static
 * @lang ja
 */
/**
 * Retrieves TCP/IP setting information.<br>
 * If retrieval is successful, object with TCP/IP setting information as properties is returned.<br>
 * See "01-02 SESAMi Service Management Interface Specification_Object.xls" for details.
 * @addon
 * @static
 * @lang en
 */
SSMILib.GetTcpIpInfo = function()
{
	var _obj = ["TCPIP"];
	var dev = new SSMILib.DeviceInfo(_obj, null);

	dev.requester.successHandler = SSMILib.GetTcpIpInfo.successCb;
	dev.requester.errorHandler = SSMILib.GetTcpIpInfo.errorCb;

	if (SSMILib.dummy) {
		/*
		<env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/">
  			<env:Body xmlns:xsd="http://www.w3.org/2000/10/XMLSchema">
  			  	<GetAttributeResponse xmlns="http://www.fujixerox.co.jp/2003/12/ssm/management/statusConfig">
  			  	  	<Object name="urn:fujixerox:names:ssm:1.0:management:TCPIP">
  			  	  	  	<Attribute name="AddressResolution" type="string">MANUAL</Attribute>
  			  	  	  	<Attribute name="IPAddress" type="string">192.168.0.200</Attribute>
  			  	  	  	<Attribute name="GatewayAddress" type="string">192.168.0.1</Attribute>
  			  	  	  	<Attribute name="SubnetMask" type="string">255.255.255.0</Attribute>
  			  	  	  	<Attribute name="DNSAutoConfig" type="boolean">false</Attribute>
  			  	  	  	<Attribute name="DomainName" type="string"/>
  			  	  	  	<Attribute name="DNSTimeOut" type="nonNegativeInteger">1</Attribute>
  			  	  	  	<Attribute name="DynamicDNS" type="boolean">false</Attribute>
  			  	  	  	<Attribute name="WINSAutoConfig" type="boolean">false</Attribute>
  			  	  	  	<Attribute name="PrimaryWINSServer" type="string">0.0.0.0</Attribute>
  			  	  	  	<Attribute name="SecondaryWINSServer" type="string">0.0.0.0</Attribute>
  			  	  	  	<Attribute name="IPAddressFiltering" type="boolean">false</Attribute>
  			  	  	  	<Attribute name="DNSManuallySearch" type="boolean">false</Attribute>
  			  	  	  	<Attribute name="HostName" type="string">FX-EF5486</Attribute>
  			  	  	  	<Attribute name="IPMode" type="string">IPv4</Attribute>
  			  	  	  	<Attribute name="IPsec" type="boolean">false</Attribute>
  			  	  	</Object>
  			  	</GetAttributeResponse>
  			</env:Body>
		</env:Envelope>
		*/
		var responseXML = new Array();
		responseXML["AddressResolution"] = "MANUAL";
		responseXML["IPAddress"] = "192.168.0.200";
		responseXML["GatewayAddress"] = "192.168.0.1";
		responseXML["SubnetMask"] = "255.255.255.0";
		responseXML["DNSAutoConfig"] = "false";
		responseXML["DomainName"] = "";
		responseXML["DNSTimeOut"] = "1";
		responseXML["DynamicDNS"] = "false";
		responseXML["WINSAutoConfig"] = "false";
		responseXML["PrimaryWINSServer"] = "0.0.0.0";
		responseXML["SecondaryWINSServer"] = "0.0.0.0";
		responseXML["IPAddressFiltering"] = "false";
		responseXML["DNSManuallySearch"] = "false";
		responseXML["HostName"] = "FX-EF5486";
		responseXML["IPMode"] = "IPv4";
		responseXML["IPsec"] = "false";

		SSMILib.onEvent("GetTcpIpInfo", true, responseXML);
		return;
	}

	dev.getDeviceInfo(true);
	return;
};

/**
 * @private
 */
SSMILib.GetTcpIpInfo.successCb = function(res)
{
	if(!res.responseXML) {
		SSMILib.onEvent("GetTcpIpInfo", false, null);
		return;
	}
	var _returnObj = SSMILib.attrNodeToObject(res.responseXML);

	if(_returnObj){
		var _result = true;
	} else {
		var _result = false;
	}
	SSMILib.onEvent("GetTcpIpInfo", _result, _returnObj);

	return;
};

/**
 * @private
 */
SSMILib.GetTcpIpInfo.errorCb = function(res)
{
	var _returnObj = null;

	SSMILib.onEvent("GetTcpIpInfo", false, _returnObj);

	return;
};
