var DATA = {
	TITLE_NAME	: "SK Campaign app",
	
	DATA_TYPE	: "img",
	VIEW_TIME	: "3",
	VIEW_CHANGE	: "7",
	VIEW_MODE	: "1",

	HTML_URL 	: "",
	IMG_URL 	: ["http://127.0.0.1:5502/images/top_ci.png", "http://10.97.4.104:5500/img/2nd.png"],
};

/** README 
 * 1. TITLE_NAME 	: 앱 이름
 * 2. DATA_TYPE 	: 데이터 타입 (html, img)
 * 3. VIEW_COUNT 	: 데이터 뷰 횟수
 * 4. VIEW_TIME 	: 데이터 뷰 시간 (초)
 * 5. VIEW_MODE 	: 데이터 뷰 모드 (1: 순차, 2: 무작위)
 * 6. HTML_URL 		: html 데이터 url
 * 7. IMG_URL 		: img 데이터 url
 *
 *---------------------------------------------------------*/