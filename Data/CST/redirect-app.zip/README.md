# Redirect App
기존 Custom Service를 Web Server로부터 불러오기 위한 App


## Getting started

To make it easy for you to get started with GitLab, here's a list of recommended next steps.

Already a pro? Just edit this README.md and make it your own. Want to make it easy? [Use the template at the bottom](#editing-this-readme)!

## Add your files

- [ ] [Create](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#create-a-file) or [upload](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#upload-a-file) files
- [ ] [Add files using the command line](https://docs.gitlab.com/ee/gitlab-basics/add-file.html#add-a-file-using-the-command-line) or push an existing Git repository with the following command:

```
cd existing_repo
git remote add origin https://flankerd.iptime.org/ohdongseok/redirect-app.git
git branch -M main
git push -uf origin main
```

## Description
SmartUI 또는 과금용 Custom Service의 개별대응 또는 디지털인증 불가 상태를 대비한 대응으로 안내또는 기본 페이지를 가지는 App을 제작하여 대응 예정.

## Visuals

## Installation

## License
Copyright(C) 2023 **FUJIFILM** Business Innovation Korea Co., Ltd. All rights reserved.

## Project status
진행중...