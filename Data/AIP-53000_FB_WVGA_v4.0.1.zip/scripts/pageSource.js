﻿var glbPageSource=[];
glbPageSource["page_waiting"]='';
glbPageSource["page_menu"]=
	'<img id="img_MP_bg" />' +
	'<img id="img_MP_logo" />' +
	'<img id="img_MP_top_banner" class="rcWrapper"/>' +
	'<div id="lyr_MP_policy" class="btn rcWrapper">' +
		'<img id="img_MP_policy" />' +
		'<div id="lbl_MP_policy" class="lbl"></div>' +
		'<div id="lbl_MP_policy2" class="lbl"></div>' +
	'</div>' +
	'<div id="btn_MP_login" class="btn">' +
		'<img src="" alt="" id="img_MP_login" class="btnBg" />' +
		'<div id="lbl_MP_login" class="lbl"></div>' +
	'</div>' +
	'<div id="btn_MP_logout" class="btn">' +
		'<img src="" alt="" id="img_MP_logout" class="btnBg" />' +
		'<div id="lbl_MP_logout" class="lbl"></div>' +
	'</div>' +
    //'<div id="lbl_MP_user" class="lbl"></div>' +
	'<div id="btn_MP_setting" class="btn" style="display:none;" >' +
		'<img src="" alt="" id="img_MP_setting" class="btnBg" />' +
		'<div id="lbl_MP_setting" class="lbl"></div>' +
	'</div>' +
	'<img id="btn_MP_refresh" class="btn" />' +
	'<div id="lbl_MP_prnCount"></div>' +
	'<div id="btn_MP_promptPrint" class="btn">' +
		'<img src="" alt="" id="img_MP_promptPrint" class="btnBg" />' +
		'<img src="" alt="" id="img_MP_promptIcon" class="icon"/>' +
		'<div id="lbl_MP_promptPrint" class="lbl"></div>' +
	'</div>' +
	'<div id="btn_MP_selectPrint" class="btn">' +
		'<img src="" alt="" id="img_MP_selectPrint" class="btnBg" />' +
		'<img src="" alt="" id="img_MP_selectIcon" class="icon"/>' +
		'<div id="lbl_MP_selectPrint" class="lbl"></div>' +
	'</div>' +
	'<div id="btn_MP_usageTools" class="btn">' +
		'<img src="" alt="" id="img_MP_usageTools" class="btnBg" />' +
		'<img src="" alt="" id="img_MP_usageToolsIcon" class="icon"/>' +
		'<div id="lbl_MP_usageTools" class="lbl"></div>' +
	'</div>' +
	'<div id="lyr_colorUsage">' +
		'<div id="lbl_MP_color_used"></div>' +
		'<div id="lbl_MP_color_limit"></div>' +
		'<div id="lbl_MP_gray_used"></div>' +
		'<div id="lbl_MP_gray_limit"></div>' +
	'</div>' +
	'<div id="lyr_funcList"></div>' +
	'<div id="btn_MP_funcListUp" class="btn rcWrapper">' +
		'<img id="img_MP_funcListUp"/>' +
	'</div>' +
	'<div id="btn_MP_funcListDown" class="btn rcWrapper focused">' +
		'<img id="img_MP_funcListDown"/>' +
	'</div>' +
	'<div id="txt_MP_Msg0"></div>' +
	'<div id="txt_MP_Msg1"></div>' +
	'<div id="lbl_MP_printOpt" class="lbl"></div>' +
	'<div id="lbl_MP_docCnt" class="lbl"></div>' +
	'<div id="lbl_MP_usage" class="lbl"></div>';
glbPageSource["pop_preferenceSetting"]=
	'<img id="img_PR_bg" class="bg" />' +
	'<!--header-->' +
		'<div>' +
			'<div id="lbl_PR_title" class="lbl"></div>' +
			'<div id="btn_PR_logout" class="btn">' +
				'<img id="img_PR_logout" class="bg" />' +
				'<div id="lbl_PR_logout" class="lbl"></div>' +
			'</div>' +
			'<div id="btn_PR_cancel" class="btn">' +
				'<img id="img_PR_cancel" class="bg" />' +
				'<img src="" alt="" id="img_PR_cancelIcon" class="icon"/>' +
				'<div id="lbl_PR_cancel" class="lbl"></div>' +
			'</div>' +
			'<div id="btn_PR_confirm" class="btn">' +
				'<img id="img_PR_confirm" class="bg" />' +
				'<img src="" alt="" id="img_PR_confirmIcon" class="icon"/>' +
				'<div id="lbl_PR_confirm" class="lbl"></div>' +
			'</div>' +
			'<div id="btn_PR_etc" class="btn">' +
				'<img id="img_PR_etc" class="bg" />' +
				'<div id="lbl_PR_etc" class="lbl"></div>' +
			'</div>' +
		'</div>' +
		'<!--body-->' +
		'<div id="lyr_PR_body">' +
			// '<div id="lbl_PR_titleBarName" class="lbl"></div>' +
			'<div id="lbl_PR_banner" class="lbl"></div> ' +
			'<div id="lbl_PR_serverURL0" class="lbl"></div>' +
			'<div id="lbl_PR_serverURL1" class="lbl"></div>' +
			'<div id="lbl_PR_serverURL2" class="lbl"></div>' +
			'<div id="lbl_PR_serverURL3" class="lbl"></div>' +
			'<div id="lbl_PR_serverURL4" class="lbl"></div>' +
			'<div id="lbl_PR_serverURL5" class="lbl"></div>' +
			'<div id="lbl_PR_serverType" class="lbl"></div> ' +
			'<div id="lbl_PR_agreeDisplay" class="lbl"></div> ' +
			// '<input id="tbx_PR_titleBarName" class="tbx" />' +
			'<input id="tbx_PR_banner" class="tbx" />' +
			'<input id="tbx_PR_serverURL0" class="tbx" />' +
			'<input id="tbx_PR_serverURL1" class="tbx" />' +
			'<input id="tbx_PR_serverURL2" class="tbx" />' +
			'<input id="tbx_PR_serverURL3" class="tbx" />' +
			'<input id="tbx_PR_serverURL4" class="tbx" />' +
			'<input id="tbx_PR_serverURL5" class="tbx" />' +
			'<select id="pul_PR_multiServerType" class="pulldown">' +
				'<option id="pul_PR_multiServerType0" value="0"></option>' +
				'<option id="pul_PR_multiServerType1" value="1"></option>' +
			'</select>' +
			'<select id="pul_PR_agreeDisplay" class="pulldown">' +
				'<option id="pul_PR_agreeDisplay0" value="false"></option>' +
				'<option id="pul_PR_agreeDisplay1" value="true"></option>' +
			'</select>' +
		'</div>' +
		'<div id="txt_PR_Msg0"></div>' +
		'<div id="txt_PR_Msg1"></div>';
glbPageSource["pop_preferenceSettingEtc"] =
	'<img id="img_PRE_bg" class="bg" />' +
		'<!--header-->' +
		'<div>' +
			'<div id="lbl_PRE_title" class="lbl"></div>' +
			'<div id="btn_PRE_cancel" class="btn">' +
				'<img id="img_PRE_cancel" class="bg" />' +
				'<img src="" alt="" id="img_PRE_cancelIcon" class="icon"/>' +
				'<div id="lbl_PRE_cancel" class="lbl"></div>' +
			'</div>' +
			'<div id="btn_PRE_confirm" class="btn">' +
				'<img id="img_PRE_confirm" class="bg" />' +
				'<img src="" alt="" id="img_PRE_confirmIcon" class="icon"/>' +
				'<div id="lbl_PRE_confirm" class="lbl"></div>'+
			'</div>' +
			'<div id="btn_PRE_main" class="btn">' +
				'<img id="img_PRE_main" class="bg" />' +
				'<div id="lbl_PRE_main" class="lbl"></div>' +
			'</div>' +
		'</div>' +
		'<!--body-->' +
		'<div id="lyr_PRE_body">' +
			'<div id="lbl_PRE_body">'+
				'<div id="lbl_PRE_deleteAfterPrintMode" class="lbl"></div>' +
				'<div id="lbl_PRE_resptimeDisplayLimit" class="lbl"></div>' +
				'<div id="lbl_PRE_connectionTimeLimit" class="lbl"></div>' +
				'<div id="lbl_PRE_defaultBtnSetting" class="lbl"></div>' +
				'<div id="lbl_PRE_displayColorUsage" class="lbl"></div>' +
				'<div id="lbl_PRE_lstDisplayLimit" class="lbl"></div>' +
				'<div id="lbl_PRE_lstBarDisplay" class="lbl"></div>' +
				'<div id="lbl_PRE_lstListAutoSelect" class="lbl"></div>' +
				'<div id="lbl_PRE_lstListSortSelect" class="lbl"></div>' +
			'</div>' +
			'<div id="pul_PRE_body">' +
				'<select id="pul_PRE_deleteAfterPrintMode" class="pulldown">' +
					'<option id="pul_PRE_deleteAfterPrintMode0" value="save"></option>' +
					'<option id="pul_PRE_deleteAfterPrintMode1" value="delete"></option>' +
				'</select>' +
				'<select id="pul_PRE_resptimeDisplayLimit" class="pulldown" >' +
					'<option id="pul_PRE_resptimeDisplayLimit0" value="12"></option>' +
					'<option id="pul_PRE_resptimeDisplayLimit1" value="24"></option>' +
				'</select>' +
				'<input id="tbx_PRE_connectionTimeLimit" class="tbx" />'+
				'<div id="lbl_PRE_connectionTimeLimit_Guide" class="lbl"></div>'+
				'<select id="pul_PRE_defaultBtnSetting" class="pulldown">' +
					'<option id="pul_PRE_defaultBtnSetting0" value="0"></option>' +
					'<option id="pul_PRE_defaultBtnSetting1" value="1"></option>' +
					'<option id="pul_PRE_defaultBtnSetting2" value="2"></option>' +
					'<option id="pul_PRE_defaultBtnSetting3" value="3"></option>' +
					'<option id="pul_PRE_defaultBtnSetting4" value="4"></option>' +
				'</select>' +
				'<select id="pul_PRE_displayColorUsage" class="pulldown">' +
					'<option id="pul_PRE_displayColorUsage0" value="Y"></option>' +
					'<option id="pul_PRE_displayColorUsage1" value="N"></option>' +
				'</select>' +
				'<select id="pul_PRE_lstDisplayLimit" class="pulldown">' +
					'<option id="pul_PRE_lstDisplayLimit0" value="40"></option>' +
					'<option id="pul_PRE_lstDisplayLimit1" value="80"></option>' +
				'</select>' +
				'<select id="pul_PRE_lstBarDisplay" class="pulldown">'+
					'<option id="pul_PRE_lstBarDisplay0" value="Y"></option>' +
					'<option id="pul_PRE_lstBarDisplay1" value="N"></option>' +
				'</select>' +
				'<select id="pul_PRE_lstListAutoSelect" class="pulldown">' +
					'<option id="pul_PRE_lstListAutoSelect0" value="0"></option>' +
					'<option id="pul_PRE_lstListAutoSelect1" value="1"></option>' +
				'</select>' +
				'<select id="pul_PRE_lstListSortSelect" class="pulldown">' +
					'<option id="pul_PRE_lstListSortSelect0" value="Y"></option>' +
					'<option id="pul_PRE_lstListSortSelect1" value="N"></option>' +
				'</select>' +
			'</div>' +
		'</div>' +
		'<div id="txt_PRE_Msg0"></div>' +
		'<div id="txt_PRE_Msg1"></div>';
glbPageSource["pop_printSetting"]=
	'<!--header-->' +
		'<img id="img_PS_bg" />' +
		'<div id="lbl_PS_title" class="lbl"></div>' +
		'<div id="btn_PS_confirm" class="btn">' +
			'<img id="img_PS_confirm" class="bg" />' +
			'<img id="icon_PS_confirm" class="icon" />' +
			'<div id="lbl_PS_confirm" class="lbl"></div>' +
		'</div>' +
		'<div id="btn_PS_cancel" class="btn">' +
			'<img id="img_PS_cancel" class="bg" />' +
			'<img id="icon_PS_cancel" class="icon" />' +
			'<div id="lbl_PS_cancel" class="lbl"></div>' +
		'</div>' +
	'<!--body-->' +
		'<div id="lbl_PS_eco_msg1" class="lbl"></div>' +
		'<div id="lbl_PS_eco_msg2" class="lbl"></div>' +
		'<div id="btn_PS_print" class="btn" >' +
			'<img id="img_PS_print" class="btnBg" />' +
			'<img id="icon_PS_print" class="icon" />' +
			'<div id="lbl_PS_print" class="lbl" ></div>' +
		'</div>' +
		'<div id="tit_PS_jobName" class="lbl"></div>' +
		'<div id="lbl_PS_jobName" class="lbl"></div>' +
		'<div id="tit_PS_jobRcvTime" class="lbl"></div>' +
		'<div id="lbl_PS_jobRcvTime" class="lbl"></div>' +
		'<div id="tit_PS_totalPage" class="lbl"></div>' +
		'<div id="lbl_PS_totalPage" class="lbl"></div>' +
		'<div id="lbl_PS_totalPageUnit" class="lbl"></div>' +
		'<div id="tit_PS_printQuantity" class="lbl"></div>' +
		'<div id="lyr_PS_printQuantity" class="lyr">' +
			'<div id="lbl_PS_printQuantity" class="lbl"></div>' +
			'<div id="lbl_PS_printQuantityUnit"></div>' +
		'</div>' +
		'<div id="tit_PS_printQuantityUnit" class="lbl"></div>' +
		'<div id="btn_PS_deleteAfterPrint" type="checkbox" class="btn" >' +
			'<img id="cbx_PS_deleteAfterPrint" class="icon"/>' +
			'<div id="tit_PS_deleteAfterPrint" class="lbl"></div>' +
		'</div>' +
		'<div id="btn_PS_watermarkOn" type="checkbox" class="btn" >' +
			'<img id="cbx_PS_watermarkOn" class="icon"/>' +
			'<div id="tit_PS_watermarkOn" class="lbl"></div>' +
		'</div>' +
		'<div id="tit_PS_nup" class="lbl"></div><!--pulldown nup--><div id="pul_PS_nup" class="pulldown"><img id="img_PS_nup" class="bg" /><img id="icn_PS_nup" class="icn" /><div id="lbl_PS_nup" class="lbl"></div></div><div id="pul_PS_btn_nup" class="pulldown"><img id="img_PS_btn_nup" class="img" /></div><div id="tit_PS_color" class="lbl"></div><!--pulldown color--><div id="pul_PS_color" class="pulldown"><img id="img_PS_color" class="bg" /><img id="icn_PS_color" class="icn" /><div id="lbl_PS_color" class="lbl"></div></div><div id="pul_PS_btn_color" class="pulldown"><img id="img_PS_btn_color" class="img" /></div><div id="tit_PS_plex" class="lbl">tit_PS_plex</div><!--pulldown Plex--><div id="pul_PS_plex" class="pulldown"><img id="img_PS_plex" class="bg" /><img id="icn_PS_plex" class="icn" /><div id="lbl_PS_plex" class="lbl"></div></div><div id="pul_PS_btn_plex" class="pulldown"><img id="img_PS_btn_plex" class="img" /></div><div id="lyr_PS_infoDisplay"><div id="lyr_PS_Msg" class="lbl"><div id="txt_PS_Msg0"></div><div id="txt_PS_Msg1"></div></div><img id="btn_PS_infoUp" class="btn" /><img id="btn_PS_infoDown" class="btn" /></div></div>';
glbPageSource["pop_printSettingMulti"] = //2017.08~09 [삼정회계법인] 선택 출력의 프린트 설정 일괄 변경 기능 추가 refs #4429
    '<img id="img_PSM_bg" />' +
    '<img id="icn_PSM_title" class="icon" />' +
    '<div id="lbl_PSM_title" class="lbl"></div>' +
    '<div id="btn_PSM_confirm" class="btn">' +
    	'<img id="img_PSM_confirm" class="bg" />' +
    	'<img id="icon_PSM_confirm" class="icon" />' +
    	'<div id="lbl_PSM_confirm" class="lbl"></div>' +
    '</div>' +
    '<div id="btn_PSM_cancel" class="btn">' +
    	'<img id="img_PSM_cancel" class="bg" />' +
    	'<img id="icon_PSM_cancel" class="icon" />' +
    	'<div id="lbl_PSM_cancel" class="lbl"></div>' +
    '</div>' +
    '<span id="lbl_PSM_guide"></span>' +
    '<div id="btn_PSM_print" class="btn">' +
    	'<img id="img_PSM_print" class="btnBg" />' +
    	'<img id="icon_PSM_print" class="icon" />' +
    	'<div id="lbl_PSM_print" class="lbl" ></div>' +
    '</div>' +
    '<div id="tit_PSM_printQuantity" class="lbl"></div>' +
    '<div id="lyr_PSM_printQuantity" class="lyr">' +
    	'<div id="lbl_PSM_printQuantity" class="lbl"></div>' +
    	'<div id="lbl_PSM_printQuantityUnit"></div>' +
    '</div>' +
    '<div id="tit_PSM_printQuantityUnit" class="lbl"></div>' +
	'<div id="btn_PSM_watermarkOn" type="checkbox" class="btn" >' +
		'<img id="cbx_PSM_watermarkOn" class="icon"/>' +
		'<div id="tit_PSM_watermarkOn" class="lbl"></div>' +
	'</div>' +
    '<div id="tit_PSM_color" class="lbl"></div>' +
    '<div id="pul_PSM_color" class="pulldown">' +
    	'<img id="img_PSM_color" class="bg" />' +
    	'<img id="icn_PSM_color" class="icn" />' +
    	'<div id="lbl_PSM_color" class="lbl"></div>' +
    '</div>' +
    '<div id="pul_PSM_btn_color" class="pulldown">' +
    	'<img id="img_PSM_btn_color" class="img" />' +
    '</div>' +
    '<div id="tit_PSM_plex" class="lbl"></div>' +
    '<div id="pul_PSM_plex" class="pulldown">' +
    	'<img id="img_PSM_plex" class="bg" />' +
    	'<img id="icn_PSM_plex" class="icn" />' +
    	'<div id="lbl_PSM_plex" class="lbl"></div>' +
    '</div>' +
    '<div id="pul_PSM_btn_plex" class="pulldown">' +
    	'<img id="img_PSM_btn_plex" class="img" />' +
    '</div>' +
    '<div id="lyr_PSM_infoDisplay">' +
    	'<div id="lyr_PSM_Msg" class="lbl">' +
    	'<div id="txt_PSM_Msg0"></div>' +
    	'<div id="txt_PSM_Msg1"></div>' +
    '</div>' +
    '<img id="btn_PSM_infoUp" class="btn" />' +
    '<img id="btn_PSM_infoDown" class="btn" />' +
    '</div>';
glbPageSource["pop_registCard"]=
	'<!-- body -->' +
		'<div id="lbl_RC_title" class="rcWrapper focused"></div>' +
		'<div id="lyr_RC_step01" class="rcWrapper">' +
			'<img id="img_RC_step01_bg" />' +
			'<img id="img_RC_step01_agree" src = ""/>' +
			'<div id="lyr_RC_step01_guide" class="rcWrapper focused">' +
				'<img id="img_RC_step01_card" />' +
            	'<div id="lbl_RC_step01_guide1"></div>' +
            	'<div id="lbl_RC_step01_guide2"></div>' +
            	'<div id="lbl_RC_step01_guide3"></div>' +
			'</div>' +
			'<div id="btn_RC_step01_ok" class="btn" >' +
					'<img id="img_RC_step01_ok" class="btnBg" />' +
					'<img id="icon_RC_step01_ok" class="icon" />' +
					'<div id="lbl_RC_step01_ok" class-"lbl"></div>' +
			'</div>' +
			'<div id="btn_RC_step01_cancel" class="btn" >' +
					'<img id="img_RC_step01_cancel" class="btnBg" />' +
					'<img id="icon_RC_step01_cancel" class="icon" />' +
					'<div id="lbl_RC_step01_cancel" class-"lbl"></div>' +
			'</div>' +
		'</div>' +
		'<div id="lyr_RC_step02" class="rcWrapper">' +
			'<img id="img_RC_step02_bg" />' +
			'<div id="lbl_RC_step02_guide1"></div>' +
			'<div id="lbl_RC_step02_guide2"></div>' +
			'<div id="lbl_RC_step02_guide3"></div>' +
			'<div id="lbl_RC_step02_guide4"></div>' +
			'<div id="lbl_RC_step02_id"></div>' +
			'<input id="tbx_RC_step02_id" type="text" class="id_box" />' +
			'<div id="lbl_RC_step02_pw"></div>' +
			'<input id="tbx_RC_step02_pw" type="password" class="pw_box" />' +
			'<div id="btn_RC_step02_ok" class="btn" >' +
				'<img id="img_RC_step02_ok" class="btnBg" />' +
				'<img id="icon_RC_step02_ok" class="icon" />' +
				'<div id="lbl_RC_step02_ok" class-"lbl"></div>' +
			'</div>' +
			'<div id="btn_RC_step02_cancel" class="btn" >' +
				'<img id="img_RC_step02_cancel" class="btnBg" />' +
				'<img id="icon_RC_step02_cancel" class="icon" />' +
				'<div id="lbl_RC_step02_cancel" class-"lbl"></div>' +
			'</div>' +
		'</div>' +
		'<div id="lyr_RC_step03" class="rcWrapper"><img id="img_RC_step03_bg" /><img id="img_RC_step03_card" /><div id="lbl_RC_step03_guide1"></div><div id="lbl_RC_step03_guide2"></div><div id="btn_RC_step03_ok" class="btn" ><img id="img_RC_step03_ok" class="btnBg" /><img id="icon_RC_step03_ok" class="icon" /><div id="lbl_RC_step03_ok" class-"lbl"></div></div></div>';
glbPageSource["pop_passwordExp"]=
		'<!-- body -->' +
			'<div id="lbl_PE_title" class="peWrapper focused"></div>' +
			'<div id="lyr_PE_step01" class="peWrapper">' +
				'<img id="img_PE_step01_bg" />' +
				'<img id="img_PE_step01_agree" src = ""/>' +
				'<div id="lyr_PE_step01_guide" class="peWrapper focused">' +
					'<img id="img_PE_step01_password" />' +
					'<div id="lbl_PE_step01_guide1"></div>' +
					'<div id="lbl_PE_step01_guide2"></div>' +
					'<div id="lbl_PE_step01_guide3"></div>' +
				'</div>' +
				'<div id="btn_PE_step01_ok" class="btn" >' +
					'<img id="img_PE_step01_ok" class="btnBg" />' +
					'<img id="icon_PE_step01_ok" class="icon" />' +
					'<div id="lbl_PE_step01_ok" class-"lbl"></div>' +
				'</div>' +
				'<div id="btn_PE_step01_cancel" class="btn" >' +
					'<img id="img_PE_step01_cancel" class="btnBg" />' +
					'<img id="icon_PE_step01_cancel" class="icon" />' +
					'<div id="lbl_PE_step01_cancel" class-"lbl"></div>' +
				'</div>' +
			'</div>' +
			'<div id="lyr_PE_step02" class="peWrapper">' +
				'<img id="img_PE_step02_bg" />' +
				'<div id="lbl_PE_step02_guide1"></div>' +
				'<div id="lbl_PE_step02_guide2"></div>' +
				'<div id="lbl_PE_step02_guide3"></div>' +
				'<div id="lbl_PE_step02_guide4"></div>' +
				'<div id="lbl_PE_step02_pw_new"></div>' +
				'<input id="tbx_PE_step02_pw_new" type="password" class="pw_box" />' +
				'<div id="lbl_PE_step02_pw_chk"></div>' +
				'<input id="tbx_PE_step02_pw_chk" type="password" class="pw_box" />' +
				'<div id="btn_PE_step02_ok" class="btn" >' +
					'<img id="img_PE_step02_ok" class="btnBg" />' +
					'<img id="icon_PE_step02_ok" class="icon" />' +
					'<div id="lbl_PE_step02_ok" class-"lbl"></div>' +
				'</div>' +
				'<div id="btn_PE_step02_cancel" class="btn" >' +
					'<img id="img_PE_step02_cancel" class="btnBg" />' +
					'<img id="icon_PE_step02_cancel" class="icon" />' +
					'<div id="lbl_PE_step02_cancel" class-"lbl"></div>' +
				'</div>' +
			'</div>' +
			'<div id="lyr_PE_step03" class="peWrapper">' +
				'<img id="img_PE_step03_bg" />' +
				'<img id="img_PE_step03_password" />' +
				'<div id="lbl_PE_step03_guide1"></div>' +
				'<div id="lbl_PE_step03_guide2"></div>' +
				'<div id="btn_PE_step03_ok" class="btn" >' +
					'<img id="img_PE_step03_ok" class="btnBg" />' +
					'<img id="icon_PE_step03_ok" class="icon" />' +
					'<div id="lbl_PE_step03_ok" class-"lbl"></div>' +
				'</div>' +
			'</div>';
glbPageSource["pop_printing"]=
	'<!--header-->' +
		'<div id="lbl_PP_title"></div>' +
	'<!--body-->' +
	'<div>' +
		'<img id="img_PP_BG" />' +
		'<div id="lbl_PP_guide" class="lbl" ></div>' +
		'<img id="img_PP_PG" />' +
		'<img id="img_PP_PGB" />' +
		'<img id="img_PP_MACHINE" />' +
	'</div>';
glbPageSource["pop_errorPopup"]='<!--header--><img id="img_EP_bg" /><div id="lbl_EP_title"></div><!--body--><div><div id="lbl_EP_msg"><ul><li><div id="txt_EP_msg0"></div></li><li><div id="txt_EP_msg1"></div></li><li><div id="txt_EP_msg2"></div></li><li><div id="txt_EP_msg3"></div></li><li><div id="txt_EP_msg4"></div></li><li><div id="txt_EP_msg5"></div></li><li><div id="txt_EP_msg6"></div></li><li><div id="txt_EP_msg7"></div></li><li><div id="txt_EP_msg8"></div></li><li><div id="txt_EP_msg9"></div></li><li><div id="txt_EP_msg10"></div></li><li><div id="txt_EP_msg11"></div></li></ul></div></div>';
glbPageSource["pop_warnPopup"]='<!--header--><img id="img_WP_bg" /><!--body--><img id="img_WP_icon" /><div><div id="lbl_WP_msg"><div id="txt_WP_msg0"></div><div id="txt_WP_msg1"></div><div id="txt_WP_msg2"></div><div id="txt_WP_msg3"></div><div id="txt_WP_msg4"></div><div id="txt_WP_msg5"></div></div><div id="btn_WP_close" class="btn"><img id="img_WP_close" class="btnBg" /><img id="icn_WP_cancel" class="icon" /><div id="lbl_WP_close" ></div></div></div>';
