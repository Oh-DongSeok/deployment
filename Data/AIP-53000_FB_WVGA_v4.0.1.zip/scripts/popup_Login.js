﻿/**
 * 개별 페이지의 표시 및 동작용
 * （IC Card등록용 팝업)
 */
var LoginPopup = new TemplatePage();
var textIdSelect = false;
var textPwSelect = false;

LoginPopup.ID = "pop_login";

/**
 * 개별 페이지의 Data정의
 */
LoginPopup._initModel = function()
{
	this._data =
	{
		buttonList:[
			{	//확인버튼
				id:"btn_LI_ok",
				type:WidgetLib.ButtonType.NORMAL,
				attr:{targetImgId:"img_LI_ok", offImg: Img.BTN_AP_OK_OFF, pressImg: Img.BTN_AP_OK_PRESS,
						iconAttr:{targetImgId:"icon_LI_ok",offImg: Img.IMG_OK_ICON_OFF, pressImg: Img.IMG_OK_ICON_PRESS}}
			},
			{	//취소버튼
				id:"btn_LI_cancel",
				type:WidgetLib.ButtonType.NORMAL,
				attr:{targetImgId:"img_LI_cancel", offImg: Img.BTN_AP_CANCEL_OFF,pressImg: Img.BTN_AP_CANCEL_PRESS,
						iconAttr:{targetImgId:"icon_LI_cancel",offImg: Img.IMG_CANCEL_ICON_OFF, pressImg: Img.IMG_CANCEL_ICON_PRESS}}
			},
		],
		imageList:[
			{id:"img_LI_bg",		src:Img.IMG_RC_BG1},
		],
		textList:[
			{id:"lbl_LI_title",		text:Msg.LOGIN.TITLE},
			{id:"lbl_LI_guide1",	text:Msg.LOGIN.GUIDE1	},
			{id:"lbl_LI_guide2",	text:Msg.LOGIN.GUIDE2	},
			{id:"lbl_LI_ok",		text:Msg.LOGIN.LBL_OK	},
			{id:"lbl_LI_cancel",	text:Msg.LOGIN.LBL_CANCEL	}
		]
	};
};

LoginPopup._onPageChange=function(){
	this._dataSet.rcStep = 0;
	WidgetLib.setWidgetStatus("btn_LI_ok",{enable:true});
	document.getElementById("lyr_LI_input").className = "liWrapper focused";
	this.updateDisplay();
};
/**
 * 화면 표시의 갱신 (공통/화면전환시에 호출된다.)
 */
LoginPopup.updateDisplay=function(){
	KISUtil.debug("function:","updateDisplay");

};

/**
 * 개별 페이지의 Event처리
 * @param {string} event : Event의 종류
 * @param {string} id : Event의 발생원
 */
LoginPopup.EventHandler = function(event, id)
{
	KISUtil.debug("EventHandler","event:"+event+"/id:"+id);
	//Common.setText("lbl_LI_step02_guide0", "event:" + event + "/id:" + id);
	switch(event){
		case "onbuttonup":
			MessageManager.clearMessageArea();
			BrowserExt.Beep(0);
			switch(id)
			{
				case "btn_LI_ok":
					var _id = document.getElementById('tbx_LI_id').value;
					var _pw = document.getElementById('tbx_LI_pw').value;
					
					//send Login
					if(_id == "11111"){
						//userId, password, realm, bltinUser, isKeyOperator
						var realm = "";
						//var bltinUser = "CustomerEngineer";
						var bltinUser = "";
						var isKeyOperator = true;
						SSMILib.LoginDev(_id, _pw, realm, bltinUser, isKeyOperator);
					}else{
						SSMILib.LoginDev(_id, _pw);
					}

					//여러번 클릭에 따른 다중요청이 발생할 수 있음 회피 코드가 필요해보임
					WidgetLib.setWidgetStatus("btn_LI_ok",{enable:false});
					BrowserExt.SetScreenChange("allservice");
					break;
				case "btn_LI_cancel":
					//로그아웃 처리
					SSMILib.LogoutDev();
					BrowserExt.SetScreenChange("allservice");
					break;
				case "btn_MP_func_0":
				case "btn_MP_func_1":
				case "btn_MP_func_2":
				case "btn_MP_func_3":
				case "btn_MP_func_4":
				case "btn_MP_func_5":
				case "btn_MP_func_6":
				case "btn_MP_func_7":
				case "btn_MP_func_8":
					break;
				case "btn_comeback_key":
					document.getElementById('tbx_LI_id').value = "";
					document.getElementById('tbx_LI_pw').value = "";
					break;
				case "btn_menu_key":
					//リセットキー
					BrowserExt.Beep(0);
					BrowserExt.SetScreenChange("allservice");
					//document.getElementById('tbx_LI_step02_id').value = "";
					//document.getElementById('tbx_LI_step02_pw').value = "";
					break;
				case "btn_auth_key":
					BrowserExt.Beep(1);
					break;
				case "btn_start_key":
					BrowserExt.Beep(1);
					break;
				default:
					//clearMessageAreaTimer();
					break;
			}
			break;
		case "onhardkeydown":
			MessageManager.clearMessageArea();
			BrowserExt.Beep(1);
			return;
		default:
			break;
	}
};

function select(){
	textIdSelect = true;
	textPwSelect = false;
}