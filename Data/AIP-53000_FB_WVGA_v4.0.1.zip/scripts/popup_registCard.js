﻿/**
 * 개별 페이지의 표시 및 동작용
 * （IC Card등록용 팝업)
 */
var RegistCardPopup = new TemplatePage();

RegistCardPopup.ID = "pop_registCard";

/**
 * 개별 페이지의 Data정의
 */
RegistCardPopup._initModel = function()
{
	this._data =
	{
		buttonList:[
			{	//step01 확인버튼
				id:"btn_RC_step01_ok",	
				type:WidgetLib.ButtonType.NORMAL,
				attr:{targetImgId:"img_RC_step01_ok", offImg: Img.BTN_AP_OK_OFF, pressImg: Img.BTN_AP_OK_PRESS, 
						iconAttr:{targetImgId:"icon_RC_step01_ok",offImg: Img.IMG_OK_ICON_OFF, pressImg: Img.IMG_OK_ICON_PRESS}}
			},
			{	//step01 취소버튼
				id:"btn_RC_step01_cancel",
				type:WidgetLib.ButtonType.NORMAL,
				attr:{targetImgId:"img_RC_step01_cancel", offImg: Img.BTN_AP_CANCEL_OFF,pressImg: Img.BTN_AP_CANCEL_PRESS,
						iconAttr:{targetImgId:"icon_RC_step01_cancel",offImg: Img.IMG_CANCEL_ICON_OFF, pressImg: Img.IMG_CANCEL_ICON_PRESS}}
			},
			{	//step02 확인버튼
				id:"btn_RC_step02_ok",
				type:WidgetLib.ButtonType.NORMAL,
				attr:{targetImgId:"img_RC_step02_ok", offImg: Img.BTN_AP_OK_OFF, pressImg: Img.BTN_AP_OK_PRESS,
						iconAttr:{targetImgId:"icon_RC_step02_ok",offImg: Img.IMG_OK_ICON_OFF, pressImg: Img.IMG_OK_ICON_PRESS}}
			},
			{	//step02 취소버튼
				id:"btn_RC_step02_cancel",
				type:WidgetLib.ButtonType.NORMAL,
				attr:{targetImgId:"img_RC_step02_cancel", offImg: Img.BTN_AP_CANCEL_OFF,pressImg: Img.BTN_AP_CANCEL_PRESS,
						iconAttr:{targetImgId:"icon_RC_step02_cancel",offImg: Img.IMG_CANCEL_ICON_OFF, pressImg: Img.IMG_CANCEL_ICON_PRESS}}
			},
			{	//step03 확인버튼
				id:"btn_RC_step03_ok",
				type:WidgetLib.ButtonType.NORMAL,
				attr:{targetImgId:"img_RC_step03_ok", offImg: Img.BTN_AP_OK_OFF, pressImg: Img.BTN_AP_OK_PRESS,
					iconAttr:{targetImgId:"icon_RC_step03_ok",offImg: Img.IMG_OK_ICON_OFF, pressImg: Img.IMG_OK_ICON_PRESS}}
			},
		],
		imageList:[
			{id:"img_RC_step01_bg",	src:Img.IMG_RC_BG0},
			{id:"img_RC_step01_card", src:Img.IMG_RC_CARD},
			{id:"img_RC_step02_bg",	src:Img.IMG_RC_BG1},		
			{id:"img_RC_step03_bg",	src:Img.IMG_RC_BG2},
			{id:"img_RC_step03_card", src:Img.IMG_RC_CARD2}
			//,{id:"icn_RC_popup",	src:Img["ICN_RC_REGIST_CARD"]},
		],
		textList:[
			{id:"lbl_RC_title",	text:Msg.REGIST_CARD.STEP1_TITLE},
			{id:"lbl_RC_step01_guide1",	text:Msg.REGIST_CARD.STEP1_GUIDE1	},
			{id:"lbl_RC_step01_guide2",	text:Msg.REGIST_CARD.STEP1_GUIDE2	},
			{id:"lbl_RC_step01_guide3",	text:Msg.REGIST_CARD.STEP1_GUIDE3	},
			{id:"lbl_RC_step02_guide1",	text:Msg.REGIST_CARD.STEP2_GUIDE1	},
			{id:"lbl_RC_step02_guide2",	text:Msg.REGIST_CARD.STEP2_GUIDE2	},
			{id:"lbl_RC_step03_guide1",	text:Msg.REGIST_CARD.STEP3_GUIDE1	},
			{id:"lbl_RC_step03_guide2",	text:Msg.REGIST_CARD.STEP3_GUIDE2	},
			{id:"lbl_RC_step01_ok",	text:Msg.REGIST_CARD.LBL_OK	},
			{id:"lbl_RC_step01_cancel",	text:Msg.REGIST_CARD.LBL_CANCEL	},
			{id:"lbl_RC_step02_id",	text:Msg.REGIST_CARD.STEP2_ID},
			{id:"lbl_RC_step02_pw",	text:Msg.REGIST_CARD.STEP2_PW},
			{id:"lbl_RC_step02_ok",	text:Msg.REGIST_CARD.LBL_OK	},
			{id:"lbl_RC_step02_cancel",	text:Msg.REGIST_CARD.LBL_CANCEL	},
			{id:"lbl_RC_step03_ok",	text:Msg.REGIST_CARD.LBL_OK	}
		]
	};
};

RegistCardPopup._onPageChange=function(){
	this._dataSet.rcStep = 0;
	WidgetLib.setWidgetStatus("btn_RC_step02_ok",{enable:true});
	document.getElementById("lyr_RC_step01").className = "rcWrapper focused";
	if(glbConfig.DATA.AGREE_DISPLAY){
		Common.setImage("img_RC_step01_agree", Img.IMG_RC_AGREE);
		Common.setText("lbl_RC_step01_ok", Msg.REGIST_CARD.LBL_AGREE);
		document.getElementById("lyr_RC_step01_guide").className = "rcWrapper";
		document.getElementById("lbl_RC_title").className = "rcWrapper";
		document.getElementById('btn_RC_step01_ok').style.top = "415px";
		document.getElementById('btn_RC_step01_cancel').style.top = "415px";
	}else{
		document.getElementById("lyr_RC_step01_guide").className = "rcWrapper focused";
		Common.setImage("img_RC_step01_agree", Img.EMPTY_ICON);
	}
	this.updateDisplay();
};
/**
 * 화면 표시의 갱신 (공통/화면전환시에 호출된다.)
 */
RegistCardPopup.updateDisplay=function(){
	KISUtil.debug("function:","updateDisplay");

	var idx = this._dataSet.registCardIdx;
	//console.log("this._dataSet.registCardIdx:"+this._dataSet.registCardIdx);
	if(idx<0)
	{
		KISUtil.debug("invalid DataType/registCard",this._dataSet.registCard);
	}
	else
	{
		glbInfo.registCard=[0,1,2];		//필요한가?
		for(var i=0,il=glbInfo.registCard.length;i<il;i++)
		{
			WidgetLib.setWidgetStatus("btn_RC_registCard_"+i,{on:(i==idx)});
		}
	}
};

/**
 * 개별 페이지의 Event처리
 * @param {string} event : Event의 종류
 * @param {string} id : Event의 발생원
 */
RegistCardPopup.EventHandler = function(event, id)
{
	KISUtil.debug("EventHandler","event:"+event+"/id:"+id);
	switch(event){
		case "RegisterCard":
			var param = {title:Msg.WarnPopup.title, type:"logout", targetPage:true};
			param.message = Msg.errorMessage.ERRCODE008;
			if(arguments[1] == true){
				var response = arguments[2];
				switch(response.status){
					case "useridNull":
						param.message = Msg.errorMessage.ERRCODE006;
						break;
					case "userpwNull":
						param.message = Msg.errorMessage.ERRCODE020;
						break;
					case "cardidNull":
						param.message = Msg.errorMessage.ERRCODE007;
						break;
					case "cardExist":
						param.message = Msg.errorMessage.ERRCODE024;
						break;
					case "userFail":
						param.message = Msg.errorMessage.ERRCODE009;
						break;
					case "fail":
						param.message = Msg.errorMessage.ERRCODE008;
						break;
					case "success":
					default:
						//if success
						//goto next Step
						document.getElementById("lyr_RC_step02").className = "rcWrapper";
						document.getElementById("lyr_RC_step03").className = "rcWrapper focused";
						this._dataSet.rcStep++;
						return;
				}
			}
			WarnPopup._message = param;
			PageManager.changePage(WarnPopup,PageManager.type.NORMAL);
			break;
		case "onbuttonup":
			MessageManager.clearMessageArea();
			BrowserExt.Beep(0);
			switch(id)
			{
				case "btn_RC_step01_ok":
					document.getElementById("lyr_RC_step01").className = "rcWrapper";
					document.getElementById("lyr_RC_step02").className = "rcWrapper focused";
					if(glbConfig.DATA.AGREE_DISPLAY){
						document.getElementById("lbl_RC_title").className = "rcWrapper focused";
					}
					this._dataSet.rcStep++;
					break;
				case "btn_RC_step02_ok":
					var _id = document.getElementById('tbx_RC_step02_id').value;
					var _pw = document.getElementById('tbx_RC_step02_pw').value;
					
					//send RegCard
					var cardInfoObj = new SSMILib.CardInfo();
					cardInfoObj.cardId = glbInfo.cardInfo; 
					cardInfoObj.userId = _id; 
					cardInfoObj.userPw = _pw; 
					//SSMILib.RegisterCard(cardInfoObj, DOC_PRINT_TIMEOUT);
					SSMILib.RegisterCard(cardInfoObj, DOC_PRINT_TIMEOUT, glbConfig.DATA.SERVER_URL[0]);//SmartUI 2017.02 복수의 Print Server 대응 refs #4184
					
					//여러번 클릭에 따른 다중요청이 발생할 수 있음 회피 코드가 필요해보임
					WidgetLib.setWidgetStatus("btn_RC_step02_ok",{enable:false});
					break;
				case "btn_RC_step03_ok":
					document.getElementById("lyr_RC_step03").className = "rcWrapper";
					delete this._dataSet.rcStep;
					//changePage
					//PageManager.changePage(WaitingPage, PageManager.type.NORMAL);
					//SSMILib.GetAccountConfig();
					SSMILib.LogoutDev();
					break;
				case "btn_RC_step01_cancel":
					document.getElementById("lyr_RC_step01").className = "rcWrapper";
					delete this._dataSet.rcStep;
					//PageManager.changePage(MenuPage, PageManager.type.NORMAL);
					//로그아웃 처리
					SSMILib.LogoutDev();
					break;
				case "btn_RC_step02_cancel":
					document.getElementById("lyr_RC_step02").className = "rcWrapper";
					//document.getElementById("lyr_RC_step01").className = "rcWrapper focused";
					//this._dataSet.rcStep--;
					delete this._dataSet.rcStep;
					//로그아웃 처리
					SSMILib.LogoutDev();
					break;
				case "btn_comeback_key":
					document.getElementById('tbx_RC_step02_id').value = "";
					document.getElementById('tbx_RC_step02_pw').value = "";
					break;
				case "btn_menu_key":
					//リセットキー
					BrowserExt.Beep(0);
					BrowserExt.SetScreenChange("allservice");
					//document.getElementById('tbx_LI_step02_id').value = "";
					//document.getElementById('tbx_LI_step02_pw').value = "";
					break;
				case "btn_auth_key":
					if(glbInfo.userInfo){
						SSMILib.LogoutDev();
					}
					BrowserExt.Beep(0);
					break;
				case "btn_start_key":
					BrowserExt.Beep(1);
					break;
				default:
					//clearMessageAreaTimer();
					break;
			}
			break;
		case "onhardkeydown":
			MessageManager.clearMessageArea();
			switch(id)
			{
				case BrowserExt.keyCode.FX_VK_CLEAR:
					//Reset Key
					BrowserExt.Beep(0);
					//window.location.reload(true);
					// Mantis No: 0000018
					BrowserExt.SetScreenChange("allservice");
					break;
				case BrowserExt.keyCode.FX_VK_BACK_SPACE:
					BrowserExt.Beep(0);
					document.getElementById('tbx_RC_step02_id').value = "";
					document.getElementById('tbx_RC_step02_pw').value = "";
					break;
				case BrowserExt.keyCode.FX_VK_ENTER:
					// step을 확인할 수 없으므로 Enter key는 사용하지 않음.
					BrowserExt.Beep(1);
					break;
				case BrowserExt.keyCode.FX_VK_0:
				case BrowserExt.keyCode.FX_VK_1:
				case BrowserExt.keyCode.FX_VK_2:
				case BrowserExt.keyCode.FX_VK_3:
				case BrowserExt.keyCode.FX_VK_4:
				case BrowserExt.keyCode.FX_VK_5:
				case BrowserExt.keyCode.FX_VK_6:
				case BrowserExt.keyCode.FX_VK_7:
				case BrowserExt.keyCode.FX_VK_8:
				case BrowserExt.keyCode.FX_VK_9:
				case BrowserExt.keyCode.FX_VK_PAUSE:
					break;
				default:
					BrowserExt.Beep(1);
					break;
			}
			break;
		default:
			break;
	}
};